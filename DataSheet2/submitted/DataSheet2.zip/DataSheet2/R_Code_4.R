############################
#### Table 1 FUNCTIONS ####
############################

# first set the working directory
setwd("~/Desktop/test/analysis/table_1/")

# We will define a few functions
# These will be specific to either OTUs or Taxa
# But they are applicable to all three tests: KW,NPT,GT

# NOTE: after each 'major' step a new df is created...
# so that the old df is stored within the function...
# and may be called to debug anything later on

require(dplyr)
GetSigsOTUs <- function(data=data.frame){
    # specifiy the order of columns, and drop unneeded columns in the process
    df1 <- data[,c(1,3,6:8)]
    df2 <- df1
    # split the columns (3 and 4) with Age-Genotype (i.e. column 3 name is: P24.WT_mean)
    # place them into vectors, age becomes new column 'Age'
    # col3 becomes new column 3 name, col4 becomes new column 4 name
    age <- strsplit(names(df2)[3],"\\.")[[1]][1]
    df2$Age <- age
    col3 <- strsplit(names(df2)[3],"\\.")[[1]][2]
    names(df2)[3] <- col3
    col4 <- strsplit(names(df2)[4],"\\.")[[1]][2]
    names(df2)[4] <- col4
    df3 <- df2
    # filter column P, based upon significance
    df3 <- filter(df3, P < 0.05)
    # if no P-values are < 0.05, paste 1 into each row
    # this allows the function to proceed
    if(nrow(df3) == 0){df3[1,] <- 1}
    df4 <- df3
    # reorder columns to ensure that KO_mean is column 3, and WT_mean is column 4
    coltest <- as.numeric(which(colnames(df4) == "KO_mean"))
    if(coltest==4){df4 <- df4[,c(1:2,4,3,5:6)]}
    df5 <- df4
    # calculate log2 Fold Change (KO to WT)
    df5$log2FC <- (log2(df5[3]) - log2(df5[4]))
    df6 <- df5
    # replace any Inf and -Inf values with 10 and -10 respectively
    df6[,7][df6[,7] == "Inf"] <- "10"
    df6[,7][df6[,7] == "-Inf"] <- "-10"
    return(df6)
}

require(dplyr)
GetSigsTaxa <- function(data=data.frame){
    # specifiy the order of columns, and drop unneeded columns in the process
    # and change column name 'OTU' to 'Taxon'
    df1 <- data[,c(1,3,6:7)]
    names(df1)[1] <- "Taxon"
    df2 <- df1
    # split the columns (3 and 4) with Age-Genotype (i.e. column 3 name is: P24.WT_mean)
    # place them into vectors, age becomes new column 'Age'
    # col3 becomes new column 3 name, col4 becomes new column 4 name
    age <- strsplit(names(df2)[3],"\\.")[[1]][1]
    df2$Age <- age
    col3 <- strsplit(names(df2)[3],"\\.")[[1]][2]
    names(df2)[3] <- col3
    col4 <- strsplit(names(df2)[4],"\\.")[[1]][2]
    names(df2)[4] <- col4
    df3 <- df2
    # filter column P, based upon significance
    df3 <- filter(df3, P < 0.05)
    # if no P-values are < 0.05, paste 1 into each row
    # this allows the function to proceed
    if(nrow(df3) == 0){df3[1,] <- 1}
    df4 <- df3
    # reorder columns to ensure that KO_mean is column 3, and WT_mean is column 4
    coltest <- as.numeric(which(colnames(df4) == "KO_mean"))
    if(coltest==4){df4 <- df4[,c(1:2,4,3,5)]}
    df5 <- df4
    # calculate log2 Fold Change (KO to WT)
    df5$log2FC <- (log2(df5[3]) - log2(df5[4]))
    df6 <- df5
    # replace any Inf and -Inf values with 10 and -10 respectively
    df6[,6][df6[,6] == "Inf"] <- "10"
    df6[,6][df6[,6] == "-Inf"] <- "-10"
    return(df6)
}

# save the workspace
save.image(file = "table_1_functionsWS.Rdata")

# proceed to table_1_OTUs_format.R

############################
#### Table 1 OTUs Format ####
############################

# first set the working directory
setwd("~/Desktop/test/analysis/table_1/")

# read in the workspace from table_S3_functions
load("table_1_functionsWS.Rdata")

# read in differential abundance testing results
# there will be a lot of files here, don't panic
# Boston - colon
cBos_P07_KW <- read.table(file="otus/cBos_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW <- read.table(file="otus/cBos_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW <- read.table(file="otus/cBos_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT <- read.table(file="otus/cBos_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT <- read.table(file="otus/cBos_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT <- read.table(file="otus/cBos_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_GT <- read.table(file="otus/cBos_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_GT <- read.table(file="otus/cBos_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_GT <- read.table(file="otus/cBos_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - colon
cLar_P07_KW <- read.table(file="otus/cLar_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW <- read.table(file="otus/cLar_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW <- read.table(file="otus/cLar_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT <- read.table(file="otus/cLar_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT <- read.table(file="otus/cLar_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT <- read.table(file="otus/cLar_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_GT <- read.table(file="otus/cLar_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_GT <- read.table(file="otus/cLar_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_GT <- read.table(file="otus/cLar_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Boston - fecal
fBos_P07_KW <- read.table(file="otus/fBos_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW <- read.table(file="otus/fBos_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW <- read.table(file="otus/fBos_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT <- read.table(file="otus/fBos_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT <- read.table(file="otus/fBos_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT <- read.table(file="otus/fBos_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_GT <- read.table(file="otus/fBos_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_GT <- read.table(file="otus/fBos_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_GT <- read.table(file="otus/fBos_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - fecal
fLar_P07_KW <- read.table(file="otus/fLar_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW <- read.table(file="otus/fLar_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW <- read.table(file="otus/fLar_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT <- read.table(file="otus/fLar_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT <- read.table(file="otus/fLar_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT <- read.table(file="otus/fLar_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_GT <- read.table(file="otus/fLar_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_GT <- read.table(file="otus/fLar_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_GT <- read.table(file="otus/fLar_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)

require(dplyr)
# perform the GetSigsOTUs function
# Boston - colon
cBos_P07_KW <- GetSigsOTUs(cBos_P07_KW)
cBos_P20_KW <- GetSigsOTUs(cBos_P20_KW)
cBos_P24_KW <- GetSigsOTUs(cBos_P24_KW)
cBos_P07_NPT <- GetSigsOTUs(cBos_P07_NPT)
cBos_P20_NPT <- GetSigsOTUs(cBos_P20_NPT)
cBos_P24_NPT <- GetSigsOTUs(cBos_P24_NPT)
cBos_P07_GT <- GetSigsOTUs(cBos_P07_GT)
cBos_P20_GT <- GetSigsOTUs(cBos_P20_GT)
cBos_P24_GT <- GetSigsOTUs(cBos_P24_GT)
# Laramie - colon
cLar_P07_KW <- GetSigsOTUs(cLar_P07_KW)
cLar_P20_KW <- GetSigsOTUs(cLar_P20_KW)
cLar_P24_KW <- GetSigsOTUs(cLar_P24_KW)
cLar_P07_NPT <- GetSigsOTUs(cLar_P07_NPT)
cLar_P20_NPT <- GetSigsOTUs(cLar_P20_NPT)
cLar_P24_NPT <- GetSigsOTUs(cLar_P24_NPT)
cLar_P07_GT <- GetSigsOTUs(cLar_P07_GT)
cLar_P20_GT <- GetSigsOTUs(cLar_P20_GT)
cLar_P24_GT <- GetSigsOTUs(cLar_P24_GT)
# Boston - fecal
fBos_P07_KW <- GetSigsOTUs(fBos_P07_KW)
fBos_P20_KW <- GetSigsOTUs(fBos_P20_KW)
fBos_P24_KW <- GetSigsOTUs(fBos_P24_KW)
fBos_P07_NPT <- GetSigsOTUs(fBos_P07_NPT)
fBos_P20_NPT <- GetSigsOTUs(fBos_P20_NPT)
fBos_P24_NPT <- GetSigsOTUs(fBos_P24_NPT)
fBos_P07_GT <- GetSigsOTUs(fBos_P07_GT)
fBos_P20_GT <- GetSigsOTUs(fBos_P20_GT)
fBos_P24_GT <- GetSigsOTUs(fBos_P24_GT)
# Laramie - fecal
fLar_P07_KW <- GetSigsOTUs(fLar_P07_KW)
fLar_P20_KW <- GetSigsOTUs(fLar_P20_KW)
fLar_P24_KW <- GetSigsOTUs(fLar_P24_KW)
fLar_P07_NPT <- GetSigsOTUs(fLar_P07_NPT)
fLar_P20_NPT <- GetSigsOTUs(fLar_P20_NPT)
fLar_P24_NPT <- GetSigsOTUs(fLar_P24_NPT)
fLar_P07_GT <- GetSigsOTUs(fLar_P07_GT)
fLar_P20_GT <- GetSigsOTUs(fLar_P20_GT)
fLar_P24_GT <- GetSigsOTUs(fLar_P24_GT)

# add relevant metadata into appropriate columns
# Boston - colon
cBos_P07_KW$Facility <- "Boston"
cBos_P07_KW$Type <- "colon"
cBos_P07_KW$Test <- "krusk_wall"
cBos_P20_KW$Facility <- "Boston"
cBos_P20_KW$Type <- "colon"
cBos_P20_KW$Test <- "krusk_wall"
cBos_P24_KW$Facility <- "Boston"
cBos_P24_KW$Type <- "colon"
cBos_P24_KW$Test <- "krusk_wall"
cBos_P07_NPT$Facility <- "Boston"
cBos_P07_NPT$Type <- "colon"
cBos_P07_NPT$Test <- "nonparam-T"
cBos_P20_NPT$Facility <- "Boston"
cBos_P20_NPT$Type <- "colon"
cBos_P20_NPT$Test <- "nonparam-T"
cBos_P24_NPT$Facility <- "Boston"
cBos_P24_NPT$Type <- "colon"
cBos_P24_NPT$Test <- "nonparam-T"
cBos_P07_GT$Facility <- "Boston"
cBos_P07_GT$Type <- "colon"
cBos_P07_GT$Test <- "g-test"
cBos_P20_GT$Facility <- "Boston"
cBos_P20_GT$Type <- "colon"
cBos_P20_GT$Test <- "g-test"
cBos_P24_GT$Facility <- "Boston"
cBos_P24_GT$Type <- "colon"
cBos_P24_GT$Test <- "g-test"
# Laramie - colon
cLar_P07_KW$Facility <- "Laramie"
cLar_P07_KW$Type <- "colon"
cLar_P07_KW$Test <- "krusk_wall"
cLar_P20_KW$Facility <- "Laramie"
cLar_P20_KW$Type <- "colon"
cLar_P20_KW$Test <- "krusk_wall"
cLar_P24_KW$Facility <- "Laramie"
cLar_P24_KW$Type <- "colon"
cLar_P24_KW$Test <- "krusk_wall"
cLar_P07_NPT$Facility <- "Laramie"
cLar_P07_NPT$Type <- "colon"
cLar_P07_NPT$Test <- "nonparam-T"
cLar_P20_NPT$Facility <- "Laramie"
cLar_P20_NPT$Type <- "colon"
cLar_P20_NPT$Test <- "nonparam-T"
cLar_P24_NPT$Facility <- "Laramie"
cLar_P24_NPT$Type <- "colon"
cLar_P24_NPT$Test <- "nonparam-T"
cLar_P07_GT$Facility <- "Laramie"
cLar_P07_GT$Type <- "colon"
cLar_P07_GT$Test <- "g-test"
cLar_P20_GT$Facility <- "Laramie"
cLar_P20_GT$Type <- "colon"
cLar_P20_GT$Test <- "g-test"
cLar_P24_GT$Facility <- "Laramie"
cLar_P24_GT$Type <- "colon"
cLar_P24_GT$Test <- "g-test"
# Boston - fecal
fBos_P07_KW$Facility <- "Boston"
fBos_P07_KW$Type <- "fecal"
fBos_P07_KW$Test <- "krusk_wall"
fBos_P20_KW$Facility <- "Boston"
fBos_P20_KW$Type <- "fecal"
fBos_P20_KW$Test <- "krusk_wall"
fBos_P24_KW$Facility <- "Boston"
fBos_P24_KW$Type <- "fecal"
fBos_P24_KW$Test <- "krusk_wall"
fBos_P07_NPT$Facility <- "Boston"
fBos_P07_NPT$Type <- "fecal"
fBos_P07_NPT$Test <- "nonparam-T"
fBos_P20_NPT$Facility <- "Boston"
fBos_P20_NPT$Type <- "fecal"
fBos_P20_NPT$Test <- "nonparam-T"
fBos_P24_NPT$Facility <- "Boston"
fBos_P24_NPT$Type <- "fecal"
fBos_P24_NPT$Test <- "nonparam-T"
fBos_P07_GT$Facility <- "Boston"
fBos_P07_GT$Type <- "fecal"
fBos_P07_GT$Test <- "g-test"
fBos_P20_GT$Facility <- "Boston"
fBos_P20_GT$Type <- "fecal"
fBos_P20_GT$Test <- "g-test"
fBos_P24_GT$Facility <- "Boston"
fBos_P24_GT$Type <- "fecal"
fBos_P24_GT$Test <- "g-test"
# Laramie - fecal
fLar_P07_KW$Facility <- "Laramie"
fLar_P07_KW$Type <- "fecal"
fLar_P07_KW$Test <- "krusk_wall"
fLar_P20_KW$Facility <- "Laramie"
fLar_P20_KW$Type <- "fecal"
fLar_P20_KW$Test <- "krusk_wall"
fLar_P24_KW$Facility <- "Laramie"
fLar_P24_KW$Type <- "fecal"
fLar_P24_KW$Test <- "krusk_wall"
fLar_P07_NPT$Facility <- "Laramie"
fLar_P07_NPT$Type <- "fecal"
fLar_P07_NPT$Test <- "nonparam-T"
fLar_P20_NPT$Facility <- "Laramie"
fLar_P20_NPT$Type <- "fecal"
fLar_P20_NPT$Test <- "nonparam-T"
fLar_P24_NPT$Facility <- "Laramie"
fLar_P24_NPT$Type <- "fecal"
fLar_P24_NPT$Test <- "nonparam-T"
fLar_P07_GT$Facility <- "Laramie"
fLar_P07_GT$Type <- "fecal"
fLar_P07_GT$Test <- "g-test"
fLar_P20_GT$Facility <- "Laramie"
fLar_P20_GT$Type <- "fecal"
fLar_P20_GT$Test <- "g-test"
fLar_P24_GT$Facility <- "Laramie"
fLar_P24_GT$Type <- "fecal"
fLar_P24_GT$Test <- "g-test"

# Merge age- and type- matched dataframes from each Facility
# Then filter the merged df for NA's in two columns,
# This returns a df which retains OTUs that were present in both Facilities
# Finally, rbind the df by column to return our conserved candidates in a legible format

# P07 - colon
cdf07_KW <- merge(cBos_P07_KW,cLar_P07_KW, by="OTU", all=TRUE, sort=FALSE)
cdf07_KW <- cdf07_KW[!is.na(cdf07_KW$P.x) & !is.na(cdf07_KW$P.y),]
cdf07_KW <- rbind(cBos_P07_KW[cBos_P07_KW$OTU %in% cdf07_KW$OTU,], cLar_P07_KW[cLar_P07_KW$OTU %in% cdf07_KW$OTU,])
cdf07_NPT <- merge(cBos_P07_NPT,cLar_P07_NPT, by="OTU", all=TRUE, sort=FALSE)
cdf07_NPT <- cdf07_NPT[!is.na(cdf07_NPT$P.x) & !is.na(cdf07_NPT$P.y),]
cdf07_NPT <- rbind(cBos_P07_NPT[cBos_P07_NPT$OTU %in% cdf07_NPT$OTU,], cLar_P07_NPT[cLar_P07_NPT$OTU %in% cdf07_NPT$OTU,])
cdf07_GT <- merge(cBos_P07_GT,cLar_P07_GT, by="OTU", all=TRUE, sort=FALSE)
cdf07_GT <- cdf07_GT[!is.na(cdf07_GT$P.x) & !is.na(cdf07_GT$P.y),]
cdf07_GT <- rbind(cBos_P07_GT[cBos_P07_GT$OTU %in% cdf07_GT$OTU,], cLar_P07_GT[cLar_P07_GT$OTU %in% cdf07_GT$OTU,])
# P20 - colon
cdf20_KW <- merge(cBos_P20_KW,cLar_P20_KW, by="OTU", all=TRUE, sort=FALSE)
cdf20_KW <- cdf20_KW[!is.na(cdf20_KW$P.x) & !is.na(cdf20_KW$P.y),]
cdf20_KW <- rbind(cBos_P20_KW[cBos_P20_KW$OTU %in% cdf20_KW$OTU,], cLar_P20_KW[cLar_P20_KW$OTU %in% cdf20_KW$OTU,])
cdf20_NPT <- merge(cBos_P20_NPT,cLar_P20_NPT, by="OTU", all=TRUE, sort=FALSE)
cdf20_NPT <- cdf20_NPT[!is.na(cdf20_NPT$P.x) & !is.na(cdf20_NPT$P.y),]
cdf20_NPT <- rbind(cBos_P20_NPT[cBos_P20_NPT$OTU %in% cdf20_NPT$OTU,], cLar_P20_NPT[cLar_P20_NPT$OTU %in% cdf20_NPT$OTU,])
cdf20_GT <- merge(cBos_P20_GT,cLar_P20_GT, by="OTU", all=TRUE, sort=FALSE)
cdf20_GT <- cdf20_GT[!is.na(cdf20_GT$P.x) & !is.na(cdf20_GT$P.y),]
cdf20_GT <- rbind(cBos_P20_GT[cBos_P20_GT$OTU %in% cdf20_GT$OTU,], cLar_P20_GT[cLar_P20_GT$OTU %in% cdf20_GT$OTU,])
# P24 - colon
cdf24_KW <- merge(cBos_P24_KW,cLar_P24_KW, by="OTU", all=TRUE, sort=FALSE)
cdf24_KW <- cdf24_KW[!is.na(cdf24_KW$P.x) & !is.na(cdf24_KW$P.y),]
cdf24_KW <- rbind(cBos_P24_KW[cBos_P24_KW$OTU %in% cdf24_KW$OTU,], cLar_P24_KW[cLar_P24_KW$OTU %in% cdf24_KW$OTU,])
cdf24_NPT <- merge(cBos_P24_NPT,cLar_P24_NPT, by="OTU", all=TRUE, sort=FALSE)
cdf24_NPT <- cdf24_NPT[!is.na(cdf24_NPT$P.x) & !is.na(cdf24_NPT$P.y),]
cdf24_NPT <- rbind(cBos_P24_NPT[cBos_P24_NPT$OTU %in% cdf24_NPT$OTU,], cLar_P24_NPT[cLar_P24_NPT$OTU %in% cdf24_NPT$OTU,])
cdf24_GT <- merge(cBos_P24_GT,cLar_P24_GT, by="OTU", all=TRUE, sort=FALSE)
cdf24_GT <- cdf24_GT[!is.na(cdf24_GT$P.x) & !is.na(cdf24_GT$P.y),]
cdf24_GT <- rbind(cBos_P24_GT[cBos_P24_GT$OTU %in% cdf24_GT$OTU,], cLar_P24_GT[cLar_P24_GT$OTU %in% cdf24_GT$OTU,])
# P07 - fecal
fdf07_KW <- merge(fBos_P07_KW,fLar_P07_KW, by="OTU", all=TRUE, sort=FALSE)
fdf07_KW <- fdf07_KW[!is.na(fdf07_KW$P.x) & !is.na(fdf07_KW$P.y),]
fdf07_KW <- rbind(fBos_P07_KW[fBos_P07_KW$OTU %in% fdf07_KW$OTU,], fLar_P07_KW[fLar_P07_KW$OTU %in% fdf07_KW$OTU,])
fdf07_NPT <- merge(fBos_P07_NPT,fLar_P07_NPT, by="OTU", all=TRUE, sort=FALSE)
fdf07_NPT <- fdf07_NPT[!is.na(fdf07_NPT$P.x) & !is.na(fdf07_NPT$P.y),]
fdf07_NPT <- rbind(fBos_P07_NPT[fBos_P07_NPT$OTU %in% fdf07_NPT$OTU,], fLar_P07_NPT[fLar_P07_NPT$OTU %in% fdf07_NPT$OTU,])
fdf07_GT <- merge(fBos_P07_GT,fLar_P07_GT, by="OTU", all=TRUE, sort=FALSE)
fdf07_GT <- fdf07_GT[!is.na(fdf07_GT$P.x) & !is.na(fdf07_GT$P.y),]
fdf07_GT <- rbind(fBos_P07_GT[fBos_P07_GT$OTU %in% fdf07_GT$OTU,], fLar_P07_GT[fLar_P07_GT$OTU %in% fdf07_GT$OTU,])
# P20 - fecal
fdf20_KW <- merge(fBos_P20_KW,fLar_P20_KW, by="OTU", all=TRUE, sort=FALSE)
fdf20_KW <- fdf20_KW[!is.na(fdf20_KW$P.x) & !is.na(fdf20_KW$P.y),]
fdf20_KW <- rbind(fBos_P20_KW[fBos_P20_KW$OTU %in% fdf20_KW$OTU,], fLar_P20_KW[fLar_P20_KW$OTU %in% fdf20_KW$OTU,])
fdf20_NPT <- merge(fBos_P20_NPT,fLar_P20_NPT, by="OTU", all=TRUE, sort=FALSE)
fdf20_NPT <- fdf20_NPT[!is.na(fdf20_NPT$P.x) & !is.na(fdf20_NPT$P.y),]
fdf20_NPT <- rbind(fBos_P20_NPT[fBos_P20_NPT$OTU %in% fdf20_NPT$OTU,], fLar_P20_NPT[fLar_P20_NPT$OTU %in% fdf20_NPT$OTU,])
fdf20_GT <- merge(fBos_P20_GT,fLar_P20_GT, by="OTU", all=TRUE, sort=FALSE)
fdf20_GT <- fdf20_GT[!is.na(fdf20_GT$P.x) & !is.na(fdf20_GT$P.y),]
fdf20_GT <- rbind(fBos_P20_GT[fBos_P20_GT$OTU %in% fdf20_GT$OTU,], fLar_P20_GT[fLar_P20_GT$OTU %in% fdf20_GT$OTU,])
# P24 - fecal
fdf24_KW <- merge(fBos_P24_KW,fLar_P24_KW, by="OTU", all=TRUE, sort=FALSE)
fdf24_KW <- fdf24_KW[!is.na(fdf24_KW$P.x) & !is.na(fdf24_KW$P.y),]
fdf24_KW <- rbind(fBos_P24_KW[fBos_P24_KW$OTU %in% fdf24_KW$OTU,], fLar_P24_KW[fLar_P24_KW$OTU %in% fdf24_KW$OTU,])
fdf24_NPT <- merge(fBos_P24_NPT,fLar_P24_NPT, by="OTU", all=TRUE, sort=FALSE)
fdf24_NPT <- fdf24_NPT[!is.na(fdf24_NPT$P.x) & !is.na(fdf24_NPT$P.y),]
fdf24_NPT <- rbind(fBos_P24_NPT[fBos_P24_NPT$OTU %in% fdf24_NPT$OTU,], fLar_P24_NPT[fLar_P24_NPT$OTU %in% fdf24_NPT$OTU,])
fdf24_GT <- merge(fBos_P24_GT,fLar_P24_GT, by="OTU", all=TRUE, sort=FALSE)
fdf24_GT <- fdf24_GT[!is.na(fdf24_GT$P.x) & !is.na(fdf24_GT$P.y),]
fdf24_GT <- rbind(fBos_P24_GT[fBos_P24_GT$OTU %in% fdf24_GT$OTU,], fLar_P24_GT[fLar_P24_GT$OTU %in% fdf24_GT$OTU,])

# combine (rbind) each age-test-type dataframe
# and then sort by Age and OTU
# colon
cdf <- rbind(cdf07_KW, cdf07_NPT, cdf07_GT,
cdf20_KW, cdf20_NPT, cdf20_GT,
cdf24_KW, cdf24_NPT, cdf24_GT)
cdf <- cdf[order(cdf$Age, cdf$OTU),]

# fecal
fdf <- rbind(fdf07_KW, fdf07_NPT, fdf07_GT,
fdf20_KW, fdf20_NPT, fdf20_GT,
fdf24_KW, fdf24_NPT, fdf24_GT)
fdf <- fdf[order(fdf$Age, fdf$OTU),]

# finally, merge cdf and fdf
# and then sort by Age and OTU
cons_otus <- rbind(cdf,fdf)
cons_otus <- cons_otus[order(cons_otus$Age, cons_otus$OTU),]

# save tables and workspace
setwd("~/Desktop/test/analysis/table_1/")
write.table(cdf, file = "cdf_cons_otus.txt", sep="\t", row.names = FALSE)
write.table(fdf, file = "fdf_cons_otus.txt", sep="\t", row.names = FALSE)
write.table(cons_otus, file = "cons_otus.txt", sep="\t", row.names = FALSE)
save.image(file = "table_1_OTUsformat.Rdata")

# proceed to table_1_taxa_format.R
############################
#### Table 1 Taxa Format ####
############################

# first set the working directory
setwd("~/Desktop/test/analysis/table_1/")

# read in the workspace from table_S3_functions
load("table_1_functionsWS.Rdata")

# read in differential abundance testing results
# there will be a lot of files here, don't panic
# Boston - colon
cBos_P07_KW_L2 <- read.table(file="taxa/cBos_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW_L2 <- read.table(file="taxa/cBos_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW_L2 <- read.table(file="taxa/cBos_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_KW_L6 <- read.table(file="taxa/cBos_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW_L6 <- read.table(file="taxa/cBos_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW_L6 <- read.table(file="taxa/cBos_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT_L2 <- read.table(file="taxa/cBos_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT_L2 <- read.table(file="taxa/cBos_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT_L2 <- read.table(file="taxa/cBos_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT_L6 <- read.table(file="taxa/cBos_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT_L6 <- read.table(file="taxa/cBos_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT_L6 <- read.table(file="taxa/cBos_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - colon
cLar_P07_KW_L2 <- read.table(file="taxa/cLar_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW_L2 <- read.table(file="taxa/cLar_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW_L2 <- read.table(file="taxa/cLar_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_KW_L6 <- read.table(file="taxa/cLar_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW_L6 <- read.table(file="taxa/cLar_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW_L6 <- read.table(file="taxa/cLar_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT_L2 <- read.table(file="taxa/cLar_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT_L2 <- read.table(file="taxa/cLar_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT_L2 <- read.table(file="taxa/cLar_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT_L6 <- read.table(file="taxa/cLar_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT_L6 <- read.table(file="taxa/cLar_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT_L6 <- read.table(file="taxa/cLar_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Boston - fecal
fBos_P07_KW_L2 <- read.table(file="taxa/fBos_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW_L2 <- read.table(file="taxa/fBos_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW_L2 <- read.table(file="taxa/fBos_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_KW_L6 <- read.table(file="taxa/fBos_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW_L6 <- read.table(file="taxa/fBos_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW_L6 <- read.table(file="taxa/fBos_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT_L2 <- read.table(file="taxa/fBos_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT_L2 <- read.table(file="taxa/fBos_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT_L2 <- read.table(file="taxa/fBos_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT_L6 <- read.table(file="taxa/fBos_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT_L6 <- read.table(file="taxa/fBos_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT_L6 <- read.table(file="taxa/fBos_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - fecal
fLar_P07_KW_L2 <- read.table(file="taxa/fLar_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW_L2 <- read.table(file="taxa/fLar_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW_L2 <- read.table(file="taxa/fLar_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_KW_L6 <- read.table(file="taxa/fLar_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW_L6 <- read.table(file="taxa/fLar_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW_L6 <- read.table(file="taxa/fLar_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT_L2 <- read.table(file="taxa/fLar_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT_L2 <- read.table(file="taxa/fLar_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT_L2 <- read.table(file="taxa/fLar_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT_L6 <- read.table(file="taxa/fLar_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT_L6 <- read.table(file="taxa/fLar_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT_L6 <- read.table(file="taxa/fLar_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)

require(dplyr)
# perform the GetSigsTaxa function
# Boston - colon
cBos_P07_KW_L2 <- GetSigsTaxa(cBos_P07_KW_L2)
cBos_P20_KW_L2 <- GetSigsTaxa(cBos_P20_KW_L2)
cBos_P24_KW_L2 <- GetSigsTaxa(cBos_P24_KW_L2)
cBos_P07_KW_L6 <- GetSigsTaxa(cBos_P07_KW_L6)
cBos_P20_KW_L6 <- GetSigsTaxa(cBos_P20_KW_L6)
cBos_P24_KW_L6 <- GetSigsTaxa(cBos_P24_KW_L6)
cBos_P07_NPT_L2 <- GetSigsTaxa(cBos_P07_NPT_L2)
cBos_P20_NPT_L2 <- GetSigsTaxa(cBos_P20_NPT_L2)
cBos_P24_NPT_L2 <- GetSigsTaxa(cBos_P24_NPT_L2)
cBos_P07_NPT_L6 <- GetSigsTaxa(cBos_P07_NPT_L6)
cBos_P20_NPT_L6 <- GetSigsTaxa(cBos_P20_NPT_L6)
cBos_P24_NPT_L6 <- GetSigsTaxa(cBos_P24_NPT_L6)
# Laramie - colon
cLar_P07_KW_L2 <- GetSigsTaxa(cLar_P07_KW_L2)
cLar_P20_KW_L2 <- GetSigsTaxa(cLar_P20_KW_L2)
cLar_P24_KW_L2 <- GetSigsTaxa(cLar_P24_KW_L2)
cLar_P07_KW_L6 <- GetSigsTaxa(cLar_P07_KW_L6)
cLar_P20_KW_L6 <- GetSigsTaxa(cLar_P20_KW_L6)
cLar_P24_KW_L6 <- GetSigsTaxa(cLar_P24_KW_L6)
cLar_P07_NPT_L2 <- GetSigsTaxa(cLar_P07_NPT_L2)
cLar_P20_NPT_L2 <- GetSigsTaxa(cLar_P20_NPT_L2)
cLar_P24_NPT_L2 <- GetSigsTaxa(cLar_P24_NPT_L2)
cLar_P07_NPT_L6 <- GetSigsTaxa(cLar_P07_NPT_L6)
cLar_P20_NPT_L6 <- GetSigsTaxa(cLar_P20_NPT_L6)
cLar_P24_NPT_L6 <- GetSigsTaxa(cLar_P24_NPT_L6)
# Boston - fecal
fBos_P07_KW_L2 <- GetSigsTaxa(fBos_P07_KW_L2)
fBos_P20_KW_L2 <- GetSigsTaxa(fBos_P20_KW_L2)
fBos_P24_KW_L2 <- GetSigsTaxa(fBos_P24_KW_L2)
fBos_P07_KW_L6 <- GetSigsTaxa(fBos_P07_KW_L6)
fBos_P20_KW_L6 <- GetSigsTaxa(fBos_P20_KW_L6)
fBos_P24_KW_L6 <- GetSigsTaxa(fBos_P24_KW_L6)
fBos_P07_NPT_L2 <- GetSigsTaxa(fBos_P07_NPT_L2)
fBos_P20_NPT_L2 <- GetSigsTaxa(fBos_P20_NPT_L2)
fBos_P24_NPT_L2 <- GetSigsTaxa(fBos_P24_NPT_L2)
fBos_P07_NPT_L6 <- GetSigsTaxa(fBos_P07_NPT_L6)
fBos_P20_NPT_L6 <- GetSigsTaxa(fBos_P20_NPT_L6)
fBos_P24_NPT_L6 <- GetSigsTaxa(fBos_P24_NPT_L6)
# Laramie - fecal
fLar_P07_KW_L2 <- GetSigsTaxa(fLar_P07_KW_L2)
fLar_P20_KW_L2 <- GetSigsTaxa(fLar_P20_KW_L2)
fLar_P24_KW_L2 <- GetSigsTaxa(fLar_P24_KW_L2)
fLar_P07_KW_L6 <- GetSigsTaxa(fLar_P07_KW_L6)
fLar_P20_KW_L6 <- GetSigsTaxa(fLar_P20_KW_L6)
fLar_P24_KW_L6 <- GetSigsTaxa(fLar_P24_KW_L6)
fLar_P07_NPT_L2 <- GetSigsTaxa(fLar_P07_NPT_L2)
fLar_P20_NPT_L2 <- GetSigsTaxa(fLar_P20_NPT_L2)
fLar_P24_NPT_L2 <- GetSigsTaxa(fLar_P24_NPT_L2)
fLar_P07_NPT_L6 <- GetSigsTaxa(fLar_P07_NPT_L6)
fLar_P20_NPT_L6 <- GetSigsTaxa(fLar_P20_NPT_L6)
fLar_P24_NPT_L6 <- GetSigsTaxa(fLar_P24_NPT_L6)

# add relevant metadata into appropriate columns
# Boston - colon
cBos_P07_KW_L2$Facility <- "Boston"
cBos_P07_KW_L2$Type <- "colon"
cBos_P07_KW_L2$Test <- "krusk-wall"
cBos_P20_KW_L2$Facility <- "Boston"
cBos_P20_KW_L2$Type <- "colon"
cBos_P20_KW_L2$Test <- "krusk-wall"
cBos_P24_KW_L2$Facility <- "Boston"
cBos_P24_KW_L2$Type <- "colon"
cBos_P24_KW_L2$Test <- "krusk-wall"
cBos_P07_KW_L6$Facility <- "Boston"
cBos_P07_KW_L6$Type <- "colon"
cBos_P07_KW_L6$Test <- "krusk-wall"
cBos_P20_KW_L6$Facility <- "Boston"
cBos_P20_KW_L6$Type <- "colon"
cBos_P20_KW_L6$Test <- "krusk-wall"
cBos_P24_KW_L6$Facility <- "Boston"
cBos_P24_KW_L6$Type <- "colon"
cBos_P24_KW_L6$Test <- "krusk-wall"
cBos_P07_NPT_L2$Facility <- "Boston"
cBos_P07_NPT_L2$Type <- "colon"
cBos_P07_NPT_L2$Test <- "nonparam-T"
cBos_P20_NPT_L2$Facility <- "Boston"
cBos_P20_NPT_L2$Type <- "colon"
cBos_P20_NPT_L2$Test <- "nonparam-T"
cBos_P24_NPT_L2$Facility <- "Boston"
cBos_P24_NPT_L2$Type <- "colon"
cBos_P24_NPT_L2$Test <- "nonparam-T"
cBos_P07_NPT_L6$Facility <- "Boston"
cBos_P07_NPT_L6$Type <- "colon"
cBos_P07_NPT_L6$Test <- "nonparam-T"
cBos_P20_NPT_L6$Facility <- "Boston"
cBos_P20_NPT_L6$Type <- "colon"
cBos_P20_NPT_L6$Test <- "nonparam-T"
cBos_P24_NPT_L6$Facility <- "Boston"
cBos_P24_NPT_L6$Type <- "colon"
cBos_P24_NPT_L6$Test <- "nonparam-T"
# Laramie - colon
cLar_P07_KW_L2$Facility <- "Laramie"
cLar_P07_KW_L2$Type <- "colon"
cLar_P07_KW_L2$Test <- "krusk-wall"
cLar_P20_KW_L2$Facility <- "Laramie"
cLar_P20_KW_L2$Type <- "colon"
cLar_P20_KW_L2$Test <- "krusk-wall"
cLar_P24_KW_L2$Facility <- "Laramie"
cLar_P24_KW_L2$Type <- "colon"
cLar_P24_KW_L2$Test <- "krusk-wall"
cLar_P07_KW_L6$Facility <- "Laramie"
cLar_P07_KW_L6$Type <- "colon"
cLar_P07_KW_L6$Test <- "krusk-wall"
cLar_P20_KW_L6$Facility <- "Laramie"
cLar_P20_KW_L6$Type <- "colon"
cLar_P20_KW_L6$Test <- "krusk-wall"
cLar_P24_KW_L6$Facility <- "Laramie"
cLar_P24_KW_L6$Type <- "colon"
cLar_P24_KW_L6$Test <- "krusk-wall"
cLar_P07_NPT_L2$Facility <- "Laramie"
cLar_P07_NPT_L2$Type <- "colon"
cLar_P07_NPT_L2$Test <- "nonparam-T"
cLar_P20_NPT_L2$Facility <- "Laramie"
cLar_P20_NPT_L2$Type <- "colon"
cLar_P20_NPT_L2$Test <- "nonparam-T"
cLar_P24_NPT_L2$Facility <- "Laramie"
cLar_P24_NPT_L2$Type <- "colon"
cLar_P24_NPT_L2$Test <- "nonparam-T"
cLar_P07_NPT_L6$Facility <- "Laramie"
cLar_P07_NPT_L6$Type <- "colon"
cLar_P07_NPT_L6$Test <- "nonparam-T"
cLar_P20_NPT_L6$Facility <- "Laramie"
cLar_P20_NPT_L6$Type <- "colon"
cLar_P20_NPT_L6$Test <- "nonparam-T"
cLar_P24_NPT_L6$Facility <- "Laramie"
cLar_P24_NPT_L6$Type <- "colon"
cLar_P24_NPT_L6$Test <- "nonparam-T"
# Boston - fecal
fBos_P07_KW_L2$Facility <- "Boston"
fBos_P07_KW_L2$Type <- "fecal"
fBos_P07_KW_L2$Test <- "krusk-wall"
fBos_P20_KW_L2$Facility <- "Boston"
fBos_P20_KW_L2$Type <- "fecal"
fBos_P20_KW_L2$Test <- "krusk-wall"
fBos_P24_KW_L2$Facility <- "Boston"
fBos_P24_KW_L2$Type <- "fecal"
fBos_P24_KW_L2$Test <- "krusk-wall"
fBos_P07_KW_L6$Facility <- "Boston"
fBos_P07_KW_L6$Type <- "fecal"
fBos_P07_KW_L6$Test <- "krusk-wall"
fBos_P20_KW_L6$Facility <- "Boston"
fBos_P20_KW_L6$Type <- "fecal"
fBos_P20_KW_L6$Test <- "krusk-wall"
fBos_P24_KW_L6$Facility <- "Boston"
fBos_P24_KW_L6$Type <- "fecal"
fBos_P24_KW_L6$Test <- "krusk-wall"
fBos_P07_NPT_L2$Facility <- "Boston"
fBos_P07_NPT_L2$Type <- "fecal"
fBos_P07_NPT_L2$Test <- "nonparam-T"
fBos_P20_NPT_L2$Facility <- "Boston"
fBos_P20_NPT_L2$Type <- "fecal"
fBos_P20_NPT_L2$Test <- "nonparam-T"
fBos_P24_NPT_L2$Facility <- "Boston"
fBos_P24_NPT_L2$Type <- "fecal"
fBos_P24_NPT_L2$Test <- "nonparam-T"
fBos_P07_NPT_L6$Facility <- "Boston"
fBos_P07_NPT_L6$Type <- "fecal"
fBos_P07_NPT_L6$Test <- "nonparam-T"
fBos_P20_NPT_L6$Facility <- "Boston"
fBos_P20_NPT_L6$Type <- "fecal"
fBos_P20_NPT_L6$Test <- "nonparam-T"
fBos_P24_NPT_L6$Facility <- "Boston"
fBos_P24_NPT_L6$Type <- "fecal"
fBos_P24_NPT_L6$Test <- "nonparam-T"
# Laramie - fecal
fLar_P07_KW_L2$Facility <- "Laramie"
fLar_P07_KW_L2$Type <- "fecal"
fLar_P07_KW_L2$Test <- "krusk-wall"

fLar_P20_KW_L2$Facility <- "Laramie"
fLar_P20_KW_L2$Type <- "fecal"
fLar_P20_KW_L2$Test <- "krusk-wall"
fLar_P24_KW_L2$Facility <- "Laramie"
fLar_P24_KW_L2$Type <- "fecal"
fLar_P24_KW_L2$Test <- "krusk-wall"
fLar_P07_KW_L6$Facility <- "Laramie"
fLar_P07_KW_L6$Type <- "fecal"
fLar_P07_KW_L6$Test <- "krusk-wall"
fLar_P20_KW_L6$Facility <- "Laramie"
fLar_P20_KW_L6$Type <- "fecal"
fLar_P20_KW_L6$Test <- "krusk-wall"
fLar_P24_KW_L6$Facility <- "Laramie"
fLar_P24_KW_L6$Type <- "fecal"
fLar_P24_KW_L6$Test <- "krusk-wall"
fLar_P07_NPT_L2$Facility <- "Laramie"
fLar_P07_NPT_L2$Type <- "fecal"
fLar_P07_NPT_L2$Test <- "nonparam-T"
fLar_P20_NPT_L2$Facility <- "Laramie"
fLar_P20_NPT_L2$Type <- "fecal"
fLar_P20_NPT_L2$Test <- "nonparam-T"
fLar_P24_NPT_L2$Facility <- "Laramie"
fLar_P24_NPT_L2$Type <- "fecal"
fLar_P24_NPT_L2$Test <- "nonparam-T"
fLar_P07_NPT_L6$Facility <- "Laramie"
fLar_P07_NPT_L6$Type <- "fecal"
fLar_P07_NPT_L6$Test <- "nonparam-T"
fLar_P20_NPT_L6$Facility <- "Laramie"
fLar_P20_NPT_L6$Type <- "fecal"
fLar_P20_NPT_L6$Test <- "nonparam-T"
fLar_P24_NPT_L6$Facility <- "Laramie"
fLar_P24_NPT_L6$Type <- "fecal"
fLar_P24_NPT_L6$Test <- "nonparam-T"

# Merge age- and type- matched dataframes from each Facility
# Then filter the merged df for NA's in two columns,
# This returns a df which retains OTUs that were present in both Facilities
# Finally, rbind the df by column to return our conserved candidates in a legible format

# P07 - colon
cdf07_KW_L2 <- merge(cBos_P07_KW_L2,cLar_P07_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf07_KW_L2 <- cdf07_KW_L2[!is.na(cdf07_KW_L2$P.x) & !is.na(cdf07_KW_L2$P.y),]
cdf07_KW_L2 <- rbind(cBos_P07_KW_L2[cBos_P07_KW_L2$Taxon %in% cdf07_KW_L2$Taxon,],
cLar_P07_KW_L2[cLar_P07_KW_L2$Taxon %in% cdf07_KW_L2$Taxon,])
cdf07_KW_L6 <- merge(cBos_P07_KW_L6,cLar_P07_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf07_KW_L6 <- cdf07_KW_L6[!is.na(cdf07_KW_L6$P.x) & !is.na(cdf07_KW_L6$P.y),]
cdf07_KW_L6 <- rbind(cBos_P07_KW_L6[cBos_P07_KW_L6$Taxon %in% cdf07_KW_L6$Taxon,],
cLar_P07_KW_L6[cLar_P07_KW_L6$Taxon %in% cdf07_KW_L6$Taxon,])
cdf07_NPT_L2 <- merge(cBos_P07_NPT_L2,cLar_P07_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf07_NPT_L2 <- cdf07_NPT_L2[!is.na(cdf07_NPT_L2$P.x) & !is.na(cdf07_NPT_L2$P.y),]
cdf07_NPT_L2 <- rbind(cBos_P07_NPT_L2[cBos_P07_NPT_L2$Taxon %in% cdf07_NPT_L2$Taxon,],
cLar_P07_NPT_L2[cLar_P07_NPT_L2$Taxon %in% cdf07_NPT_L2$Taxon,])
cdf07_NPT_L6 <- merge(cBos_P07_NPT_L6,cLar_P07_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf07_NPT_L6 <- cdf07_NPT_L6[!is.na(cdf07_NPT_L6$P.x) & !is.na(cdf07_NPT_L6$P.y),]
cdf07_NPT_L6 <- rbind(cBos_P07_NPT_L6[cBos_P07_NPT_L6$Taxon %in% cdf07_NPT_L6$Taxon,],
cLar_P07_NPT_L6[cLar_P07_NPT_L6$Taxon %in% cdf07_NPT_L6$Taxon,])
# P20 - colon
cdf20_KW_L2 <- merge(cBos_P20_KW_L2,cLar_P20_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf20_KW_L2 <- cdf20_KW_L2[!is.na(cdf20_KW_L2$P.x) & !is.na(cdf20_KW_L2$P.y),]
cdf20_KW_L2 <- rbind(cBos_P20_KW_L2[cBos_P20_KW_L2$Taxon %in% cdf20_KW_L2$Taxon,],
cLar_P20_KW_L2[cLar_P20_KW_L2$Taxon %in% cdf20_KW_L2$Taxon,])
cdf20_KW_L6 <- merge(cBos_P20_KW_L6,cLar_P20_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf20_KW_L6 <- cdf20_KW_L6[!is.na(cdf20_KW_L6$P.x) & !is.na(cdf20_KW_L6$P.y),]
cdf20_KW_L6 <- rbind(cBos_P20_KW_L6[cBos_P20_KW_L6$Taxon %in% cdf20_KW_L6$Taxon,],
cLar_P20_KW_L6[cLar_P20_KW_L6$Taxon %in% cdf20_KW_L6$Taxon,])
cdf20_NPT_L2 <- merge(cBos_P20_NPT_L2,cLar_P20_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf20_NPT_L2 <- cdf20_NPT_L2[!is.na(cdf20_NPT_L2$P.x) & !is.na(cdf20_NPT_L2$P.y),]
cdf20_NPT_L2 <- rbind(cBos_P20_NPT_L2[cBos_P20_NPT_L2$Taxon %in% cdf20_NPT_L2$Taxon,],
cLar_P20_NPT_L2[cLar_P20_NPT_L2$Taxon %in% cdf20_NPT_L2$Taxon,])
cdf20_NPT_L6 <- merge(cBos_P20_NPT_L6,cLar_P20_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf20_NPT_L6 <- cdf20_NPT_L6[!is.na(cdf20_NPT_L6$P.x) & !is.na(cdf20_NPT_L6$P.y),]
cdf20_NPT_L6 <- rbind(cBos_P20_NPT_L6[cBos_P20_NPT_L6$Taxon %in% cdf20_NPT_L6$Taxon,],
cLar_P20_NPT_L6[cLar_P20_NPT_L6$Taxon %in% cdf20_NPT_L6$Taxon,])
# P24 - colon
cdf24_KW_L2 <- merge(cBos_P24_KW_L2,cLar_P24_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf24_KW_L2 <- cdf24_KW_L2[!is.na(cdf24_KW_L2$P.x) & !is.na(cdf24_KW_L2$P.y),]
cdf24_KW_L2 <- rbind(cBos_P24_KW_L2[cBos_P24_KW_L2$Taxon %in% cdf24_KW_L2$Taxon,],
cLar_P24_KW_L2[cLar_P24_KW_L2$Taxon %in% cdf24_KW_L2$Taxon,])
cdf24_KW_L6 <- merge(cBos_P24_KW_L6,cLar_P24_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf24_KW_L6 <- cdf24_KW_L6[!is.na(cdf24_KW_L6$P.x) & !is.na(cdf24_KW_L6$P.y),]
cdf24_KW_L6 <- rbind(cBos_P24_KW_L6[cBos_P24_KW_L6$Taxon %in% cdf24_KW_L6$Taxon,],
cLar_P24_KW_L6[cLar_P24_KW_L6$Taxon %in% cdf24_KW_L6$Taxon,])
cdf24_NPT_L2 <- merge(cBos_P24_NPT_L2,cLar_P24_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
cdf24_NPT_L2 <- cdf24_NPT_L2[!is.na(cdf24_NPT_L2$P.x) & !is.na(cdf24_NPT_L2$P.y),]
cdf24_NPT_L2 <- rbind(cBos_P24_NPT_L2[cBos_P24_NPT_L2$Taxon %in% cdf24_NPT_L2$Taxon,],
cLar_P24_NPT_L2[cLar_P24_NPT_L2$Taxon %in% cdf24_NPT_L2$Taxon,])
cdf24_NPT_L6 <- merge(cBos_P24_NPT_L6,cLar_P24_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
cdf24_NPT_L6 <- cdf24_NPT_L6[!is.na(cdf24_NPT_L6$P.x) & !is.na(cdf24_NPT_L6$P.y),]
cdf24_NPT_L6 <- rbind(cBos_P24_NPT_L6[cBos_P24_NPT_L6$Taxon %in% cdf24_NPT_L6$Taxon,],
cLar_P24_NPT_L6[cLar_P24_NPT_L6$Taxon %in% cdf24_NPT_L6$Taxon,])
# P07 - fecal
fdf07_KW_L2 <- merge(fBos_P07_KW_L2,fLar_P07_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf07_KW_L2 <- fdf07_KW_L2[!is.na(fdf07_KW_L2$P.x) & !is.na(fdf07_KW_L2$P.y),]
fdf07_KW_L2 <- rbind(fBos_P07_KW_L2[fBos_P07_KW_L2$Taxon %in% fdf07_KW_L2$Taxon,],
fLar_P07_KW_L2[fLar_P07_KW_L2$Taxon %in% fdf07_KW_L2$Taxon,])
fdf07_KW_L6 <- merge(fBos_P07_KW_L6,fLar_P07_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf07_KW_L6 <- fdf07_KW_L6[!is.na(fdf07_KW_L6$P.x) & !is.na(fdf07_KW_L6$P.y),]
fdf07_KW_L6 <- rbind(fBos_P07_KW_L6[fBos_P07_KW_L6$Taxon %in% fdf07_KW_L6$Taxon,],
fLar_P07_KW_L6[fLar_P07_KW_L6$Taxon %in% fdf07_KW_L6$Taxon,])
fdf07_NPT_L2 <- merge(fBos_P07_NPT_L2,fLar_P07_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf07_NPT_L2 <- fdf07_NPT_L2[!is.na(fdf07_NPT_L2$P.x) & !is.na(fdf07_NPT_L2$P.y),]
fdf07_NPT_L2 <- rbind(fBos_P07_NPT_L2[fBos_P07_NPT_L2$Taxon %in% fdf07_NPT_L2$Taxon,],
fLar_P07_NPT_L2[fLar_P07_NPT_L2$Taxon %in% fdf07_NPT_L2$Taxon,])
fdf07_NPT_L6 <- merge(fBos_P07_NPT_L6,fLar_P07_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf07_NPT_L6 <- fdf07_NPT_L6[!is.na(fdf07_NPT_L6$P.x) & !is.na(fdf07_NPT_L6$P.y),]
fdf07_NPT_L6 <- rbind(fBos_P07_NPT_L6[fBos_P07_NPT_L6$Taxon %in% fdf07_NPT_L6$Taxon,],
fLar_P07_NPT_L6[fLar_P07_NPT_L6$Taxon %in% fdf07_NPT_L6$Taxon,])
# P20 - fecal
fdf20_KW_L2 <- merge(fBos_P20_KW_L2,fLar_P20_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf20_KW_L2 <- fdf20_KW_L2[!is.na(fdf20_KW_L2$P.x) & !is.na(fdf20_KW_L2$P.y),]
fdf20_KW_L2 <- rbind(fBos_P20_KW_L2[fBos_P20_KW_L2$Taxon %in% fdf20_KW_L2$Taxon,],
fLar_P20_KW_L2[fLar_P20_KW_L2$Taxon %in% fdf20_KW_L2$Taxon,])
fdf20_KW_L6 <- merge(fBos_P20_KW_L6,fLar_P20_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf20_KW_L6 <- fdf20_KW_L6[!is.na(fdf20_KW_L6$P.x) & !is.na(fdf20_KW_L6$P.y),]
fdf20_KW_L6 <- rbind(fBos_P20_KW_L6[fBos_P20_KW_L6$Taxon %in% fdf20_KW_L6$Taxon,],
fLar_P20_KW_L6[fLar_P20_KW_L6$Taxon %in% fdf20_KW_L6$Taxon,])
fdf20_NPT_L2 <- merge(fBos_P20_NPT_L2,fLar_P20_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf20_NPT_L2 <- fdf20_NPT_L2[!is.na(fdf20_NPT_L2$P.x) & !is.na(fdf20_NPT_L2$P.y),]
fdf20_NPT_L2 <- rbind(fBos_P20_NPT_L2[fBos_P20_NPT_L2$Taxon %in% fdf20_NPT_L2$Taxon,],
fLar_P20_NPT_L2[fLar_P20_NPT_L2$Taxon %in% fdf20_NPT_L2$Taxon,])
fdf20_NPT_L6 <- merge(fBos_P20_NPT_L6,fLar_P20_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf20_NPT_L6 <- fdf20_NPT_L6[!is.na(fdf20_NPT_L6$P.x) & !is.na(fdf20_NPT_L6$P.y),]
fdf20_NPT_L6 <- rbind(fBos_P20_NPT_L6[fBos_P20_NPT_L6$Taxon %in% fdf20_NPT_L6$Taxon,],
fLar_P20_NPT_L6[fLar_P20_NPT_L6$Taxon %in% fdf20_NPT_L6$Taxon,])
# P24 - fecal
fdf24_KW_L2 <- merge(fBos_P24_KW_L2,fLar_P24_KW_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf24_KW_L2 <- fdf24_KW_L2[!is.na(fdf24_KW_L2$P.x) & !is.na(fdf24_KW_L2$P.y),]
fdf24_KW_L2 <- rbind(fBos_P24_KW_L2[fBos_P24_KW_L2$Taxon %in% fdf24_KW_L2$Taxon,],
fLar_P24_KW_L2[fLar_P24_KW_L2$Taxon %in% fdf24_KW_L2$Taxon,])
fdf24_KW_L6 <- merge(fBos_P24_KW_L6,fLar_P24_KW_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf24_KW_L6 <- fdf24_KW_L6[!is.na(fdf24_KW_L6$P.x) & !is.na(fdf24_KW_L6$P.y),]
fdf24_KW_L6 <- rbind(fBos_P24_KW_L6[fBos_P24_KW_L6$Taxon %in% fdf24_KW_L6$Taxon,],
fLar_P24_KW_L6[fLar_P24_KW_L6$Taxon %in% fdf24_KW_L6$Taxon,])
fdf24_NPT_L2 <- merge(fBos_P24_NPT_L2,fLar_P24_NPT_L2, by="Taxon", all=TRUE, sort=FALSE)
fdf24_NPT_L2 <- fdf24_NPT_L2[!is.na(fdf24_NPT_L2$P.x) & !is.na(fdf24_NPT_L2$P.y),]
fdf24_NPT_L2 <- rbind(fBos_P24_NPT_L2[fBos_P24_NPT_L2$Taxon %in% fdf24_NPT_L2$Taxon,],
fLar_P24_NPT_L2[fLar_P24_NPT_L2$Taxon %in% fdf24_NPT_L2$Taxon,])
fdf24_NPT_L6 <- merge(fBos_P24_NPT_L6,fLar_P24_NPT_L6, by="Taxon", all=TRUE, sort=FALSE)
fdf24_NPT_L6 <- fdf24_NPT_L6[!is.na(fdf24_NPT_L6$P.x) & !is.na(fdf24_NPT_L6$P.y),]
fdf24_NPT_L6 <- rbind(fBos_P24_NPT_L6[fBos_P24_NPT_L6$Taxon %in% fdf24_NPT_L6$Taxon,],
fLar_P24_NPT_L6[fLar_P24_NPT_L6$Taxon %in% fdf24_NPT_L6$Taxon,])

# combine (rbind) each age-test-type dataframe
# and then sort by Age and Taxon
# remove any rows that contain values of 1 in the Age column
# colon
cdf <- rbind(cdf07_KW_L2, cdf07_KW_L6, cdf07_NPT_L2, cdf07_NPT_L6,
cdf20_KW_L2, cdf20_KW_L6, cdf20_NPT_L2, cdf20_NPT_L6,
cdf24_KW_L2, cdf24_KW_L6, cdf24_NPT_L2, cdf24_NPT_L6)
cdf <- cdf[order(cdf$Age, cdf$Taxon),]
killrow <- which(cdf$Age == 1)
cdf <- cdf[- c(killrow),]
# fecal
fdf <- rbind(fdf07_KW_L2, fdf07_KW_L6, fdf07_NPT_L2, fdf07_NPT_L6,
fdf20_KW_L2, fdf20_KW_L6, fdf20_NPT_L2, fdf20_NPT_L6,
fdf24_KW_L2, fdf24_KW_L6, fdf24_NPT_L2, fdf24_NPT_L6)
fdf <- fdf[order(fdf$Age, fdf$Taxon),]
killrow <- which(fdf$Age == 1)
fdf <- fdf[- c(killrow),]

# finally, merge cdf and fdf
# and then sort by Age and Taxon
cons_taxa <- rbind(cdf,fdf)
cons_taxa <- cons_taxa[order(cons_taxa$Age, cons_taxa$Taxon),]

# save tables and workspace
setwd("~/Desktop/test/analysis/table_1/")
write.table(cdf, file = "cdf_cons_taxa.txt", sep="\t", row.names = FALSE)
write.table(fdf, file = "fdf_cons_taxa.txt", sep="\t", row.names = FALSE)
write.table(cons_taxa, file = "cons_taxa.txt", sep="\t", row.names = FALSE)
save.image(file = "table_1_Taxaformat.Rdata")
##################
#### Table S2 ####
##################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S2/")

# read in raw observed OTUs files
cBL <- read.table(file="cBL_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
fBL <- read.table(file="fBL_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
c57 <- read.table(file="c57_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)


# change column 1 from 'X' to 'SampleID'
# first check column name, then change, then check the change
names(cBL)[1]
names(cBL)[1] <- "SampleID"
names(cBL)[1]
names(fBL)[1]
names(fBL)[1] <- "SampleID"
names(fBL)[1]
names(c57)[1]
names(c57)[1] <- "SampleID"
names(c57)[1]

# we don't need the chao1 data, so remove it
cBL <- cBL[, c("SampleID","observed_otus")]
fBL <- fBL[, c("SampleID","observed_otus")]
c57 <- c57[, c("SampleID","observed_otus")]

# read in the HSCR and c57 mapping files with metadata
# reduce the number of columns in the HSCR map
# then merge the maps with their respective data frames
HSCR_map <- read.table(file="hscr_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
c57_map <- read.table(file="c57_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
HSCR_map <- HSCR_map[, c("SampleID","GroupFacility")]
cBL <- merge(cBL, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
fBL <- merge(fBL, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
c57 <- merge(c57, c57_map, by="SampleID", all.x=TRUE, sort=FALSE)

require(dplyr)
# using package dplyr calculate mean number of observed OTUs for each group
# these will be grouped by GroupFacility (cBL and fBL) or Facility (c57)
cBL <- summarise(group_by(cBL, GroupFacility),
mean=mean(observed_otus))
fBL <- summarise(group_by(fBL, GroupFacility),
mean=mean(observed_otus))
c57 <- summarise(group_by(c57, Facility),
mean=mean(observed_otus))

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S2/")
write.table(cBL, file = "cBL_meanObsOTU.txt", sep="\t", row.names = FALSE)
write.table(fBL, file = "fBL_meanObsOTU.txt", sep="\t", row.names = FALSE)
write.table(c57, file = "c57_meanObsOTU.txt", sep="\t", row.names = FALSE)
save.image(file = "table_S2_WS.Rdata")

#########################
#### Table S3 FORMAT ####
#########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S3/")

# read in all of the alpha diversity files
# Inter-Facility
cBL <- read.table(file="hscr/inter/cBL_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
fBL <- read.table(file="hscr/inter/fBL_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
c57 <- read.table(file="c57/c57_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)

# Intra-Facility
cBos <- read.table(file="hscr/intra/cBos_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
fBos <- read.table(file="hscr/intra/fBos_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
cLar <- read.table(file="hscr/intra/cLar_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)
fLar <- read.table(file="hscr/intra/fLar_HSCR_adiv.txt",
header=TRUE,sep="\t", as.is=TRUE)

# change column 1 from 'X' to 'SampleID'
# first check column name, then change, then check the change
names(cBL)[1]
names(cBL)[1] <- "SampleID"
names(cBL)[1]
names(fBL)[1]
names(fBL)[1] <- "SampleID"
names(fBL)[1]
names(c57)[1]
names(c57)[1] <- "SampleID"
names(c57)[1]
names(cBos)[1]
names(cBos)[1] <- "SampleID"
names(cBos)[1]
names(fBos)[1]
names(fBos)[1] <- "SampleID"
names(fBos)[1]
names(cLar)[1]
names(cLar)[1] <- "SampleID"
names(cLar)[1]
names(fLar)[1]
names(fLar)[1] <- "SampleID"
names(fLar)[1]

# read in the HSCR and c57 mapping files with metadata
# reduce the number of columns in the HSCR map
# then merge the maps with their respective data frames
HSCR_map <- read.table(file="hscr_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
c57_map <- read.table(file="c57_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
HSCR_map <- HSCR_map[, c("SampleID","GroupFacility","Group")]
cBL <- merge(cBL, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
fBL <- merge(fBL, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
c57 <- merge(c57, c57_map, by="SampleID", all.x=TRUE, sort=FALSE)
cBos <- merge(cBos, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
fBos <- merge(fBos, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
cLar <- merge(cLar, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
fLar <- merge(fLar, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)

# for use in table_S3_stats.R,
# we need to change columns 'GroupFacility' - 'Group' - 'Facility'
# to universal column name: 'Factor'
# first check column name, then change, then check the change
# then reduce columns where applicable
names(cBL)[4]
names(cBL)[4] <- "Factor"
names(cBL)[4]
cBL <- cBL[, c("Factor","chao1","observed_otus")]
names(fBL)[4]
names(fBL)[4] <- "Factor"
names(fBL)[4]
fBL <- fBL[, c("Factor","chao1","observed_otus")]
names(c57)[4]
names(c57)[4] <- "Factor"
names(c57)[4]
c57 <- c57[, c("Factor","chao1","observed_otus")]
names(cBos)[5]
names(cBos)[5] <- "Factor"
names(cBos)[5]
cBos <- cBos[, c("Factor","chao1","observed_otus")]
names(fBos)[5]
names(fBos)[5] <- "Factor"
names(fBos)[5]
fBos <- fBos[, c("Factor","chao1","observed_otus")]
names(cLar)[5]
names(cLar)[5] <- "Factor"
names(cLar)[5]
cLar <- cLar[, c("Factor","chao1","observed_otus")]
names(fLar)[5]
names(fLar)[5] <- "Factor"
names(fLar)[5]
fLar <- fLar[, c("Factor","chao1","observed_otus")]

require(dplyr)
# using package dplyr specify the order of factor levels
cBL <- mutate(cBL, Factor = factor(Factor, levels=unique(Factor)))
fBL <- mutate(fBL, Factor = factor(Factor, levels=unique(Factor)))
c57 <- mutate(c57, Factor = factor(Factor, levels=unique(Factor)))
cBos <- mutate(cBos, Factor = factor(Factor, levels=unique(Factor)))
fBos <- mutate(fBos, Factor = factor(Factor, levels=unique(Factor)))
cLar <- mutate(cLar, Factor = factor(Factor, levels=unique(Factor)))
fLar <- mutate(fLar, Factor = factor(Factor, levels=unique(Factor)))

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S3/")
write.table(cBL, file = "cBL_form.txt", sep="\t", row.names = FALSE)
write.table(fBL, file = "fBL_form.txt", sep="\t", row.names = FALSE)
write.table(c57, file = "c57_form.txt", sep="\t", row.names = FALSE)
write.table(cBos, file = "cBos_form.txt", sep="\t", row.names = FALSE)
write.table(fBos, file = "fBos_form.txt", sep="\t", row.names = FALSE)
write.table(cLar, file = "cLar_form.txt", sep="\t", row.names = FALSE)
write.table(fLar, file = "fLar_form.txt", sep="\t", row.names = FALSE)
save.image(file = "table_S3_formatWS.Rdata")

# proceed to table_S3_functions.R

############################
#### Table S3 FUNCTIONS ####
############################

# We will define four functions:
# 1 - AutoKW which runs Kruskal-Wallis with Dunn's post hoc with fdr correction
# 2 - AutoWilc which runs pairwise wilcoxon with fdr correction
# 3 - InterFilt which filters the outputs above for,
# age- and genotype-matched inter-facility comparisons
# 4 - IntraFilt which filters the outputs above for,
# age-matched intra-facility comparisons

AutoKW <- function(data=data.frame){
    rawDunn<- data.frame()
    meltDunn<- data.frame()
    for(i in 2:(ncol(data))){
        # perform Dunn's post hoc with fdr correction
        kwd<- posthoc.kruskal.dunn.test(data[,i] ~ data$Factor, p.adjust.method = "fdr")
        kdf<- data.frame(kwd$p.value)
        kdf<- data.frame(Model=rep(names(data)[i], nrow(kdf)), Class=row.names(kdf), kdf)
        rawDunn<- rbind(rawDunn, kdf)
        # melt rawDunn into workable data frame
        meltDunn<- melt(rawDunn, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltDunn$Model <- as.character(meltDunn$Model)
        meltDunn$Class <- as.character(meltDunn$Class)
        meltDunn$PairClass <- as.character(meltDunn$PairClass)
    }
    return(meltDunn)
}

AutoWilc <- function(data=data.frame){
    rawWilc<- data.frame()
    meltWilc<- data.frame()
    for(i in 2:(ncol(data))){
        # perform pairwise Wilcoxon with fdr correction
        wilc<- pairwise.wilcox.test(data[,i], data$Factor, p.adjust.method = "fdr", paired = FALSE, exact = FALSE)
        wdf<- data.frame(wilc$p.value)
        wdf<- data.frame(Model=rep(names(data)[i], nrow(wdf)), Class=row.names(wdf), wdf)
        rawWilc<- rbind(rawWilc, wdf)
        # melt rawWilc into workable data frame
        meltWilc<- melt(rawWilc, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltWilc$Model <- as.character(meltWilc$Model)
        meltWilc$Class <- as.character(meltWilc$Class)
        meltWilc$PairClass <- as.character(meltWilc$PairClass)
    }
    return(meltWilc)
}

InterFilt <- function(data=data.frame){
    # create vectors containing the specific groups we are interested in
    v1 <- filter(data, Class == "P07-WT-Lar" & PairClass == "P07.WT.Bos")
    v2 <- filter(data, Class == "P07-WT-Bos" & PairClass == "P07.WT.Lar")
    v3 <- filter(data, Class == "P20-WT-Lar" & PairClass == "P20.WT.Bos")
    v4 <- filter(data, Class == "P20-WT-Bos" & PairClass == "P20.WT.Lar")
    v5 <- filter(data, Class == "P24-WT-Lar" & PairClass == "P24.WT.Bos")
    v6 <- filter(data, Class == "P24-WT-Bos" & PairClass == "P24.WT.Lar")
    v11 <- filter(data, Class == "P07-KO-Lar" & PairClass == "P07.KO.Bos")
    v12 <- filter(data, Class == "P07-KO-Bos" & PairClass == "P07.KO.Lar")
    v13 <- filter(data, Class == "P20-KO-Lar" & PairClass == "P20.KO.Bos")
    v14 <- filter(data, Class == "P20-KO-Bos" & PairClass == "P20.KO.Lar")
    v15 <- filter(data, Class == "P24-KO-Lar" & PairClass == "P24.KO.Bos")
    v16 <- filter(data, Class == "P24-KO-Bos" & PairClass == "P24.KO.Lar")
    # combine the vectors
    filt <- rbind(v1,v2,v3,v4,v5,v6,v11,v12,v13,v14,v15,v16)
    # filter the vectors to remove NA's in the p_Value column
    dfc <- filter(filt, Model == "chao1" & p_Value > 0)
    dfo <- filter(filt, Model == "observed_otus" & p_Value > 0)
    # combine chao1 and observed_otus dataframes together
    df <- rbind(dfc,dfo)
    # change column 'Model'  to 'Metric'
    names(df)[1] <- "Metric"
    return(df)
}

IntraFilt <- function(data=data.frame){
    # create vectors containing the specific groups we are interested in
    v1 <- filter(data, Class == "P07-WT" & PairClass == "P07.KO")
    v2 <- filter(data, Class == "P07-KO" & PairClass == "P07.WT")
    v3 <- filter(data, Class == "P20-WT" & PairClass == "P20.KO")
    v4 <- filter(data, Class == "P20-KO" & PairClass == "P20.WT")
    v5 <- filter(data, Class == "P24-WT" & PairClass == "P24.KO")
    v6 <- filter(data, Class == "P24-KO" & PairClass == "P24.WT")
    # combine the vectors
    filt <- rbind(v1,v2,v3,v4,v5,v6)
    # filter the vectors to remove NA's in the p_Value column
    dfc <- filter(filt, Model == "chao1" & p_Value > 0)
    dfo <- filter(filt, Model == "observed_otus" & p_Value > 0)
    # combine chao1 and observed_otus dataframes together
    df <- rbind(dfc,dfo)
    # change column 'Model'  to 'Metric'
    names(df)[1] <- "Metric"
    return(df)
}

# save the workspace
save.image(file = "table_S3_functionsWS.Rdata")

# proceed to table_S3_stats.R
########################
#### Table S3 STATS ####
########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S3/")

# read in the workspace from table_S3_functions
load("table_S3_functionsWS.Rdata")

# read in all of the formatted files from table_S3_format.R
cBL <- read.table(file="cBL_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBL <- read.table(file="fBL_form.txt",header=TRUE,sep="\t",as.is=FALSE)
c57 <- read.table(file="c57_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cBos <- read.table(file="cBos_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBos <- read.table(file="fBos_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cLar <- read.table(file="cLar_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fLar <- read.table(file="fLar_form.txt",header=TRUE,sep="\t",as.is=FALSE)

require(PMCMR)
require(reshape2)
# apply the functions to each data frame
# warnings may arise showing "ties present", disregard this
# first the statistical test, then the filter
# then add new column designating the statistical test
# then bind the objects together and save them
# NOTE: c57 does not need to be filtered
cBL_kw <- AutoKW(cBL)
cBL_kw <- InterFilt(cBL_kw)
cBL_kw$Test <- "Kruskal-Wallis"
cBL_wilc <- AutoWilc(cBL)
cBL_wilc <- InterFilt(cBL_wilc)
cBL_wilc$Test <- "Pairwise Wilcoxon"
cBL_adiv <- rbind(cBL_kw,cBL_wilc)
write.table(cBL_adiv, file = "cBL_adiv.txt", sep="\t", row.names = FALSE)

fBL_kw <- AutoKW(fBL)
fBL_kw <- InterFilt(fBL_kw)
fBL_kw$Test <- "Kruskal-Wallis"
fBL_wilc <- AutoWilc(fBL)
fBL_wilc <- InterFilt(fBL_wilc)
fBL_wilc$Test <- "Pairwise Wilcoxon"
fBL_adiv <- rbind(fBL_kw,fBL_wilc)
write.table(fBL_adiv, file = "fBL_adiv.txt", sep="\t", row.names = FALSE)

c57_kw <- AutoKW(c57)
c57_kw$Test <- "Kruskal-Wallis"
c57_wilc <- AutoWilc(c57)
c57_wilc$Test <- "Pairwise Wilcoxon"
c57_adiv <- rbind(c57_kw,c57_wilc)
write.table(c57_adiv, file = "c57_adiv.txt", sep="\t", row.names = FALSE)

cBos_kw <- AutoKW(cBos)
cBos_kw <- IntraFilt(cBos_kw)
cBos_kw$Test <- "Kruskal-Wallis"
cBos_wilc <- AutoWilc(cBos)
cBos_wilc <- IntraFilt(cBos_wilc)
cBos_wilc$Test <- "Pairwise Wilcoxon"
cBos_adiv <- rbind(cBos_kw,cBos_wilc)
write.table(cBos_adiv, file = "cBos_adiv.txt", sep="\t", row.names = FALSE)

fBos_kw <- AutoKW(fBos)
fBos_kw <- IntraFilt(fBos_kw)
fBos_kw$Test <- "Kruskal-Wallis"
fBos_wilc <- AutoWilc(fBos)
fBos_wilc <- IntraFilt(fBos_wilc)
fBos_wilc$Test <- "Pairwise Wilcoxon"
fBos_adiv <- rbind(fBos_kw,fBos_wilc)
write.table(fBos_adiv, file = "fBos_adiv.txt", sep="\t", row.names = FALSE)

cLar_kw <- AutoKW(cLar)
cLar_kw <- IntraFilt(cLar_kw)
cLar_kw$Test <- "Kruskal-Wallis"
cLar_wilc <- AutoWilc(cLar)
cLar_wilc <- IntraFilt(cLar_wilc)
cLar_wilc$Test <- "Pairwise Wilcoxon"
cLar_adiv <- rbind(cLar_kw,cLar_wilc)
write.table(cLar_adiv, file = "cLar_adiv.txt", sep="\t", row.names = FALSE)

fLar_kw <- AutoKW(fLar)
fLar_kw <- IntraFilt(fLar_kw)
fLar_kw$Test <- "Kruskal-Wallis"
fLar_wilc <- AutoWilc(fLar)
fLar_wilc <- IntraFilt(fLar_wilc)
fLar_wilc$Test <- "Pairwise Wilcoxon"
fLar_adiv <- rbind(fLar_kw,fLar_wilc)
write.table(fLar_adiv, file = "fLar_adiv.txt", sep="\t", row.names = FALSE)

# save the workspace
save.image(file = "table_S3_statsWS.Rdata")
############################
#### Table S4 FUNCTIONS ####
############################

# We will define eight functions:
# 1 - HighRA which retains columns with row values greater than 0.059 ot 5.9%
# 2 - GetRA which returns a dataframe with mean relative abundances per column,
# therefore the input df must be split by Factor (or Group)
# 3 - TruncPhy which truncates the column names that represent Phylum
# 4 - TruneGen which truncates the column names representing Phylum to Genus
# 5 - AutoKW which runs Kruskal-Wallis with Dunn's post hoc with fdr correction
# 6 - AutoWilc which runs pairwise wilcoxon with fdr correction
# 7 - InterFilt which filters the outputs above for,
# age- and genotype-matched inter-facility comparisons
# 8 - GetSigs which returns a dataframe with P values < 0.05

HighRA <-function(data=data.frame){
    goodCol<- as.integer()
    for(i in 3:ncol(data)){
        col<- which(data[,i] > 0.059)
        if(length(col)>0) goodCol <- c(goodCol, i)
    }
    # retain those columns in df_above
    df_above <- data[,c(1:1, goodCol)]
    return(df_above)
}

GetRA <- function(data=data.frame){
    dfm <- data.frame()
    for(i in 1:ncol(data)){
        new <- data.frame(mean(data[,i]))
        df <- data.frame(Taxon=rep(names(data)[i],nrow(new)),new)
        names(df)[2] <- "Mean"
        dfm <- rbind(dfm,df)
    }
    return(dfm)
}

TruncPhy <- function(colName){
    newname <- "SampleID"
    for(i in 2:length(colName)){
        p <- strsplit(colName[i], ".p__")[[1]][2]
        # save phylum name
        newname<- c(newname, paste("", strsplit(p, "\\.")[[1]][1], sep=""))
    }
    return(newname)
}

TruncGen<- function(colName){
    newname<- "SampleID"
    for(i in 2:length(colName)){
        p<- strsplit(colName[i], ".p__")[[1]][2]
        if(nchar(p) > 4){
            o<- strsplit(p, ".o__")[[1]][2]
            if(is.na(o)||(o==".f__")){
                # only to phylum, save new column name
                newname<- c(newname, paste("p", strsplit(p, "\\.")[[1]][1], sep="_"))
            }
            else{
                if(nchar(o) > 4){
                    f<- strsplit(o, ".f__")[[1]][2]
                    if(is.na(f)||(f==".g__")){
                        # family doesn't exist, save order
                        newname<- c(newname, paste("o", strsplit(o, "\\.")[[1]][1], sep="_"))
                    }
                    else{
                        if(nchar(f) > 4){
                            g<- strsplit(f, ".g__")[[1]][2]
                            if(is.na(g)){
                                # genus doesn't exist, save family
                                newname<- c(newname, paste("f", strsplit(f, "\\.")[[1]][1], sep="_"))
                            }
                            else{
                                # genus exists
                                newname<- c(newname, paste("g", strsplit(g, "\\.")[[1]][1], sep="_"))
                            }
                        }
                    }
                }
            }
        }
    }
    return(newname)
}

AutoKW <- function(data=data.frame){
    rawDunn<- data.frame()
    meltDunn<- data.frame()
    for(i in 2:(ncol(data))){
        # perform Dunn's post hoc with fdr correction
        kwd<- posthoc.kruskal.dunn.test(data[,i] ~ data$Factor, p.adjust.method = "fdr")
        kdf<- data.frame(kwd$p.value)
        kdf<- data.frame(Model=rep(names(data)[i], nrow(kdf)), Class=row.names(kdf), kdf)
        rawDunn<- rbind(rawDunn, kdf)
        # melt rawDunn into workable data frame
        meltDunn<- melt(rawDunn, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltDunn$Model <- as.character(meltDunn$Model)
        meltDunn$Class <- as.character(meltDunn$Class)
        meltDunn$PairClass <- as.character(meltDunn$PairClass)
    }
    return(meltDunn)
}

AutoWilc <- function(data=data.frame){
    rawWilc<- data.frame()
    meltWilc<- data.frame()
    for(i in 2:(ncol(data))){
        # perform pairwise Wilcoxon with fdr correction
        wilc<- pairwise.wilcox.test(data[,i], data$Factor, p.adjust.method = "fdr", paired = FALSE, exact = FALSE)
        wdf<- data.frame(wilc$p.value)
        wdf<- data.frame(Model=rep(names(data)[i], nrow(wdf)), Class=row.names(wdf), wdf)
        rawWilc<- rbind(rawWilc, wdf)
        # melt rawWilc into workable data frame
        meltWilc<- melt(rawWilc, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltWilc$Model <- as.character(meltWilc$Model)
        meltWilc$Class <- as.character(meltWilc$Class)
        meltWilc$PairClass <- as.character(meltWilc$PairClass)
    }
    return(meltWilc)
}

InterFilt <- function(data=data.frame){
    # create vectors containing the specific groups we are interested in
    v1 <- filter(data, Class == "P07-WT-Lar" & PairClass == "P07.WT.Bos")
    v2 <- filter(data, Class == "P07-WT-Bos" & PairClass == "P07.WT.Lar")
    v3 <- filter(data, Class == "P20-WT-Lar" & PairClass == "P20.WT.Bos")
    v4 <- filter(data, Class == "P20-WT-Bos" & PairClass == "P20.WT.Lar")
    v5 <- filter(data, Class == "P24-WT-Lar" & PairClass == "P24.WT.Bos")
    v6 <- filter(data, Class == "P24-WT-Bos" & PairClass == "P24.WT.Lar")
    v11 <- filter(data, Class == "P07-KO-Lar" & PairClass == "P07.KO.Bos")
    v12 <- filter(data, Class == "P07-KO-Bos" & PairClass == "P07.KO.Lar")
    v13 <- filter(data, Class == "P20-KO-Lar" & PairClass == "P20.KO.Bos")
    v14 <- filter(data, Class == "P20-KO-Bos" & PairClass == "P20.KO.Lar")
    v15 <- filter(data, Class == "P24-KO-Lar" & PairClass == "P24.KO.Bos")
    v16 <- filter(data, Class == "P24-KO-Bos" & PairClass == "P24.KO.Lar")
    # combine the vectors
    filt <- rbind(v1,v2,v3,v4,v5,v6,v11,v12,v13,v14,v15,v16)
    # filter the vectors to remove NA's in the p_Value column
    df <- filter(filt, p_Value > 0)
    # change column 'Model'  to 'Taxon'
    names(df)[1] <- "Taxon"
    return(df)
}

GetSigs <- function(data=data.frame){
    # filter dataframes for P values < 0.05
    sigs <- data[which(data$p_Value < 0.05),]
    # sort the output dataframe by Class (should be by Age-Genotype)
    sigs <- sigs[order(sigs$Class),]
    return(sigs)
}

# save the workspace
setwd("~/Desktop/test/analysis/table_S4/")
save.image(file = "table_S4_functionsWS.Rdata")

# proceed to table_S4_format.R
#########################
#### Table S4 FORMAT ####
#########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S4/")

# read in the workspace from table_S4_functions
load("table_S4_functionsWS.Rdata")

# read in the phylum output from QIIME taxa summary
BL_phy <- read.delim(file="HSCR_phylum.txt",
header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)
c57_phy <- read.delim(file="c57_phylum.txt",
header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)
BL_gen <- read.delim(file="HSCR_genus.txt",
header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)

# remove unnessary columns
# we want X.SampleID as column 1 and Unassigned.Other as column 2
rName <- c("BarcodeSequence","LinkerPrimerSequence","ReverseLinkerPrimerSequence",
"MouseOrigin","Platform","Year","Type","YearType","GenoType","AgeType",
"AgeGenoType","AgeFacility","AgeFacilityType","FacilityType",
"Study","StudyType","AgeGenoTypeStudy","Description", "Group",
"Facility", "Age", "Geno", "GroupFacility","GroupFacilityType",
"Cage","Mother","Sex","FacilityCage","FacilityLitter","AgeDays")
kill <- which(names(BL_phy) %in% rName)
BL_phy <- BL_phy[, - c(kill)]
kill <- which(names(c57_phy) %in% rName)
c57_phy <- c57_phy[, - c(kill)]
kill <- which(names(BL_gen) %in% rName)
BL_gen <- BL_gen[, - c(kill)]

# a few column names need changed
# .Other and Unassigned.Other and .Thermi. and .WPS.2
# first check column name, then change, then check the change
names(BL_phy)[2]
names(BL_phy)[2] <- "k__Unassigned.p__Unassigned"
names(BL_phy)[2]
names(BL_phy)[3]
names(BL_phy)[3] <- "k__Bacteria.p__Undefined"
names(BL_phy)[3]
names(c57_phy)[2]
names(c57_phy)[2] <- "k__Unassigned.p__Unassigned"
names(c57_phy)[2]
names(c57_phy)[3]
names(c57_phy)[3] <- "k__Bacteria.p__Undefined"
names(c57_phy)[3]
names(BL_gen)[2]
names(BL_gen)[2] <- "k__Unassigned.p__Unassigned"
names(BL_gen)[2]
names(BL_gen)[3]
names(BL_gen)[3] <- "k__Bacteria.p__Undefined"
names(BL_gen)[3]

# apply the HighRA function
df_BL_phy <- HighRA(BL_phy)
df_c57_phy <- HighRA(c57_phy)
df_BL_gen <- HighRA(BL_gen)

# apply the TruncPhy function to the appropriate dataframes
# and check the new column names
names(df_BL_phy) <- TruncPhy(names(df_BL_phy))
names(df_BL_phy)
names(df_c57_phy) <- TruncPhy(names(df_c57_phy))
names(df_c57_phy)

# apply the TruncGen function to the appropriate dataframes
# and check the new column names
names(df_BL_gen) <- TruncGen(names(df_BL_gen))
names(df_BL_gen)

# read in the HSCR and c57 mapping files with metadata
# reduce the number of columns in the HSCR map
# then merge the maps with their respective data frames
# disregard the duplicate warning
HSCR_map <- read.table(file="hscr_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
HSCR_map <- HSCR_map[, c("SampleID","GroupFacility","Type")]
df_BL_phy <- merge(df_BL_phy, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
df_BL_gen <- merge(df_BL_gen, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
c57_map <- read.table(file="c57_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
df_c57_phy <- merge(df_c57_phy, c57_map, by="SampleID", all.x=TRUE, sort=FALSE)

# split df_BL_phy and df_BL_gen,
# into fecal and colon specific dataframes
splt <- split.data.frame(x=df_BL_phy,f=df_BL_phy$Type)
cBL_phy <- splt$colon
fBL_phy <- splt$fecal
splt <- split.data.frame(x=df_BL_gen,f=df_BL_gen$Type)
cBL_gen <- splt$colon
fBL_gen <- splt$fecal

# drop 'SampleID' from each dataframe (first column)
# for the cBL and fBL dataframes also drop 'Type' (last column)
# for the cBL and fBL dataframes move the 'GroupFacility' column to first
# for the c57 dataframe move the 'Facility' to first
# first check the number of columns
# then drop the first column (and last column: for cBL's and fBL's)
# then move the last column to first
# and finally, rename it to 'Factor' and check rename
ncol(cBL_phy)
cBL_phy <- cBL_phy[,c(2:9)]
cBL_phy <- cBL_phy[,c(8,1:7)]
names(cBL_phy)[1] <- "Factor"
names(cBL_phy)[1]
ncol(fBL_phy)
fBL_phy <- fBL_phy[,c(2:9)]
fBL_phy <- fBL_phy[,c(8,1:7)]
names(fBL_phy)[1] <- "Factor"
names(fBL_phy)[1]
ncol(df_c57_phy)
df_c57_phy <- df_c57_phy[,c(2:5)]
df_c57_phy <- df_c57_phy[,c(4,1:3)]
names(df_c57_phy)[1] <- "Factor"
names(df_c57_phy)[1]
ncol(cBL_gen)
cBL_gen <- cBL_gen[,c(2:29)]
cBL_gen <- cBL_gen[,c(28,1:27)]
names(cBL_gen)[1] <- "Factor"
names(cBL_gen)[1]
ncol(fBL_gen)
fBL_gen <- fBL_gen[,c(2:29)]
fBL_gen <- fBL_gen[,c(28,1:27)]
names(fBL_gen)[1] <- "Factor"
names(fBL_gen)[1]

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S4/")
write.table(cBL_phy, file = "cBL_phy_form.txt", sep="\t", row.names = FALSE)
write.table(fBL_phy, file = "fBL_phy_form.txt", sep="\t", row.names = FALSE)
write.table(cBL_gen, file = "cBL_gen_form.txt", sep="\t", row.names = FALSE)
write.table(fBL_gen, file = "fBL_gen_form.txt", sep="\t", row.names = FALSE)
write.table(df_c57_phy, file = "c57_phy_form.txt", sep="\t", row.names = FALSE)

save.image(file = "table_S4_formatWS.Rdata")

# proceed to table_S4_stats.R
########################
#### Table S4 STATS ####
########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S4/")

# read in the workspace from table_S4_functions
load("table_S4_functionsWS.Rdata")

# read in all of the formatted files from table_S4_format
cBL_phy <- read.table(file="cBL_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBL_phy <- read.table(file="fBL_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
c57_phy <- read.table(file="c57_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cBL_gen <- read.table(file="cBL_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBL_gen <- read.table(file="fBL_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)

require(PMCMR)
require(reshape2)
require(dplyr)
# apply the functions to each data frame
# warnings may arise showing "ties present", disregard this
# first the statistical test, then the filter
# then add new column designating the statistical test
# then bind the objects together
# apply the GetSigs function to return dataframe with P < 0.05
# and then save the two dataframes
# NOTE: c57 does not need to be filtered,
# however, column 'Model' needs to be changed to 'Taxon'
cBL_phy_kw <- AutoKW(cBL_phy)
cBL_phy_kw <- InterFilt(cBL_phy_kw)
cBL_phy_kw$Test <- "Kruskal-Wallis"
cBL_phy_wilc <- AutoWilc(cBL_phy)
cBL_phy_wilc <- InterFilt(cBL_phy_wilc)
cBL_phy_wilc$Test <- "Pairwise Wilcoxon"
cBL_phy_stats <- rbind(cBL_phy_kw,cBL_phy_wilc)
cBL_phy_sigs <- GetSigs(cBL_phy_stats)
write.table(cBL_phy_stats, file = "cBL_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(cBL_phy_sigs, file = "cBL_phy_sigs.txt", sep="\t", row.names = FALSE)

fBL_phy_kw <- AutoKW(fBL_phy)
fBL_phy_kw <- InterFilt(fBL_phy_kw)
fBL_phy_kw$Test <- "Kruskal-Wallis"
fBL_phy_wilc <- AutoWilc(fBL_phy)
fBL_phy_wilc <- InterFilt(fBL_phy_wilc)
fBL_phy_wilc$Test <- "Pairwise Wilcoxon"
fBL_phy_stats <- rbind(fBL_phy_kw,fBL_phy_wilc)
fBL_phy_sigs <- GetSigs(fBL_phy_stats)
write.table(fBL_phy_stats, file = "fBL_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(fBL_phy_sigs, file = "fBL_phy_sigs.txt", sep="\t", row.names = FALSE)

cBL_gen_kw <- AutoKW(cBL_gen)
cBL_gen_kw <- InterFilt(cBL_gen_kw)
cBL_gen_kw$Test <- "Kruskal-Wallis"
cBL_gen_wilc <- AutoWilc(cBL_gen)
cBL_gen_wilc <- InterFilt(cBL_gen_wilc)
cBL_gen_wilc$Test <- "Pairwise Wilcoxon"
cBL_gen_stats <- rbind(cBL_gen_kw,cBL_gen_wilc)
cBL_gen_sigs <- GetSigs(cBL_gen_stats)
write.table(cBL_gen_stats, file = "cBL_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(cBL_gen_sigs, file = "cBL_gen_sigs.txt", sep="\t", row.names = FALSE)

fBL_gen_kw <- AutoKW(fBL_gen)
fBL_gen_kw <- InterFilt(fBL_gen_kw)
fBL_gen_kw$Test <- "Kruskal-Wallis"
fBL_gen_wilc <- AutoWilc(fBL_gen)
fBL_gen_wilc <- InterFilt(fBL_gen_wilc)
fBL_gen_wilc$Test <- "Pairwise Wilcoxon"
fBL_gen_stats <- rbind(fBL_gen_kw,fBL_gen_wilc)
fBL_gen_sigs <- GetSigs(fBL_gen_stats)
write.table(fBL_gen_stats, file = "fBL_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(fBL_gen_sigs, file = "fBL_gen_sigs.txt", sep="\t", row.names = FALSE)

c57_phy_kw <- AutoKW(c57_phy)
c57_phy_kw$Test <- "Kruskal-Wallis"
c57_phy_wilc <- AutoWilc(c57_phy)
c57_phy_wilc$Test <- "Pairwise Wilcoxon"
c57_phy_stats <- rbind(c57_phy_kw,c57_phy_wilc)
names(c57_phy_stats)[1] <- "Taxon"
c57_phy_sigs <- GetSigs(c57_phy_stats)
write.table(c57_phy_stats, file = "c57_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(c57_phy_sigs, file = "c57_phy_sigs.txt", sep="\t", row.names = FALSE)

# save the workspace
save.image(file = "table_S4_statsWS.Rdata")

# proceed to table_S4_RAs.R
########################
#### Table S4 GetRA ####
########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S4/")

# read in the workspace from table_S4_functions
load("table_S4_functionsWS.Rdata")

# read in all of the formatted files from table_S4_format
cBL_phy <- read.table(file="cBL_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBL_phy <- read.table(file="fBL_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cBL_gen <- read.table(file="cBL_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBL_gen <- read.table(file="fBL_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
c57_phy <- read.table(file="c57_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)

# we will define a few data specific functions
# these funtions will calculate the mean relative abundance for each column
# this is useful in order to add back in to our GetSigs dataframes
# (generated in Table_S4_stats)
# so that we know which facility had more or less of which taxa

# these are not generally applicable functions
# in defining these functions, I cut down on the amount of redundant code needed
# ideally, spending more time to make these broad functions would be beneficial

# required input for function 'manipBL' to work:
# dataframe with Colon or Fecal samples - All Ages - Both Genotypes - Both Facilities
# or 12 total factors
# a specific number of columns is not required, however, the data must begin with column 1
# column 1 must be numeric
manipBL <- function(data=data.frame){
    # split the data frame by 'Factor'
    splt<- split.data.frame(x=data,f=data$Factor)
    # paste Factor into new data frame
    d1 <- splt$`P07-WT-Bos`
    # remove column 'Factor'
    d1 <- d1[2:(ncol(data))]
    # apply the GetRa function
    d1 <- GetRA(d1)
    # add 'Factor' back in
    d1$Factor <- "P07-WT-Bos"
    d2 <- splt$`P20-WT-Bos`
    d2 <- d2[2:(ncol(data))]
    d2 <- GetRA(d2)
    d2$Factor <- "P20-WT-Bos"
    d3 <- splt$`P24-WT-Bos`
    d3 <- d3[2:(ncol(data))]
    d3 <- GetRA(d3)
    d3$Factor <- "P24-WT-Bos"
    d4 <- splt$`P07-KO-Bos`
    d4 <- d4[2:(ncol(data))]
    d4 <- GetRA(d4)
    d4$Factor <- "P07-KO-Bos"
    d5 <- splt$`P20-KO-Bos`
    d5 <- d5[2:(ncol(data))]
    d5 <- GetRA(d5)
    d5$Factor <- "P20-KO-Bos"
    d6 <- splt$`P24-KO-Bos`
    d6 <- d6[2:(ncol(data))]
    d6 <- GetRA(d6)
    d6$Factor <- "P24-KO-Bos"
    d11 <- splt$`P07-WT-Lar`
    d11 <- d11[2:(ncol(data))]
    d11 <- GetRA(d11)
    d11$Factor <- "P07-WT-Lar"
    d12 <- splt$`P20-WT-Lar`
    d12 <- d12[2:(ncol(data))]
    d12 <- GetRA(d12)
    d12$Factor <- "P20-WT-Lar"
    d13 <- splt$`P24-WT-Lar`
    d13 <- d13[2:(ncol(data))]
    d13 <- GetRA(d13)
    d13$Factor <- "P24-WT-Lar"
    d14 <- splt$`P07-KO-Lar`
    d14 <- d14[2:(ncol(data))]
    d14 <- GetRA(d14)
    d14$Factor <- "P07-KO-Lar"
    d15 <- splt$`P20-KO-Lar`
    d15 <- d15[2:(ncol(data))]
    d15 <- GetRA(d15)
    d15$Factor <- "P20-KO-Lar"
    d16 <- splt$`P24-KO-Lar`
    d16 <- d16[2:(ncol(data))]
    d16 <- GetRA(d16)
    d16$Factor <- "P24-KO-Lar"
    dfRA <- rbind(d1,d2,d3,d4,d5,d6,d11,d12,d13,d14,d15,d16)
    dfRA$Mean <- dfRA$Mean*100
    dfRA <- dfRA[order(dfRA$Factor),]
}

# required input for function 'manipC57' to work:
# dataframe with Factors Boston and Laramie only
# a specific number of columns is not required, however, the data must begin with column 1
# column 1 must be numeric
manipC57 <- function(data=data.frame){
    # split the data frame by 'Factor'
    splt<- split.data.frame(x=data,f=data$Factor)
    # paste Factor into new data frame
    d1 <- splt$`Boston`
    # remove column 'Factor'
    d1 <- d1[2:(ncol(data))]
    # apply the GetRa function
    d1 <- GetRA(d1)
    # add 'Factor' back in
    d1$Factor <- "Boston"
    d2 <- splt$`Laramie`
    d2 <- d2[2:(ncol(data))]
    d2 <- GetRA(d2)
    d2$Factor <- "Laramie"
    dfRA <- rbind(d1,d2)
    dfRA$Mean <- dfRA$Mean*100
    dfRA <- dfRA[order(dfRA$Factor),]
}

# perform each function on the appropriate dataframes
# and save the tables
cBL_phyRA <- manipBL(cBL_phy)
fBL_phyRA <- manipBL(fBL_phy)
cBL_genRA <- manipBL(cBL_gen)
fBL_genRA <- manipBL(fBL_gen)
c57_phyRA <- manipC57(c57_phy)

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S4/")
write.table(cBL_phyRA, file = "cBL_phyRA.txt", sep="\t", row.names = FALSE)
write.table(fBL_phyRA, file = "fBL_phyRA.txt", sep="\t", row.names = FALSE)
write.table(cBL_genRA, file = "cBL_genRA.txt", sep="\t", row.names = FALSE)
write.table(fBL_genRA, file = "fBL_genRA.txt", sep="\t", row.names = FALSE)
write.table(c57_phyRA, file = "c57_phyRA.txt", sep="\t", row.names = FALSE)

save.image(file = "table_S4_RAs.Rdata")

# done with table_S4
############################
#### Table S6 FUNCTIONS ####
############################

# We will define eight functions:
# 1 - HighRA which retains columns with row values greater than 0.059 ot 5.9%
# 2 - GetRA which returns a dataframe with mean relative abundances per column,
# therefore the input df must be split by Factor (or Group)
# 3 - TruncPhy which truncates the column names that represent Phylum
# 4 - TruneGen which truncates the column names representing Phylum to Genus
# 5 - AutoKW which runs Kruskal-Wallis with Dunn's post hoc with fdr correction
# 6 - AutoWilc which runs pairwise wilcoxon with fdr correction
# 7 - IntraFilt which filters the outputs above for,
# age- and genotype-matched inter-facility comparisons
# 8 - GetSigs which returns a dataframe with P values < 0.05

HighRA <-function(data=data.frame){
    goodCol<- as.integer()
    for(i in 3:ncol(data)){
        col<- which(data[,i] > 0.059)
        if(length(col)>0) goodCol <- c(goodCol, i)
    }
    # retain those columns in df_above
    df_above <- data[,c(1:1, goodCol)]
    return(df_above)
}

GetRA <- function(data=data.frame){
    dfm <- data.frame()
    for(i in 1:ncol(data)){
        new <- data.frame(mean(data[,i]))
        df <- data.frame(Taxon=rep(names(data)[i],nrow(new)),new)
        names(df)[2] <- "Mean"
        dfm <- rbind(dfm,df)
    }
    return(dfm)
}

TruncPhy <- function(colName){
    newname <- "SampleID"
    for(i in 2:length(colName)){
        p <- strsplit(colName[i], ".p__")[[1]][2]
        # save phylum name
        newname<- c(newname, paste("", strsplit(p, "\\.")[[1]][1], sep=""))
    }
    return(newname)
}

TruncGen<- function(colName){
    newname<- "SampleID"
    for(i in 2:length(colName)){
        p<- strsplit(colName[i], ".p__")[[1]][2]
        if(nchar(p) > 4){
            o<- strsplit(p, ".o__")[[1]][2]
            if(is.na(o)||(o==".f__")){
                # only to phylum, save new column name
                newname<- c(newname, paste("p", strsplit(p, "\\.")[[1]][1], sep="_"))
            }
            else{
                if(nchar(o) > 4){
                    f<- strsplit(o, ".f__")[[1]][2]
                    if(is.na(f)||(f==".g__")){
                        # family doesn't exist, save order
                        newname<- c(newname, paste("o", strsplit(o, "\\.")[[1]][1], sep="_"))
                    }
                    else{
                        if(nchar(f) > 4){
                            g<- strsplit(f, ".g__")[[1]][2]
                            if(is.na(g)){
                                # genus doesn't exist, save family
                                newname<- c(newname, paste("f", strsplit(f, "\\.")[[1]][1], sep="_"))
                            }
                            else{
                                # genus exists
                                newname<- c(newname, paste("g", strsplit(g, "\\.")[[1]][1], sep="_"))
                            }
                        }
                    }
                }
            }
        }
    }
    return(newname)
}

AutoKW <- function(data=data.frame){
    rawDunn<- data.frame()
    meltDunn<- data.frame()
    for(i in 2:(ncol(data))){
        # perform Dunn's post hoc with fdr correction
        kwd<- posthoc.kruskal.dunn.test(data[,i] ~ data$Factor, p.adjust.method = "fdr")
        kdf<- data.frame(kwd$p.value)
        kdf<- data.frame(Model=rep(names(data)[i], nrow(kdf)), Class=row.names(kdf), kdf)
        rawDunn<- rbind(rawDunn, kdf)
        # melt rawDunn into workable data frame
        meltDunn<- melt(rawDunn, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltDunn$Model <- as.character(meltDunn$Model)
        meltDunn$Class <- as.character(meltDunn$Class)
        meltDunn$PairClass <- as.character(meltDunn$PairClass)
    }
    return(meltDunn)
}

AutoWilc <- function(data=data.frame){
    rawWilc<- data.frame()
    meltWilc<- data.frame()
    for(i in 2:(ncol(data))){
        # perform pairwise Wilcoxon with fdr correction
        wilc<- pairwise.wilcox.test(data[,i], data$Factor, p.adjust.method = "fdr", paired = FALSE, exact = FALSE)
        wdf<- data.frame(wilc$p.value)
        wdf<- data.frame(Model=rep(names(data)[i], nrow(wdf)), Class=row.names(wdf), wdf)
        rawWilc<- rbind(rawWilc, wdf)
        # melt rawWilc into workable data frame
        meltWilc<- melt(rawWilc, id.vars=c("Model", "Class"), variable.name = "PairClass", value.name = "p_Value")
        meltWilc$Model <- as.character(meltWilc$Model)
        meltWilc$Class <- as.character(meltWilc$Class)
        meltWilc$PairClass <- as.character(meltWilc$PairClass)
    }
    return(meltWilc)
}

IntraFilt <- function(data=data.frame){
    # create vectors containing the specific groups we are interested in
    v1 <- filter(data, Class == "P07-WT" & PairClass == "P07.KO")
    v2 <- filter(data, Class == "P07-KO" & PairClass == "P07.WT")
    v3 <- filter(data, Class == "P20-WT" & PairClass == "P20.KO")
    v4 <- filter(data, Class == "P20-KO" & PairClass == "P20.WT")
    v5 <- filter(data, Class == "P24-WT" & PairClass == "P24.KO")
    v6 <- filter(data, Class == "P24-KO" & PairClass == "P24.WT")
    # combine the vectors
    filt <- rbind(v1,v2,v3,v4,v5,v6)
    # filter the vectors to remove NA's in the p_Value column
    df <- filter(filt, p_Value > 0)
    # change column 'Model'  to 'Taxon'
    names(df)[1] <- "Taxon"
    return(df)
}

GetSigs <- function(data=data.frame){
    # filter dataframes for P values < 0.05
    sigs <- data[which(data$p_Value < 0.05),]
    # sort the output dataframe by Class (should be by Age-Genotype)
    sigs <- sigs[order(sigs$Class),]
    return(sigs)
}

# save the workspace
setwd("~/Desktop/test/analysis/table_S6/")
save.image(file = "table_S6_functionsWS.Rdata")

# proceed to table_S6_format.R
#########################
#### Table S6 FORMAT ####
#########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S6/")

# read in the workspace from table_S6_functions
load("table_S6_functionsWS.Rdata")

# read in the phylum output from QIIME taxa summary
BL_phy <- read.delim(file="HSCR_phylum.txt",
header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)
BL_gen <- read.delim(file="HSCR_genus.txt",
header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)

# remove unnessary columns
# we want X.SampleID as column 1 and Unassigned.Other as column 2
rName <- c("BarcodeSequence","LinkerPrimerSequence","ReverseLinkerPrimerSequence",
"MouseOrigin","Platform","Year","Type","YearType","GenoType","AgeType",
"AgeGenoType","AgeFacility","AgeFacilityType","FacilityType",
"Study","StudyType","AgeGenoTypeStudy","Description", "Group",
"Facility", "Age", "Geno", "GroupFacility","GroupFacilityType",
"Cage","Mother","Sex","FacilityCage","FacilityLitter","AgeDays")
kill <- which(names(BL_phy) %in% rName)
BL_phy <- BL_phy[, - c(kill)]
kill <- which(names(BL_gen) %in% rName)
BL_gen <- BL_gen[, - c(kill)]

# a few column names need changed
# .Other and Unassigned.Other and .Thermi. and .WPS.2
# first check column name, then change, then check the change
names(BL_phy)[2]
names(BL_phy)[2] <- "k__Unassigned.p__Unassigned"
names(BL_phy)[2]
names(BL_phy)[3]
names(BL_phy)[3] <- "k__Bacteria.p__Undefined"
names(BL_phy)[3]
names(BL_gen)[2]
names(BL_gen)[2] <- "k__Unassigned.p__Unassigned"
names(BL_gen)[2]
names(BL_gen)[3]
names(BL_gen)[3] <- "k__Bacteria.p__Undefined"
names(BL_gen)[3]

# apply the HighRA function
df_BL_phy <- HighRA(BL_phy)
df_BL_gen <- HighRA(BL_gen)

# apply the TruncPhy function to the appropriate dataframes
# and check the new column names
names(df_BL_phy) <- TruncPhy(names(df_BL_phy))
names(df_BL_phy)

# apply the TruncGen function to the appropriate dataframes
# and check the new column names
names(df_BL_gen) <- TruncGen(names(df_BL_gen))
names(df_BL_gen)

# read in the HSCR mapping file with metadata
# reduce the number of columns in the map
# then merge the map with its respective dataframes
# disregard the duplicate warning
HSCR_map <- read.table(file="hscr_R_map.txt",
header=TRUE, sep="\t", as.is=TRUE)
HSCR_map <- HSCR_map[, c("SampleID","Group","Type","Facility")]
df_BL_phy <- merge(df_BL_phy, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)
df_BL_gen <- merge(df_BL_gen, HSCR_map, by="SampleID", all.x=TRUE, sort=FALSE)

# split df_BL_phy and df_BL_gen,
# into fecal and colon specific dataframes
splt <- split.data.frame(x=df_BL_phy,f=df_BL_phy$Type)
cBL_phy <- splt$colon
fBL_phy <- splt$fecal
splt <- split.data.frame(x=df_BL_gen,f=df_BL_gen$Type)
cBL_gen <- splt$colon
fBL_gen <- splt$fecal

# split cBL and fBL,
# into Facility specific dataframes
splt <- split.data.frame(x=cBL_phy,f=cBL_phy$Facility)
cBos_phy <- splt$Boston
cLar_phy <- splt$Laramie
splt <- split.data.frame(x=fBL_phy,f=fBL_phy$Facility)
fBos_phy <- splt$Boston
fLar_phy <- splt$Laramie
splt <- split.data.frame(x=cBL_gen,f=cBL_gen$Facility)
cBos_gen <- splt$Boston
cLar_gen <- splt$Laramie
splt <- split.data.frame(x=fBL_gen,f=fBL_gen$Facility)
fBos_gen <- splt$Boston
fLar_gen <- splt$Laramie

# we will define a few data specific functions
# these are not generally applicable functions
# these funtions will do the following:
# drop 'SampleID' from each dataframe (first column)
# drop 'Type' and 'Facility' (last two columns)
# move Group to the first column
# rename 'Group' to 'Factor'
manipDF <- function(data=data.frame){
    # remove column 'SampleID'
    data1 <- data[2:(ncol(data))]
    # place ncol in data into a vector
    col <- as.numeric(ncol(data1))
    # subtract 2 from ncol and place the number into a vector
    colkeep <- as.numeric(col-2)
    # retain the number in colkeep
    # this removes Type and Facility from the data
    data2 <- data1[1:colkeep]
    # place the ncol into a new vector
    col2 <- as.numeric(ncol(data2))
    colkeep2 <- as.numeric(col2-1)
    # now move 'Group' to the first column
    data3 <- data2[,c(col2,1:colkeep2)]
    # rename 'Group' to 'Factor'
    names(data3)[1] <- "Factor"
    # sort data3 by Factor
    data3 <- data3[order(data3$Factor),]
    return(data3)
}

# apply the function
cBos_phy <- manipDF(cBos_phy)
fBos_phy <- manipDF(fBos_phy)
cLar_phy <- manipDF(cLar_phy)
fLar_phy <- manipDF(fLar_phy)
cBos_gen <- manipDF(cBos_gen)
fBos_gen <- manipDF(fBos_gen)
cLar_gen <- manipDF(cLar_gen)
fLar_gen <- manipDF(fLar_gen)

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S6/")
write.table(cBos_phy, file = "cBos_phy_form.txt", sep="\t", row.names = FALSE)
write.table(fBos_phy, file = "fBos_phy_form.txt", sep="\t", row.names = FALSE)
write.table(cLar_phy, file = "cLar_phy_form.txt", sep="\t", row.names = FALSE)
write.table(fLar_phy, file = "fLar_phy_form.txt", sep="\t", row.names = FALSE)
write.table(cBos_gen, file = "cBos_gen_form.txt", sep="\t", row.names = FALSE)
write.table(fBos_gen, file = "fBos_gen_form.txt", sep="\t", row.names = FALSE)
write.table(cLar_gen, file = "cLar_gen_form.txt", sep="\t", row.names = FALSE)
write.table(fLar_gen, file = "fLar_gen_form.txt", sep="\t", row.names = FALSE)
save.image(file = "table_S6_formatWS.Rdata")

# proceed to table_S6_stats.R
########################
#### Table S6 GetRA ####
########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S6/")

# read in the workspace from table_S4_functions
load("table_S6_functionsWS.Rdata")

# read in all of the formatted files from table_S6_format
cBos_phy <- read.table(file="cBos_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBos_phy <- read.table(file="fBos_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cLar_phy <- read.table(file="cLar_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fLar_phy <- read.table(file="fLar_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cBos_gen <- read.table(file="cBos_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBos_gen <- read.table(file="fBos_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cLar_gen <- read.table(file="cLar_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fLar_gen <- read.table(file="fLar_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)

# we will define a few data specific functions
# these funtions will calculate the mean relative abundance for each column
# this is useful in order to add back in to our GetSigs dataframes
# (generated in Table_S6_stats)
# so that we know which genotype had more or less of which taxa

# required input for function 'manipRA' to work:
# dataframe with Colon or Fecal samples from one facility - All Ages - Both Genotypes
# or 6 total factors
# a specific number of columns is not required, however, the data must begin with column 1
# column 1 must be numeric
manipRA <- function(data=data.frame){
    # split the data frame by 'Factor'
    splt<- split.data.frame(x=data,f=data$Factor)
    # paste Factor into new data frame
    d1 <- splt$`P07-WT`
    # remove column 'Factor'
    d1 <- d1[2:(ncol(data))]
    # apply the GetRA function
    d1 <- GetRA(d1)
    # add 'Factor' back in
    d1$Factor <- "P07-WT"
    d2 <- splt$`P07-KO`
    d2 <- d2[2:(ncol(data))]
    d2 <- GetRA(d2)
    d2$Factor <- "P07-KO"
    d3 <- splt$`P20-WT`
    d3 <- d3[2:(ncol(data))]
    d3 <- GetRA(d3)
    d3$Factor <- "P20-WT"
    d4 <- splt$`P20-KO`
    d4 <- d4[2:(ncol(data))]
    d4 <- GetRA(d4)
    d4$Factor <- "P20-KO"
    d5 <- splt$`P24-WT`
    d5 <- d5[2:(ncol(data))]
    d5 <- GetRA(d5)
    d5$Factor <- "P24-WT"
    d6 <- splt$`P24-KO`
    d6 <- d6[2:(ncol(data))]
    d6 <- GetRA(d6)
    d6$Factor <- "P24-KO"
    dfRA <- rbind(d1,d2,d3,d4,d5,d6)
    dfRA$Mean <- dfRA$Mean*100
    dfRA <- dfRA[order(dfRA$Factor),]
}

# perform each function on the appropriate dataframes
# and save the tables
cBos_phyRA <- manipRA(cBos_phy)
fBos_phyRA <- manipRA(fBos_phy)
cLar_phyRA <- manipRA(cLar_phy)
fLar_phyRA <- manipRA(fLar_phy)
cBos_genRA <- manipRA(cBos_gen)
fBos_genRA <- manipRA(fBos_gen)
cLar_genRA <- manipRA(cLar_gen)
fLar_genRA <- manipRA(fLar_gen)

# save tables and workspace
setwd("~/Desktop/test/analysis/table_S6/")
write.table(cBos_phyRA, file = "cBos_phyRA.txt", sep="\t", row.names = FALSE)
write.table(fBos_phyRA, file = "fBos_phyRA.txt", sep="\t", row.names = FALSE)
write.table(cLar_phyRA, file = "cLar_phyRA.txt", sep="\t", row.names = FALSE)
write.table(fLar_phyRA, file = "fLar_phyRA.txt", sep="\t", row.names = FALSE)
write.table(cBos_genRA, file = "cBos_genRA.txt", sep="\t", row.names = FALSE)
write.table(fBos_genRA, file = "fBos_genRA.txt", sep="\t", row.names = FALSE)
write.table(cLar_genRA, file = "cLar_genRA.txt", sep="\t", row.names = FALSE)
write.table(fLar_genRA, file = "fLar_genRA.txt", sep="\t", row.names = FALSE)
save.image(file = "table_S6_RAs.Rdata")

# done with table_S6
########################
#### Table S6 STATS ####
########################

# first set the working directory
setwd("~/Desktop/test/analysis/table_S6/")

# read in the workspace from table_S4_functions
load("table_S6_functionsWS.Rdata")

# read in all of the formatted files from table_S6_format
cBos_phy <- read.table(file="cBos_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBos_phy <- read.table(file="fBos_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cLar_phy <- read.table(file="cLar_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fLar_phy <- read.table(file="fLar_phy_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cBos_gen <- read.table(file="cBos_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fBos_gen <- read.table(file="fBos_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
cLar_gen <- read.table(file="cLar_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)
fLar_gen <- read.table(file="fLar_gen_form.txt",header=TRUE,sep="\t",as.is=FALSE)

require(PMCMR)
require(reshape2)
require(dplyr)
# apply the functions to each data frame
# warnings may arise showing "ties present", disregard this
# first the statistical test, then the filter
# then add new column designating the statistical test
# then bind the objects together
# apply the GetSigs function to return dataframe with P < 0.05
# and then save the two dataframes
# NOTE: c57 does not need to be filtered,
# however, column 'Model' needs to be changed to 'Taxon'
cBos_phy_kw <- AutoKW(cBos_phy)
cBos_phy_kw <- IntraFilt(cBos_phy_kw)
cBos_phy_kw$Test <- "Kruskal-Wallis"
cBos_phy_wilc <- AutoWilc(cBos_phy)
cBos_phy_wilc <- IntraFilt(cBos_phy_wilc)
cBos_phy_wilc$Test <- "Pairwise Wilcoxon"
cBos_phy_stats <- rbind(cBos_phy_kw,cBos_phy_wilc)
cBos_phy_stats$FaciltyType <- "Boston-colon"
cBos_phy_sigs <- GetSigs(cBos_phy_stats)
write.table(cBos_phy_stats, file = "cBos_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(cBos_phy_sigs, file = "cBos_phy_sigs.txt", sep="\t", row.names = FALSE)

fBos_phy_kw <- AutoKW(fBos_phy)
fBos_phy_kw <- IntraFilt(fBos_phy_kw)
fBos_phy_kw$Test <- "Kruskal-Wallis"
fBos_phy_wilc <- AutoWilc(fBos_phy)
fBos_phy_wilc <- IntraFilt(fBos_phy_wilc)
fBos_phy_wilc$Test <- "Pairwise Wilcoxon"
fBos_phy_stats <- rbind(fBos_phy_kw,fBos_phy_wilc)
fBos_phy_stats$FaciltyType <- "Boston-fecal"
fBos_phy_sigs <- GetSigs(fBos_phy_stats)
write.table(fBos_phy_stats, file = "fBos_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(fBos_phy_sigs, file = "fBos_phy_sigs.txt", sep="\t", row.names = FALSE)

cLar_phy_kw <- AutoKW(cLar_phy)
cLar_phy_kw <- IntraFilt(cLar_phy_kw)
cLar_phy_kw$Test <- "Kruskal-Wallis"
cLar_phy_wilc <- AutoWilc(cLar_phy)
cLar_phy_wilc <- IntraFilt(cLar_phy_wilc)
cLar_phy_wilc$Test <- "Pairwise Wilcoxon"
cLar_phy_stats <- rbind(cLar_phy_kw,cLar_phy_wilc)
cLar_phy_stats$FaciltyType <- "Laramie-colon"
cLar_phy_sigs <- GetSigs(cLar_phy_stats)
write.table(cLar_phy_stats, file = "cLar_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(cLar_phy_sigs, file = "cLar_phy_sigs.txt", sep="\t", row.names = FALSE)

fLar_phy_kw <- AutoKW(fLar_phy)
fLar_phy_kw <- IntraFilt(fLar_phy_kw)
fLar_phy_kw$Test <- "Kruskal-Wallis"
fLar_phy_wilc <- AutoWilc(fLar_phy)
fLar_phy_wilc <- IntraFilt(fLar_phy_wilc)
fLar_phy_wilc$Test <- "Pairwise Wilcoxon"
fLar_phy_stats <- rbind(fLar_phy_kw,fLar_phy_wilc)
fLar_phy_stats$FaciltyType <- "Laramie-fecal"
fLar_phy_sigs <- GetSigs(fLar_phy_stats)
write.table(fLar_phy_stats, file = "fLar_phy_stats.txt", sep="\t", row.names = FALSE)
write.table(fLar_phy_sigs, file = "fLar_phy_sigs.txt", sep="\t", row.names = FALSE)

cBos_gen_kw <- AutoKW(cBos_gen)
cBos_gen_kw <- IntraFilt(cBos_gen_kw)
cBos_gen_kw$Test <- "Kruskal-Wallis"
cBos_gen_wilc <- AutoWilc(cBos_gen)
cBos_gen_wilc <- IntraFilt(cBos_gen_wilc)
cBos_gen_wilc$Test <- "Pairwise Wilcoxon"
cBos_gen_stats <- rbind(cBos_gen_kw,cBos_gen_wilc)
cBos_gen_stats$FaciltyType <- "Boston-colon"
cBos_gen_sigs <- GetSigs(cBos_gen_stats)
write.table(cBos_gen_stats, file = "cBos_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(cBos_gen_sigs, file = "cBos_gen_sigs.txt", sep="\t", row.names = FALSE)

fBos_gen_kw <- AutoKW(fBos_gen)
fBos_gen_kw <- IntraFilt(fBos_gen_kw)
fBos_gen_kw$Test <- "Kruskal-Wallis"
fBos_gen_wilc <- AutoWilc(fBos_gen)
fBos_gen_wilc <- IntraFilt(fBos_gen_wilc)
fBos_gen_wilc$Test <- "Pairwise Wilcoxon"
fBos_gen_stats <- rbind(fBos_gen_kw,fBos_gen_wilc)
fBos_gen_stats$FaciltyType <- "Boston-fecal"
fBos_gen_sigs <- GetSigs(fBos_gen_stats)
write.table(fBos_gen_stats, file = "fBos_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(fBos_gen_sigs, file = "fBos_gen_sigs.txt", sep="\t", row.names = FALSE)

cLar_gen_kw <- AutoKW(cLar_gen)
cLar_gen_kw <- IntraFilt(cLar_gen_kw)
cLar_gen_kw$Test <- "Kruskal-Wallis"
cLar_gen_wilc <- AutoWilc(cLar_gen)
cLar_gen_wilc <- IntraFilt(cLar_gen_wilc)
cLar_gen_wilc$Test <- "Pairwise Wilcoxon"
cLar_gen_stats <- rbind(cLar_gen_kw,cLar_gen_wilc)
cLar_gen_stats$FaciltyType <- "Laramie-colon"
cLar_gen_sigs <- GetSigs(cLar_gen_stats)
write.table(cLar_gen_stats, file = "cLar_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(cLar_gen_sigs, file = "cLar_gen_sigs.txt", sep="\t", row.names = FALSE)

fLar_gen_kw <- AutoKW(fLar_gen)
fLar_gen_kw <- IntraFilt(fLar_gen_kw)
fLar_gen_kw$Test <- "Kruskal-Wallis"
fLar_gen_wilc <- AutoWilc(fLar_gen)
fLar_gen_wilc <- IntraFilt(fLar_gen_wilc)
fLar_gen_wilc$Test <- "Pairwise Wilcoxon"
fLar_gen_stats <- rbind(fLar_gen_kw,fLar_gen_wilc)
fLar_gen_stats$FaciltyType <- "Laramie-fecal"
fLar_gen_sigs <- GetSigs(fLar_gen_stats)
write.table(fLar_gen_stats, file = "fLar_gen_stats.txt", sep="\t", row.names = FALSE)
write.table(fLar_gen_sigs, file = "fLar_gen_sigs.txt", sep="\t", row.names = FALSE)

# combine the above sigs tables together
# and save them
df_phy <- rbind(cBos_phy_sigs,fBos_phy_sigs,
cLar_phy_sigs,fLar_phy_sigs)
df_phy <- df_phy[order(df_phy$Class),]
write.table(df_phy, file = "Phy_stats.txt", sep="\t", row.names = FALSE)

df_gen <- rbind(cBos_gen_sigs,fBos_gen_sigs,
cLar_gen_sigs,fLar_gen_sigs)
df_gen <- df_gen[order(df_gen$Class),]
write.table(df_gen, file = "Gen_stats.txt", sep="\t", row.names = FALSE)

# save the workspace
save.image(file = "table_S6_statsWS.Rdata")

# proceed to table_S6_RAs.R

