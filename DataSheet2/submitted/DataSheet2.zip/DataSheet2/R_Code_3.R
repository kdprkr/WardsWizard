########################################################
################ INTERNAL FUNCTIONS ####################
########################################################

# define several functions to make figure construction "smoother"

# (dendrograms) read in format file
read.ffile <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# (PcoA) read in mapping file
read.map <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# read in distance matrix, output from QIIME1: beta_diversity.py
read.dm <- function(file=""){
  file <- as.dist(read.table(file, header=TRUE, sep="\t", 
                             as.is=TRUE, row.name=1))
  return(file)
}

# (dendrograms) perform hierarchical clustering using the UGPMA method
require(pvclust)
clust.upgma <- function(data, nboot){
  pv.clust <- pvclust(as.matrix(data), method.hclust="average",
                      nboot=nboot)
  return(pv.clust)  
}

# (dendrograms) format the format file
require(dendextend)
format.ffile <- function(data,format.file=data.frame){
  # convert class pvclust to class hclust
  h.clust <- as.hclust(data)
  # create a data frame of existing tip labels
  df.tiplabs <- data.frame(h.clust$labels)
  # change column 1 to "HC.labels"
  names(df.tiplabs)[1] <- "HC.labels"
  # merge df.tiplabs with the format file
  df.merge <- merge(df.tiplabs, format.file, by="HC.labels", 
                    sort=FALSE, all=FALSE)
  return(df.merge)
}

# (dendrograms) format user-defined tip labels
tip.labs <- function(data,format.file=data.frame,whichcol){
  # define new tip labels
  h.clust.newlabs <- as.hclust(data)
  h.clust.newlabs$labels <- c(paste(whichcol))
  return(h.clust.newlabs)
}

# (dendrograms) format user-defined colors for the tip labels
require(dendextend)
tip.cols <- function(data,format.file=data.frame,whichcol){
  # convert class hclust to class dendrogram
  dend <- as.dendrogram(data)
  # paste hex color codes from the format file into a vector
  hex.cols <- paste(whichcol)
  # paste in '#' before each hex code (for proper formating)
  hex.cols.form <- paste("#", sep="", hex.cols)
  # define the tip label colors
  dend.cols <- dend
  labels_colors(dend.cols) <- hex.cols.form[order.dendrogram(dend.cols)]
  return(dend.cols)
}

# (dendrograms) ggplot for UPGMA dendrograms
require(ggplot2)
require(rKIN)
dend.plot <- function(data, ylim.min, offst.lbl, title="", subtitle=""){
  dendplot <- ggplot(as.ggdend(data), offset_labels=offst.lbl) +
    ylim(min(ylim.min), max(get_branches_heights(data))) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(dendplot)
}

# (dendrograms) add custom UPGMA dendrogram plot theme
require(ggplot2)
dend.theme <- function(ggplot, ttl.size, sub.ttl.size, font.fam){
  dendtheme <- ggplot +
    # global theme
    theme_dendro() +
    # title and subtitle parameters
    #theme(plot.title=element_text(hjust=0, size=ttl.size),
    #      plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size)) +
    theme(plot.title=element_text(size=ttl.size, margin=margin(t=0, b=-9)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=-2))) +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(dendtheme)
}

# (dendrograms) define a function which extracts the au and bp values from a pvclust object
# and rounds all numeric values to specified number of digits
# and converts all numeric values into a percentage
extrct.pvals.do.math <- function(data, digits){
  # create a data.frame of pvclust edges
  df1 <- data$edges
  # retain the au and bp column
  df2 <- df1[,1:2]
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df2, mode) =='numeric'
  # round all numeric values to specified digits
  df2[num.cols] <- round(df2[num.cols], digits=digits)
  # convert all numeric values to a percentage
  df2[num.cols] <- df2[num.cols]*100
  return(df2)
}

# (dendrograms) define a function to extract x and y coordinates of internal nodes from a dendrogram object
require(dendextend)
intrnl.node.coords <- function(data){
  # create data frame of xy coords
  df1 <- as.data.frame(get_nodes_xy(data))
  # change columns names to x and y
  df2 <- df1
  names(df2)[1] <- "x"
  names(df2)[2] <- "y"
  # create a vector of row #'s, based upon which rows of in column y are equal to 0
  zero.row <- which(df2$y == 0)
  # remove those rows from the data.frame
  df3 <- df2[-zero.row,]
  # renumber the rows
  row.names(df3) <- 1:nrow(df3)
  return(df3)
} 

# (PCoA) isolate PC1 and PC2 axis percentages (aka the relative_eig values)
# these will become our X and Y axis labels
iso.PC <- function(data){
  # convert pcoa$values into a data frame
  df.vals <- data.frame(data$values)
  # create a vector of the first two relative_eig values
  vec.rel.eigs <- df.vals$Relative_eig[1:2]
  return(vec.rel.eigs)
}

# (PCoA) isolate dot (aka sample) coordinates
iso.coords <- function(data){
  # convert pcoa$vectors into a data frame
  df.vec <- data.frame(data$vec)
  # isolate column 1 and 2 (x and y)
  xy.coords <- df.vec[, 1:2]
  # rename the columns 1 and 2
  names(xy.coords)[1] <- "X.Coord"
  names(xy.coords)[2] <- "Y.Coord"
  # convert column 0 into a column title SampleID
  xy.coords <- data.frame(SampleID=row.names(xy.coords), xy.coords)  
  # convert SampleID to a character
  xy.coords$SampleID <- as.character(xy.coords$SampleID)
  return(xy.coords)
}

# (PCoA) plotKIN and ggplot2 PCoA plot
require(ggplot2)
require(rKIN)
pcoa.plot <- function(data, scaler, xlab, ylab, title="", subtitle="", alpha){
  pcoaplot <- plotKIN(data, scaler=scaler, xlab=xlab, ylab=ylab, alpha=alpha) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(pcoaplot)
}

# (PCoA) add custom PCoA plot theme
require(ggplot2)
pcoa.theme <- function(ggplot, ttl.size, sub.ttl.size, 
                       axs.txt.size, font.fam){
  pcoatheme <- ggplot +
    # global theme
    theme_bw() +
    # blank the plot background/grids, bold the border
    theme(panel.background=element_blank(),
          panel.grid=element_blank(),
          panel.border=element_rect(fill=NA, color="black", size=1.1)) +
    # title and subtitle parameters
    theme(plot.title=element_text(hjust=-0.13, size=ttl.size, margin=margin(t=6,b=-9)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=4,b=1))) +
    # axis parameters
    theme(axis.text=element_blank(),
          axis.ticks=element_blank(),
          axis.title=element_text(size=axs.txt.size)) +
    # remove the legend
    theme(legend.position="none") +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(pcoatheme)
}

# output from QIIME1: summarize_taxa.py
read.taxa <- function(file=""){
  file <- read.delim(file, header=TRUE, sep="\t", 
                     as.is=TRUE, stringsAsFactors=FALSE)
  return(file)
}

# define a function to truncate the column names of a taxonomy table to the Phylum level
trnc.phy <- function(colName){
  newname <- "SampleID"
  for(i in 2:length(colName)){
    p <- strsplit(colName[i], ".p__")[[1]][2]
    # save phylum name
    newname<- c(newname, paste("", strsplit(p, "\\.")[[1]][1], sep=""))
  }
  return(newname)
}

# define a function which converts all numeric values in a data.frame into a percentage
calc.prcnt <- function(data=data.frame){
  df1 <- data
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df1, mode) =='numeric'
  # convert all numeric values to a percentage
  df1[num.cols] <- df1[num.cols]*100
  return(df1)
}

# define a function to keep any column (excluding SampleID and Other)...
# with any row possessing greater than X% abundance
get.cols.ra <- function(data=data.frame, threshold){
  goodCol <- as.integer()
  for(i in 2:ncol(data)){
    col <- which(data[,i] > threshold)
    if(length(col)>0) goodCol <- c(goodCol, i)
  }
  return(goodCol)
}

# ggplot for stacked phylum bars
require(ggplot2)
phy.plot <- function(data, col.x, col.y, col.fll, title="", subtitle="", x.axis.lab="", y.axis.lab="", fll.lab="", vals.fll, y.lims){
  phyplot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], fill=names(data)[col.fll]) +
    geom_bar(stat="identity") + 
    ggplot2::labs(title=title, subtitle=subtitle, x=x.axis.lab, y=y.axis.lab, fill=fll.lab) +
    scale_fill_manual(values=vals.fll) +
    scale_y_continuous(limits=y.lims, expand=c(0,0)) +
    scale_x_continuous(expand=c(0,0.1))
  return(phyplot)
}

# add custom stacked phylum bar plot theme
require(ggplot2)
phy.theme <- function(ggplot, ttl.size, sub.ttl.size, axs.ttl.size, axs.txt.size, font.fam){
  phytheme <- ggplot +
    # global theme
    theme_bw() +
    # remove facet labels at the top
    theme(strip.text.x = element_blank()) +
    # blank the plot background/grids, bold the border
    theme(panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(),
          panel.border=element_rect(fill=NA, size=1.1, color="black")) +
    # title and subtitle parameters
    theme(plot.title=element_text(hjust=-0.36, size=ttl.size, margin=margin(t=0,b=-4)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=4))) +
    # axis parameters
    theme(axis.title=element_text(size=axs.ttl.size, face="bold"),
          axis.text=element_text(size=axs.txt.size)) +
    # remove the legend
    theme(legend.position="none") +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(phytheme)
}

# ggplot for custom legend using shapes
require(ggplot2)
lgnd.plot <- function(data, col.x, col.y, col.clr, col.shp, col.fll, alpha, labs.ttl, lbls, vals.fll, vals.clr, vals.shp){
  lgnd.plot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], color=names(data)[col.clr],
                        shape=names(data)[col.shp], fill=names(data)[col.fll]) +
    geom_point(stroke=0, size=4, alpha=alpha) +
    scale_fill_manual(values=vals.fll, labels=lbls) +
    scale_color_manual(values=vals.clr, labels=lbls) +
    scale_shape_manual(values=vals.shp, labels=lbls)
  return(lgnd.plot)
}

# ggplot theme for custom horizontal legend using shapes
lgnd.theme <- function(ggplot, txt.size, lgnd.shp.size, font.fam){
  cstm.lgnd.theme <- ggplot +
    # global theme
    theme_bw() +
    # fill the plot with a white rectangle, blank the grid and the border
    theme(plot.background=element_rect(fill="white"),
          panel.ontop=TRUE,
          panel.border=element_blank(),
          panel.grid=element_blank()) +
    # axis parameters - blank all
    theme(axis.ticks=element_blank(),
          axis.title=element_blank(),
          axis.text=element_blank()) +
    # horizontal legend parameters
    theme(legend.position=c(0.5,0.5),
          legend.direction="vertical",
          legend.title=element_blank(),
          legend.text=element_text(size=txt.size, lineheight=0.001)) +
    guides(color=guide_legend(label=TRUE, override.aes=list(size=lgnd.shp.size))) +
    theme(text=element_text(family=font.fam))
  return(cstm.lgnd.theme) 
} 

########################################################
################ Read in "global" files ################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/")

# format file (needed for dendograms)
format_file <- read.ffile(file="c57_R_format_file.txt")

# map (needed for PCoA)
map_file <- read.map(file="c57_R_map.txt")

###########################################
################ FIGURE 4 #################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_4/")

# read in the distance matrices
# NOTE: we will build A and B first, then C, then D
f4A_dm <- read.dm(file="uw_c57.txt")
f4B_dm <- read.dm(file="w_c57.txt")

# perform UPGMA clustering on the dm
f4A_pvc <- clust.upgma(data=f4A_dm, nboot=10000)
f4B_pvc <- clust.upgma(data=f4B_dm, nboot=10000)

# format the pvc data with the format file
f4A_form <- format.ffile(data=f4A_pvc, format.file=format_file)
f4B_form <- format.ffile(data=f4B_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
f4A_hc <- tip.labs(data=f4A_pvc, format.file=f4A_form, whichcol=f4A_form$HC.facility)
f4B_hc <- tip.labs(data=f4B_pvc, format.file=f4B_form, whichcol=f4B_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
f4A_dend <- tip.cols(data=f4A_hc, format.file=f4A_form, whichcol=f4A_form$HC.colorfacility)
f4B_dend <- tip.cols(data=f4B_hc, format.file=f4B_form, whichcol=f4B_form$HC.colorfacility)

# define tip label size
labels_cex(f4A_dend) <- 0.4
labels_cex(f4B_dend) <- 0.4

# define branch line width
f4A_dend <- assign_values_to_branches_edgePar(dend=f4A_dend, value=0.75, edgePar="lwd")
f4B_dend <- assign_values_to_branches_edgePar(dend=f4B_dend, value=0.75, edgePar="lwd")

# ggplot
f4A_plot <- dend.plot(data=f4A_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="A", subtitle="Unweighted UniFrac\nC57BL/6J Mice")
f4B_plot <- dend.plot(data=f4B_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="B", subtitle="Weighted UniFrac\nC57BL/6J Mice")

# add theme
f4A_plot <- dend.theme(ggplot=f4A_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")
f4B_plot <- dend.theme(ggplot=f4B_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(f4A_pvc) # edges 18 and 17
plot(f4B_pvc) # edges 18 - 16 - 14 - 13 - 12

# Step 2:
# create a data.frame of all the AU/BP values
f4A_pvals_all <- extrct.pvals.do.math(f4A_pvc, digits=2)
f4B_pvals_all <- extrct.pvals.do.math(f4B_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
f4A_pvals_flt <- f4A_pvals_all[c(18,17),]
f4A_pvals_flt[] <- lapply(f4A_pvals_flt, as.character)
row.names(f4A_pvals_flt) <- 1:nrow(f4A_pvals_flt)
f4B_pvals_flt <- f4B_pvals_all[c(18,16,14,13,12),]
f4B_pvals_flt[] <- lapply(f4B_pvals_flt, as.character)
row.names(f4B_pvals_flt) <- 1:nrow(f4B_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
f4A_nodes_all <- intrnl.node.coords(f4A_dend)
f4B_nodes_all <- intrnl.node.coords(f4B_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
f4A_plot.x <- f4A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,20), breaks=c(1:20))
f4B_plot.x <- f4B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,20), breaks=c(1:20))
print(f4A_plot.x) # ~13.5 and ~3.5
print(f4B_plot.x) # ~15.75 ~12.75 ~6.25 ~11.5 ~ 9.5

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
f4A_nodes_flt <- f4A_nodes_all[c(11,2),]
row.names(f4A_nodes_flt) <- 1:nrow(f4A_nodes_flt)
f4B_nodes_flt <- f4B_nodes_all[c(11,12,2,13,10),]
row.names(f4B_nodes_flt) <- 1:nrow(f4B_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
f4A_labs <- cbind(f4A_pvals_flt, f4A_nodes_flt)
f4A_labs$clr <- "#ffffff"
f4B_labs <- cbind(f4B_pvals_flt, f4B_nodes_flt)
f4B_labs$clr <- "#ffffff"

# ggplot with AU % labels
f4A_plot.frmt <- f4A_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=10.7, xmax=20.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=10.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f4A_labs, label=f4A_labs$au, x=f4A_labs$x, y=f4A_labs$y,
             color=f4A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1.75,0), "lines"))

f4B_plot.frmt <- f4B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=12.7, xmax=20.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=8.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f4B_labs, label=f4B_labs$au, x=f4B_labs$x, y=f4B_labs$y,
             color=f4B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1.75,0), "lines"))

# set the working directory
setwd("~/Desktop/r_analysis/fig_4/")

# read in the distance matrix for C
f4C_dm <- read.dm(file="c57core50.txt")

require(ape)
# using package ape, perform principal coordinates analysis
f4C_pcoa <- pcoa(f4C_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
f4C_eigs <- iso.PC(f4C_pcoa)

# create the axis labels
f4C_PC1 <- paste("PC 1 (", round(f4C_eigs[1]*100,0), "%)\n", sep ="")
f4C_PC2 <- paste("PC 2 (", round(f4C_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
f4C_coords <- iso.coords(f4C_pcoa)

# merge in metadata from map
f4C_df <- merge(x=map_file, y=f4C_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
f4C_df$fac.clr <- c("#762a83","#762a83","#762a83","#762a83","#762a83",
                    "#762a83","#762a83","#762a83","#762a83","#762a83",
                    "#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#1b7837","#1b7837","#1b7837","#1b7837","#1b7837")

# add shapes
f4C_df$fac.shp <- c(17,17,17,17,17,17,17,17,17,17,
                    16,16,16,16,16,16,16,16,16,16)
                    
require(rKIN)
# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
f4C_ell <- estEllipse(f4C_df, x="X.Coord", y="Y.Coord", group="Facility",
                      levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
f4C_olap <- calcOverlap(f4C_ell)

# plot with defaults
f4C_plot <- pcoa.plot(data=f4C_ell, xlab=f4C_PC1, ylab=f4C_PC2, scaler=0.05, 
                      title="C", subtitle="Weighted UniFrac - C57BL/6J Mice", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
f4C_plot <- pcoa.theme(ggplot=f4C_plot, ttl.size=13, sub.ttl.size=9, 
                       axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=4) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(0,0.25,0,-0.5), "lines"))
print(f4C_plot)

# customize points
f4C_plot.frmt <- f4C_plot +
  geom_point(inherit.aes=FALSE, data=f4C_df, x=f4C_df$X.Coord, y=f4C_df$Y.Coord,
             shape=f4C_df$fac.shp, color=f4C_df$fac.clr, alpha=1, size=1.5, stroke=0)

# add in overlap percentage labels
# create vectors with percentage values, round them, multiply them
vec1.olap <- round(f4C_olap[2,2], digits=2)*100
vec2.olap <- round(f4C_olap[1,3], digits=2)*100

# create the labels
lab1.olap <- paste("Bos/Lar overlap = ", vec1.olap, "%", sep ="")
lab2.olap <- paste("Lar/Bos overlap = ", vec2.olap, "%", sep ="")

# create vectors with x and y coordinates for labels and shading
x.lab.olap <- 0.25
y.lab.olap <- c(-0.16, -0.18)

# create a data.frame using the vectors above
olap.labs <- data.frame("label"=c(lab1.olap, lab2.olap), "x.lab"=x.lab.olap, 
                        "y.lab"=y.lab.olap, "clr"=c("#252525","#252525"))

# plot f4C_plot.frmt with overlap percentage labels
f4C_plot.frmt.olap <- f4C_plot.frmt +
  geom_text(data=olap.labs, label=olap.labs$label, x=olap.labs$x.lab, y=olap.labs$y.lab, 
            color=olap.labs$clr, size=2.4, family="Helvetica")
print(f4C_plot.frmt.olap)

# set the working directory
setwd("~/Desktop/r_analysis/fig_4/")

# read in the output from QIIME 1: summarize_taxa.py
f4D_phy <- read.taxa(file="c57_phylum.txt")

# remove unwanted columns
# print names
# create a data.frame of unwanted columns
# create a vector from the unwanted column names
# remove columns from the data.frame
names(f4D_phy)
cols <- f4D_phy[,2:10]
cols <- names(cols)
rm_cols <- which(names(f4D_phy) %in% cols)
f4D_phy <- f4D_phy[, - c(rm_cols)]

# change column 2 name from: "Unassigned.Other" to "k__Unassigned.p__Unassigned"
# change column 3 name from: "k__Bacteria.Other" to "k__Bacteria.p__Other1"
# check name, change, check the change
# NOTE: without changes, these columns will cause a foramtting error in the functions below
names(f4D_phy)[2]
names(f4D_phy)[2] <- "k__Unassigned.p__Unassigned"
names(f4D_phy)[2]
names(f4D_phy)[3]
names(f4D_phy)[3] <- "k__Bacteria.p__Other1"
names(f4D_phy)[3]

# tuncate column names
names(f4D_phy) <- trnc.phy(names(f4D_phy))

# convert decimals to percentages
f4D_phy <- calc.prcnt(f4D_phy)

# search the data.frame for columns with relative abundance above X%
# and create a vector of columns names
f4D_high_cols <- get.cols.ra(data=f4D_phy, threshold=5.99)

# create a new data.frame with high relative abundance phyla
f4D_df_abv <- f4D_phy[,c(1:1, f4D_high_cols)]

# create a new data.frame with low relative abundance phyla
f4D_df_blw <- f4D_phy[,-c(0:0, f4D_high_cols)]

# sum phyla in df_blw, add them to Other (exclude SampleID and Unassigned)
f4D_df_blw$Other <- rowSums(f4D_df_blw[,-c(1,2)])

# retain only columns SampleID, Unassigned, Other
f4D_df_blw <- f4D_df_blw[,c("SampleID","Unassigned", "Other")]

# merge df_abv and df_blo by SampleID
f4D_df_all <- merge(f4D_df_abv, f4D_df_blw, by="SampleID", all.x = TRUE, sort = FALSE)

# merge in the metadata from the map_file
f4D_df_all <- merge(f4D_df_all, map_file, by="SampleID", all.x=TRUE, sort=FALSE)

require(dplyr)
# using package dplyr summarize and group each Phylum by GroupFacilityType
# first print the column names
# add phylum name to new column: 'Phylum'
names(f4D_df_all)
Act <- summarise(group_by(f4D_df_all, Facility),
                 Mean=mean(Actinobacteria))
Act$Phylum <- "Actinobacteria"

Bact <- summarise(group_by(f4D_df_all, Facility),
                  Mean=mean(Bacteroidetes))
Bact$Phylum <- "Bacteroidetes"

Firm <- summarise(group_by(f4D_df_all, Facility),
                  Mean=mean(Firmicutes))
Firm$Phylum <- "Firmicutes"

Una <- summarise(group_by(f4D_df_all, Facility),
                 Mean=mean(Unassigned))
Una$Phylum <- "Unassigned"

Oth <- summarise(group_by(f4D_df_all, Facility),
                 Mean=mean(Other))
Oth$Phylum <- "Other"

# we want to filter any of the mean relative abundances that are below 6%
# if any two values in column 'Mean' (column 7) are above 5.99...
# ... then we want to keep the entire Phylum
# So, if the test dataframe has any observations, we retain the Phylum
# if the test dataframe has 0 obs, we need to add this Phylum to 'Other'
test_Act <- Act[which(Act[,2]> 5.99),] # 0 obs.
test_Bact <- Bact[which(Bact[,2]> 5.99),] # 2 obs.
test_Firm <- Firm[which(Firm[,2]> 5.99),] # 2 obs.

# add Act, to the mean in column Oth
Oth$Mean <- Oth$Mean + Act$Mean

# combine the data.frames
# add in scale to match each Phylum with Facility
f4D_df_phy <- rbind(Bact,Firm,Una,Oth)
f4D_df_phy$scale <- c(1,2)

# define the locations of each phylum within each stack
# aka where the bars of each phylum stack in each column
lvls <- c("Unassigned","Other","Bacteroidetes","Firmicutes")
f4D_df_phy$Phylum <- factor(f4D_df_phy$Phylum, levels=lvls)

# define the colors for each phylum
# 102372 is TARDIS blue for the eleventh doctor, kudos if that's releveant to you
# grayscale
PhyCols<- c("#43a2ca","#102372","#636363","#252525")

# define facility labels found below each column
# combine them into one data frame
t1 <- data.frame(xpos=1, ypos=-2.2, label="Boston", clr="#1b7837", shp=16,
                 Facility=factor("Boston", levels=c("Boston","Laramie")))
t2 <- data.frame(xpos=2, ypos=-2.3, label="Laramie", clr="#762a83", shp=17,
                 Facility=factor("Laramie", levels=c("Boston","Laramie")))
txt <- rbind(t1,t2)

# ggplot with shapes for facility
# col.x = scale, col.y = Mean, col.fll = Phylum
f4D_plot <- phy.plot(data=f4D_df_phy, col.x=4, col.y=2, col.fll=3,
                     title="D", subtitle="C57BL/6J Mice", x.axis.lab="Facility",
                     y.axis.lab="Mean Relative Abundance (%)", 
                     fll.lab="Phylum\n", vals.fll=PhyCols, y.lims=c(-5.85,101)) +
  geom_point(data=txt, color=txt$clr, shape=txt$shp, x=txt$xpos, y=txt$ypos,
             stroke=0, size=2, inherit.aes=FALSE)

# add custom theme, blank x axis breaks and labels
f4D_plot.frmt <- phy.theme(ggplot=f4D_plot, ttl.size=13, sub.ttl.size=9,
                           axs.ttl.size=9, axs.txt.size=7, font.fam="Helvetica") +
  theme(axis.text.x=element_blank(), axis.ticks.x=element_blank())

# create custom legends (one for facility shapes, one for phylum colors)

# facility shapes/colors
# create vector in order to create data.frame
vec.fac.x <- c(1,2)
vec.fac.y <- 1
vec.fac.lbl <- c("Boston","Laramie")
df_lgnd.fac <- data.frame("x"=vec.fac.x, "y"=vec.fac.y, "fax"=vec.fac.lbl)

# define the legend title and labels
lbls.fac <- c("Boston          ","Laramie          ")

# define shapes and colors for each patient
# contrast color scheme
fac.shp <- c(16,17)
fac.fll <- c("#1b7837","#762a83")

# ggplot
lgnd.fac <- lgnd.plot(data=df_lgnd.fac, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                      alpha=1, lbls=lbls.fac, vals.fll=fac.fll, vals.clr=fac.fll, vals.shp=fac.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd.fac <- lgnd.theme(ggplot=lgnd.fac, txt.size=7, lgnd.shp.size=3, font.fam="Helvetica")

# phylum colors
# create vector in order to create data.frame
vec.phy.x <- c(1:4)
vec.phy.y <- 1
vec.phy.lbl <- c("Unassigned","Other","Bacteroidetes","Firmicutes")
df_lgnd.phy <- data.frame("x"=vec.phy.x, "y"=vec.phy.y, "fax"=vec.phy.lbl)

# define the legend labels
lbls.phy <- c("Unassigned  ","Other  ","Bacteroidetes  ","Firmicutes  ")

# define shapes and colors for each patient
# contrast color scheme
phy.shp <- c(15,15,15,15)
phy.fll <- c("#43a2ca","#102372","#636363","#252525")

# ggplot
lgnd.phy <- lgnd.plot(data=df_lgnd.phy, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                      alpha=1, lbls=lbls.phy, vals.fll=phy.fll, vals.clr=phy.fll, vals.shp=phy.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd.phy <- lgnd.theme(ggplot=lgnd.phy, txt.size=7, lgnd.shp.size=4.5, font.fam="Helvetica")

# arrange Figure 4D into panels to add legends
require(grid)
require(gridExtra)
f4D_plot.frmt.lgnd <- grid.arrange(f4D_plot.frmt, lgnd.phy, lgnd.fac, 
                                   ncol=2, nrow=2,
                                   layout_matrix=rbind(c(1,1,2), c(1,1,3)))

# arrange plots into panels
require(grid)
require(gridExtra)
fig_4 <- grid.arrange(f4A_plot.frmt, f4B_plot.frmt, f4C_plot.frmt.olap, f4D_plot.frmt.lgnd,
                      ncol=2, nrow=2, layout_matrix=rbind(c(1,1,2,2), c(3,3,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_4/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_4.tiff", plot=fig_4, dpi=600, width=150, height=150, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S8 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s8_fig/")

# read in the distance matrices
# NOTE: A and C will be the same data, formatted by sex or cage
# NOTE: B and D will be the same data, formatted by sex or cage
sf8AC_dm <- read.dm(file="uw_c57.txt")
sf8BD_dm <- read.dm(file="w_c57.txt")

# perform UPGMA clustering on the dm
sf8AC_pvc <- clust.upgma(data=sf8AC_dm, nboot=10000)
sf8BD_pvc <- clust.upgma(data=sf8BD_dm, nboot=10000)

# format the pvc data with the format file
sf8AC_form <- format.ffile(data=sf8AC_pvc, format.file=format_file)
sf8BD_form <- format.ffile(data=sf8BD_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf8A_hc <- tip.labs(data=sf8AC_pvc, format.file=sf8AC_form, whichcol=sf8AC_form$HC.facsex)
sf8B_hc <- tip.labs(data=sf8BD_pvc, format.file=sf8BD_form, whichcol=sf8BD_form$HC.facsex)
sf8C_hc <- tip.labs(data=sf8AC_pvc, format.file=sf8AC_form, whichcol=sf8AC_form$HC.faccage)
sf8D_hc <- tip.labs(data=sf8BD_pvc, format.file=sf8BD_form, whichcol=sf8BD_form$HC.faccage)

# define tip colors (from the format file column), creates 'dendrogram' object
# NOTE: sf8C and sf8D will not be fully colorblind friendly...
# the labels serve to distinguish each group
sf8A_dend <- tip.cols(data=sf8A_hc, format.file=sf8AC_form, whichcol=sf8AC_form$HC.colorfacsex)
sf8B_dend <- tip.cols(data=sf8B_hc, format.file=sf8BD_form, whichcol=sf8BD_form$HC.colorfacsex)
sf8C_dend <- tip.cols(data=sf8C_hc, format.file=sf8AC_form, whichcol=sf8AC_form$HC.colorfaccage)
sf8D_dend <- tip.cols(data=sf8D_hc, format.file=sf8BD_form, whichcol=sf8BD_form$HC.colorfaccage)

# define tip label size
labels_cex(sf8A_dend) <- 0.36
labels_cex(sf8B_dend) <- 0.36
labels_cex(sf8C_dend) <- 0.36
labels_cex(sf8D_dend) <- 0.36

# define branch line width
sf8A_dend <- assign_values_to_branches_edgePar(dend=sf8A_dend, value=0.75, edgePar="lwd")
sf8B_dend <- assign_values_to_branches_edgePar(dend=sf8B_dend, value=0.75, edgePar="lwd")
sf8C_dend <- assign_values_to_branches_edgePar(dend=sf8C_dend, value=0.75, edgePar="lwd")
sf8D_dend <- assign_values_to_branches_edgePar(dend=sf8D_dend, value=0.75, edgePar="lwd")

# ggplot
sf8A_plot <- dend.plot(data=sf8A_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="A", subtitle="Unweighted UniFrac\nC57BL/6J Sex")
sf8B_plot <- dend.plot(data=sf8B_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="B", subtitle="Weighted UniFrac\nC57BL/6J Sex")
sf8C_plot <- dend.plot(data=sf8C_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="C", subtitle="Unweighted UniFrac\nC57BL/6J Cage")
sf8D_plot <- dend.plot(data=sf8D_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="D", subtitle="Weighted UniFrac\nC57BL/6J Cage")

# add theme
sf8A_plot <- dend.theme(ggplot=sf8A_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")
sf8B_plot <- dend.theme(ggplot=sf8B_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")
sf8C_plot <- dend.theme(ggplot=sf8C_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")
sf8D_plot <- dend.theme(ggplot=sf8D_plot, ttl.size=13, sub.ttl.size=9, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(sf8AC_pvc) # edges 18 - 17 - 15 - 13 - 5 (same for A and C)
plot(sf8BD_pvc) # edges 18 - 17 (same for B and D)

# Step 2:
# create a data.frame of all the AU/BP values
sf8AC_pvals_all <- extrct.pvals.do.math(sf8AC_pvc, digits=2)
sf8BD_pvals_all <- extrct.pvals.do.math(sf8BD_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
sf8AC_pvals_flt <- sf8AC_pvals_all[c(18,17,15,13,5),]
sf8AC_pvals_flt[] <- lapply(sf8AC_pvals_flt, as.character)
row.names(sf8AC_pvals_flt) <- 1:nrow(sf8AC_pvals_flt)
sf8BD_pvals_flt <- sf8BD_pvals_all[c(18,17),]
sf8BD_pvals_flt[] <- lapply(sf8BD_pvals_flt, as.character)
row.names(sf8BD_pvals_flt) <- 1:nrow(sf8BD_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
sf8AC_nodes_all <- intrnl.node.coords(sf8A_dend)
sf8BD_nodes_all <- intrnl.node.coords(sf8B_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
sf8A_plot.x <- sf8A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,20), breaks=c(1:20))
sf8B_plot.x <- sf8B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,20), breaks=c(1:20))
print(sf8A_plot.x) # ~11 ~2 ~3 ~12 ~4
print(sf8B_plot.x) # ~11 and ~18

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
sf8AC_nodes_flt <- sf8AC_nodes_all[c(11,2,3,12,4),]
row.names(sf8AC_nodes_flt) <- 1:nrow(sf8AC_nodes_flt)
sf8BD_nodes_flt <- sf8BD_nodes_all[c(11,18),]
row.names(sf8BD_nodes_flt) <- 1:nrow(sf8BD_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
sf8AC_labs <- cbind(sf8AC_pvals_flt, sf8AC_nodes_flt)
sf8AC_labs$clr <- "#ffffff"
sf8BD_labs <- cbind(sf8BD_pvals_flt, sf8BD_nodes_flt)
sf8BD_labs$clr <- "#ffffff"

# ggplot with AU % labels
sf8A_plot.frmt <- sf8A_plot +
  # optional: add cluster shading line for Boston Cage 3
  annotate("rect", xmin=1.7, xmax=6.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#dfc27d") +
  # optional: add cluster shading line for Laramie male mice
  annotate("rect", xmin=10.7, xmax=13.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#dfc27d") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf8AC_labs, label=sf8AC_labs$au, x=sf8AC_labs$x, y=sf8AC_labs$y,
             color=sf8AC_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf8B_plot.frmt <- sf8B_plot +
  # optional: add cluster shading line for Laramie male mice
  annotate("rect", xmin=17.7, xmax=20.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#dfc27d") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf8BD_labs, label=sf8BD_labs$au, x=sf8BD_labs$x, y=sf8BD_labs$y,
             color=sf8BD_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf8C_plot.frmt <- sf8C_plot +
  # optional: add cluster shading line for Boston Cage 3
  annotate("rect", xmin=1.7, xmax=6.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#33a02c") +
  # optional: add cluster shading line for Laramie Cage 2
  annotate("rect", xmin=10.7, xmax=13.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#5e3c99") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf8AC_labs, label=sf8AC_labs$au, x=sf8AC_labs$x, y=sf8AC_labs$y,
             color=sf8AC_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf8D_plot.frmt <- sf8D_plot +
  # optional: add cluster shading line for Laramie Cage 2
  annotate("rect", xmin=17.7, xmax=20.3, ymin=-0.036, ymax=-0.025, alpha=0.55, fill="#5e3c99") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf8BD_labs, label=sf8BD_labs$au, x=sf8BD_labs$x, y=sf8BD_labs$y,
             color=sf8BD_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s8_fig <- grid.arrange(sf8A_plot.frmt, sf8B_plot.frmt, sf8C_plot.frmt, sf8D_plot.frmt,
                       ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s8_fig/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s8.tiff", plot=s8_fig, dpi=600, width=125, height=150, units="mm", 
       device="tiff", type="cairo", compression="lzw")

setwd("~/Desktop/r_analysis/")
save.image(file="R_Code_3_WS.Rdata")
