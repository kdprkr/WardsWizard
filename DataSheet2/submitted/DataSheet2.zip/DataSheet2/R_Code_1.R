########################################################
################ INTERNAL FUNCTIONS ####################
########################################################

# define several functions to make figure construction "smoother"

# (dendrograms) read in format file
read.ffile <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# (PcoA) read in mapping file
read.map <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# read in distance matrix, output from QIIME1: beta_diversity.py
read.dm <- function(file=""){
  file <- as.dist(read.table(file, header=TRUE, sep="\t", 
                             as.is=TRUE, row.name=1))
  return(file)
}

# (dendrograms) perform hierarchical clustering using the UGPMA method
require(pvclust)
clust.upgma <- function(data, nboot){
  pv.clust <- pvclust(as.matrix(data), method.hclust="average",
                      nboot=nboot)
  return(pv.clust)  
}

# (dendrograms) format the format file
require(dendextend)
format.ffile <- function(data,format.file=data.frame){
  # convert class pvclust to class hclust
  h.clust <- as.hclust(data)
  # create a data frame of existing tip labels
  df.tiplabs <- data.frame(h.clust$labels)
  # change column 1 to "HC.labels"
  names(df.tiplabs)[1] <- "HC.labels"
  # merge df.tiplabs with the format file
  df.merge <- merge(df.tiplabs, format.file, by="HC.labels", 
                    sort=FALSE, all=FALSE)
  return(df.merge)
}

# (dendrograms) format user-defined tip labels
tip.labs <- function(data,format.file=data.frame,whichcol){
  # define new tip labels
  h.clust.newlabs <- as.hclust(data)
  h.clust.newlabs$labels <- c(paste(whichcol))
  return(h.clust.newlabs)
}

# (dendrograms) format user-defined colors for the tip labels
require(dendextend)
tip.cols <- function(data,format.file=data.frame,whichcol){
  # convert class hclust to class dendrogram
  dend <- as.dendrogram(data)
  # paste hex color codes from the format file into a vector
  hex.cols <- paste(whichcol)
  # paste in '#' before each hex code (for proper formating)
  hex.cols.form <- paste("#", sep="", hex.cols)
  # define the tip label colors
  dend.cols <- dend
  labels_colors(dend.cols) <- hex.cols.form[order.dendrogram(dend.cols)]
  return(dend.cols)
}

# (dendrograms) ggplot for UPGMA dendrograms
require(ggplot2)
require(rKIN)
dend.plot <- function(data, ylim.min, offst.lbl, title="", subtitle=""){
  dendplot <- ggplot(as.ggdend(data), offset_labels=offst.lbl) +
    ylim(min(ylim.min), max(get_branches_heights(data))) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(dendplot)
}

# (dendrograms) add custom UPGMA dendrogram plot theme
require(ggplot2)
dend.theme <- function(ggplot, ttl.size, sub.ttl.size, font.fam){
  dendtheme <- ggplot +
    # global theme
    theme_dendro() +
    # title and subtitle parameters
    theme(plot.title=element_text(size=ttl.size, margin=margin(t=0, b=-7)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=-2))) +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(dendtheme)
}

# (dendrograms) define a function which extracts the au and bp values from a pvclust object
# and rounds all numeric values to specified number of digits
# and converts all numeric values into a percentage
extrct.pvals.do.math <- function(data, digits){
  # create a data.frame of pvclust edges
  df1 <- data$edges
  # retain the au and bp column
  df2 <- df1[,1:2]
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df2, mode) =='numeric'
  # round all numeric values to specified digits
  df2[num.cols] <- round(df2[num.cols], digits=digits)
  # convert all numeric values to a percentage
  df2[num.cols] <- df2[num.cols]*100
  return(df2)
}

# (dendrograms) define a function to extract x and y coordinates of internal nodes from a dendrogram object
require(dendextend)
intrnl.node.coords <- function(data){
  # create data frame of xy coords
  df1 <- as.data.frame(get_nodes_xy(data))
  # change columns names to x and y
  df2 <- df1
  names(df2)[1] <- "x"
  names(df2)[2] <- "y"
  # create a vector of row #'s, based upon which rows of in column y are equal to 0
  zero.row <- which(df2$y == 0)
  # remove those rows from the data.frame
  df3 <- df2[-zero.row,]
  # renumber the rows
  row.names(df3) <- 1:nrow(df3)
  return(df3)
} 

# (PCoA) isolate PC1 and PC2 axis percentages (aka the relative_eig values)
# these will become our X and Y axis labels
iso.PC <- function(data){
  # convert pcoa$values into a data frame
  df.vals <- data.frame(data$values)
  # create a vector of the first two relative_eig values
  vec.rel.eigs <- df.vals$Relative_eig[1:2]
  return(vec.rel.eigs)
}

# (PCoA) isolate dot (aka sample) coordinates
iso.coords <- function(data){
  # convert pcoa$vectors into a data frame
  df.vec <- data.frame(data$vec)
  # isolate column 1 and 2 (x and y)
  xy.coords <- df.vec[, 1:2]
  # rename the columns 1 and 2
  names(xy.coords)[1] <- "X.Coord"
  names(xy.coords)[2] <- "Y.Coord"
  # convert column 0 into a column title SampleID
  xy.coords <- data.frame(SampleID=row.names(xy.coords), xy.coords)  
  # convert SampleID to a character
  xy.coords$SampleID <- as.character(xy.coords$SampleID)
  return(xy.coords)
}

# (PCoA) plotKIN and ggplot2 PCoA plot
require(ggplot2)
require(rKIN)
pcoa.plot <- function(data, scaler, xlab, ylab, title="", subtitle="", alpha){
  pcoaplot <- plotKIN(data, scaler=scaler, xlab=xlab, ylab=ylab, alpha=alpha) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(pcoaplot)
}

# (PCoA) add custom PCoA plot theme
require(ggplot2)
pcoa.theme <- function(ggplot, ttl.size, sub.ttl.size, 
                       axs.txt.size, font.fam){
  pcoatheme <- ggplot +
    # global theme
    theme_bw() +
    # blank the plot background/grids, bold the border
    theme(panel.background=element_blank(),
          panel.grid=element_blank(),
          panel.border=element_rect(fill=NA, color="black", size=1.1)) +
    # title and subtitle parameters
    theme(plot.title=element_text(hjust=-0.19, size=ttl.size, margin=margin(t=0,b=-8)),
    plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=4))) +
    # axis parameters
    theme(axis.text=element_blank(),
          axis.ticks=element_blank(),
          axis.title=element_text(size=axs.txt.size)) +
    # remove the legend
    theme(legend.position="none") +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(pcoatheme)
}

# (PCoA) ggplot for custom legend using shapes
require(ggplot2)
lgnd.plot <- function(data, col.x, col.y, col.clr, col.shp, col.fll, alpha, labs.ttl, lbls, vals.fll, vals.clr, vals.shp){
  lgnd.plot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], color=names(data)[col.clr],
                        shape=names(data)[col.shp], fill=names(data)[col.fll]) +
    geom_point(stroke=0, size=4, alpha=alpha) +
    scale_fill_manual(values=vals.fll, labels=lbls) +
    scale_color_manual(values=vals.clr, labels=lbls) +
    scale_shape_manual(values=vals.shp, labels=lbls)
  return(lgnd.plot)
}

# (PCoA) ggplot theme for custom horizontal legend using shapes
lgnd.theme <- function(ggplot, txt.size, lgnd.shp.size, font.fam){
  cstm.lgnd.theme <- ggplot +
    # global theme
    theme_bw() +
    # fill the plot with a white rectangle, blank the grid and the border
    theme(plot.background=element_rect(fill="white"),
          panel.ontop=TRUE,
          panel.border=element_blank(),
          panel.grid=element_blank()) +
    # axis parameters - blank all
    theme(axis.ticks=element_blank(),
          axis.title=element_blank(),
          axis.text=element_blank()) +
    # horizontal legend parameters
    theme(legend.position=c(0.5,0.5),
          legend.direction="vertical",
          legend.title=element_blank(),
          legend.text=element_text(size=txt.size, lineheight=0.001)) +
    guides(color=guide_legend(label=TRUE, override.aes=list(size=lgnd.shp.size))) +
    theme(text=element_text(family=font.fam))
  return(cstm.lgnd.theme) 
}  

########################################################
################ Read in "global" files ################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/")

# format file (needed for dendograms)
format_file <- read.ffile(file="hscr_R_format_file.txt")

# map (needed for PCoA)
map_file <- read.map(file="hscr_R_map.txt")

##########################################
################ FIGURE 1 ################
##########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_1/")

# read in the distance matrices
f1A_dm <- read.dm(file="uw_cBL_P20WT.txt")
f1B_dm <- read.dm(file="w_cBL_P20WT.txt")
f1C_dm <- read.dm(file="uw_cBL_P20KO.txt")
f1D_dm <- read.dm(file="w_cBL_P20KO.txt")

# perform UPGMA clustering on the dm
f1A_pvc <- clust.upgma(data=f1A_dm, nboot=10000)
f1B_pvc <- clust.upgma(data=f1B_dm, nboot=10000)
f1C_pvc <- clust.upgma(data=f1C_dm, nboot=10000)
f1D_pvc <- clust.upgma(data=f1D_dm, nboot=10000)

# format the pvc data with the format file
f1A_form <- format.ffile(data=f1A_pvc, format.file=format_file)
f1B_form <- format.ffile(data=f1B_pvc, format.file=format_file)
f1C_form <- format.ffile(data=f1C_pvc, format.file=format_file)
f1D_form <- format.ffile(data=f1D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
f1A_hc <- tip.labs(data=f1A_pvc, format.file=f1A_form, whichcol=f1A_form$HC.facility)
f1B_hc <- tip.labs(data=f1B_pvc, format.file=f1B_form, whichcol=f1B_form$HC.facility)
f1C_hc <- tip.labs(data=f1C_pvc, format.file=f1C_form, whichcol=f1C_form$HC.facility)
f1D_hc <- tip.labs(data=f1D_pvc, format.file=f1D_form, whichcol=f1D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
f1A_dend <- tip.cols(data=f1A_hc, format.file=f1A_form, whichcol=f1A_form$HC.colorfacility)
f1B_dend <- tip.cols(data=f1B_hc, format.file=f1B_form, whichcol=f1B_form$HC.colorfacility)
f1C_dend <- tip.cols(data=f1C_hc, format.file=f1C_form, whichcol=f1C_form$HC.colorfacility)
f1D_dend <- tip.cols(data=f1D_hc, format.file=f1D_form, whichcol=f1D_form$HC.colorfacility)

# define tip label size
labels_cex(f1A_dend) <- 0.4
labels_cex(f1B_dend) <- 0.4
labels_cex(f1C_dend) <- 0.4
labels_cex(f1D_dend) <- 0.4

# define branch line width
f1A_dend <- assign_values_to_branches_edgePar(dend=f1A_dend, value=0.75, edgePar="lwd")
f1B_dend <- assign_values_to_branches_edgePar(dend=f1B_dend, value=0.75, edgePar="lwd")
f1C_dend <- assign_values_to_branches_edgePar(dend=f1C_dend, value=0.75, edgePar="lwd")
f1D_dend <- assign_values_to_branches_edgePar(dend=f1D_dend, value=0.75, edgePar="lwd")

# ggplot
f1A_plot <- dend.plot(data=f1A_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                      title="A", subtitle="Unweighted UniFrac\nHSCR P20-WT Colon")
f1B_plot <- dend.plot(data=f1B_dend, ylim.min=-0.31, offst.lbl=-0.062, 
                      title="B", subtitle="Weighted UniFrac\nHSCR P20-WT Colon")
f1C_plot <- dend.plot(data=f1C_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                      title="C", subtitle="Unweighted UniFrac\nHSCR P20-KO Colon")
f1D_plot <- dend.plot(data=f1D_dend, ylim.min=-0.28, offst.lbl=-0.056, 
                      title="D", subtitle="Weighted UniFrac\nHSCR P20-KO Colon")

# add theme
f1A_plot <- dend.theme(ggplot=f1A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1B_plot <- dend.theme(ggplot=f1B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1C_plot <- dend.theme(ggplot=f1C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1D_plot <- dend.theme(ggplot=f1D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(f1A_pvc) # edge 9 and 8
plot(f1B_pvc) # edge 9 and 7
plot(f1C_pvc) # edge 9 and 4
plot(f1D_pvc) # edge 9 and 8

# Step 2:
# create a data.frame of all the AU/BP values
f1A_pvals_all <- extrct.pvals.do.math(f1A_pvc, digits=2)
f1B_pvals_all <- extrct.pvals.do.math(f1B_pvc, digits=2)
f1C_pvals_all <- extrct.pvals.do.math(f1C_pvc, digits=2)
f1D_pvals_all <- extrct.pvals.do.math(f1D_pvc, digits=2)

# Step 3: 
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
f1A_pvals_flt <- f1A_pvals_all[c(9,8),]
f1A_pvals_flt[] <- lapply(f1A_pvals_flt, as.character)
row.names(f1A_pvals_flt) <- 1:nrow(f1A_pvals_flt)
f1B_pvals_flt <- f1B_pvals_all[c(9,7),]
f1B_pvals_flt[] <- lapply(f1B_pvals_flt, as.character)
row.names(f1B_pvals_flt) <- 1:nrow(f1B_pvals_flt)
f1C_pvals_flt <- f1C_pvals_all[c(9,4),]
f1C_pvals_flt[] <- lapply(f1C_pvals_flt, as.character)
row.names(f1C_pvals_flt) <- 1:nrow(f1C_pvals_flt)
f1D_pvals_flt <- f1D_pvals_all[c(9,8),]
f1D_pvals_flt[] <- lapply(f1D_pvals_flt, as.character)
row.names(f1D_pvals_flt) <- 1:nrow(f1D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
f1A_nodes_all <- intrnl.node.coords(f1A_dend)
f1B_nodes_all <- intrnl.node.coords(f1B_dend)
f1C_nodes_all <- intrnl.node.coords(f1C_dend)
f1D_nodes_all <- intrnl.node.coords(f1D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
f1A_plot.x <- f1A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                              axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1B_plot.x <- f1B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1C_plot.x <- f1C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1D_plot.x <- f1D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
print(f1A_plot.x) # ~9 and ~2
print(f1B_plot.x) # ~7 and ~2.5
print(f1C_plot.x) # ~7 and ~2.5
print(f1D_plot.x) # ~8.5 and ~2

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
f1A_nodes_flt <- f1A_nodes_all[c(7,2),]
row.names(f1A_nodes_flt) <- 1:nrow(f1A_nodes_flt)
f1B_nodes_flt <- f1B_nodes_all[c(6,2),]
row.names(f1B_nodes_flt) <- 1:nrow(f1B_nodes_flt)
f1C_nodes_flt <- f1C_nodes_all[c(6,2),]
row.names(f1C_nodes_flt) <- 1:nrow(f1C_nodes_flt)
f1D_nodes_flt <- f1D_nodes_all[c(7,2),]
row.names(f1D_nodes_flt) <- 1:nrow(f1D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
f1A_labs <- cbind(f1A_pvals_flt, f1A_nodes_flt)
f1A_labs$clr <- "#ffffff"
f1B_labs <- cbind(f1B_pvals_flt, f1B_nodes_flt)
f1B_labs$clr <- "#ffffff"
f1C_labs <- cbind(f1C_pvals_flt, f1C_nodes_flt)
f1C_labs$clr <- "#ffffff"
f1D_labs <- cbind(f1D_pvals_flt, f1D_nodes_flt)
f1D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
f1A_vecx <- f1A_nodes_all[1,1]
f1A_vecy <- f1A_nodes_all[1,2]
f1A_veclab <- as.character("AU value (%)")
f1A_root_lab <- data.frame("x"=f1A_vecx,"y"=f1A_vecy,"lab"=f1A_veclab)
f1A_root_lab$clr <- "#ffffff"
f1B_vecx <- f1B_nodes_all[1,1]
f1B_vecy <- f1B_nodes_all[1,2]
f1B_veclab <- as.character("AU value (%)")
f1B_root_lab <- data.frame("x"=f1B_vecx,"y"=f1B_vecy,"lab"=f1B_veclab)
f1B_root_lab$clr <- "#ffffff"
f1C_vecx <- f1C_nodes_all[1,1]
f1C_vecy <- f1C_nodes_all[1,2]
f1C_veclab <- as.character("AU value (%)")
f1C_root_lab <- data.frame("x"=f1C_vecx,"y"=f1C_vecy,"lab"=f1C_veclab)
f1C_root_lab$clr <- "#ffffff"
f1D_vecx <- f1D_nodes_all[1,1]
f1D_vecy <- f1D_nodes_all[1,2]
f1D_veclab <- as.character("AU value (%)")
f1D_root_lab <- data.frame("x"=f1D_vecx,"y"=f1D_vecy,"lab"=f1D_veclab)
f1D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
f1A_root_y <- f1A_root_lab[1,2] - 0.1
f1B_root_y <- f1B_root_lab[1,2] - 0.1
f1C_root_y <- f1C_root_lab[1,2] - 0.1
f1D_root_y <- f1D_root_lab[1,2] - 0.1

# ggplot with AU % labels
f1A_plot.frmt <- f1A_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=6.7, xmax=11.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1A_labs, label=f1A_labs$au, x=f1A_labs$x, y=f1A_labs$y, 
             color=f1A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1A_root_lab, label=f1A_root_lab$lab, x=f1A_root_lab$x, y=f1A_root_y,
             color=f1A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1B_plot.frmt <- f1B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=11.3, ymin=-0.0496, ymax=-0.031, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.0496, ymax=-0.031, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1B_labs, label=f1B_labs$au, x=f1B_labs$x, y=f1B_labs$y, 
             color=f1B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1B_root_lab, label=f1B_root_lab$lab, x=f1B_root_lab$x, y=f1B_root_y,
             color=f1B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1C_plot.frmt <- f1C_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=11.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1C_labs, label=f1C_labs$au, x=f1C_labs$x, y=f1C_labs$y, 
             color=f1C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1C_root_lab, label=f1C_root_lab$lab, x=f1C_root_lab$x, y=f1C_root_y,
             color=f1C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1D_plot.frmt <- f1D_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=6.7, xmax=11.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1D_labs, label=f1D_labs$au, x=f1D_labs$x, y=f1D_labs$y, 
             color=f1D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1D_root_lab, label=f1D_root_lab$lab, x=f1D_root_lab$x, y=f1D_root_y,
             color=f1D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
fig_1 <- grid.arrange(f1A_plot.frmt, f1B_plot.frmt, f1C_plot.frmt, f1D_plot.frmt,
                      ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_1")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_1.tiff", plot=fig_1, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S1 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s1_fig/")

# read in the distance matrices
sf1A_dm <- read.dm(file="uw_cBL_P07WT.txt")
sf1B_dm <- read.dm(file="w_cBL_P07WT.txt")
sf1C_dm <- read.dm(file="uw_cBL_P07KO.txt")
sf1D_dm <- read.dm(file="w_cBL_P07KO.txt")

# perform UPGMA clustering on the dm
sf1A_pvc <- clust.upgma(data=sf1A_dm, nboot=10000)
sf1B_pvc <- clust.upgma(data=sf1B_dm, nboot=10000)
sf1C_pvc <- clust.upgma(data=sf1C_dm, nboot=10000)
sf1D_pvc <- clust.upgma(data=sf1D_dm, nboot=10000)

# format the pvc data with the format file
sf1A_form <- format.ffile(data=sf1A_pvc, format.file=format_file)
sf1B_form <- format.ffile(data=sf1B_pvc, format.file=format_file)
sf1C_form <- format.ffile(data=sf1C_pvc, format.file=format_file)
sf1D_form <- format.ffile(data=sf1D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf1A_hc <- tip.labs(data=sf1A_pvc, format.file=sf1A_form, whichcol=sf1A_form$HC.facility)
sf1B_hc <- tip.labs(data=sf1B_pvc, format.file=sf1B_form, whichcol=sf1B_form$HC.facility)
sf1C_hc <- tip.labs(data=sf1C_pvc, format.file=sf1C_form, whichcol=sf1C_form$HC.facility)
sf1D_hc <- tip.labs(data=sf1D_pvc, format.file=sf1D_form, whichcol=sf1D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
sf1A_dend <- tip.cols(data=sf1A_hc, format.file=sf1A_form, whichcol=sf1A_form$HC.colorfacility)
sf1B_dend <- tip.cols(data=sf1B_hc, format.file=sf1B_form, whichcol=sf1B_form$HC.colorfacility)
sf1C_dend <- tip.cols(data=sf1C_hc, format.file=sf1C_form, whichcol=sf1C_form$HC.colorfacility)
sf1D_dend <- tip.cols(data=sf1D_hc, format.file=sf1D_form, whichcol=sf1D_form$HC.colorfacility)

# define tip label size
labels_cex(sf1A_dend) <- 0.4
labels_cex(sf1B_dend) <- 0.4
labels_cex(sf1C_dend) <- 0.4
labels_cex(sf1D_dend) <- 0.4

# define branch line width
sf1A_dend <- assign_values_to_branches_edgePar(dend=sf1A_dend, value=0.75, edgePar="lwd")
sf1B_dend <- assign_values_to_branches_edgePar(dend=sf1B_dend, value=0.75, edgePar="lwd")
sf1C_dend <- assign_values_to_branches_edgePar(dend=sf1C_dend, value=0.75, edgePar="lwd")
sf1D_dend <- assign_values_to_branches_edgePar(dend=sf1D_dend, value=0.75, edgePar="lwd")

# ggplot
sf1A_plot <- dend.plot(data=sf1A_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                      title="A", subtitle="Unweighted UniFrac\nHSCR P07-WT Colon")
sf1B_plot <- dend.plot(data=sf1B_dend, ylim.min=-0.32, offst.lbl=-0.064, 
                      title="B", subtitle="Weighted UniFrac\nHSCR P07-WT Colon")
sf1C_plot <- dend.plot(data=sf1C_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                      title="C", subtitle="Unweighted UniFrac\nHSCR P07-KO Colon")
sf1D_plot <- dend.plot(data=sf1D_dend, ylim.min=-0.30, offst.lbl=-0.06, 
                      title="D", subtitle="Weighted UniFrac\nHSCR P07-KO Colon")

# add theme
sf1A_plot <- dend.theme(ggplot=sf1A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf1B_plot <- dend.theme(ggplot=sf1B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf1C_plot <- dend.theme(ggplot=sf1C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf1D_plot <- dend.theme(ggplot=sf1D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(sf1A_pvc) # edge 8 and 7
plot(sf1B_pvc) # edge 8 and 3
plot(sf1C_pvc) # edge 7 and 6
plot(sf1D_pvc) # edge 7 and 6

# Step 2:
# create a data.frame of all the AU/BP values
sf1A_pvals_all <- extrct.pvals.do.math(sf1A_pvc, digits=2)
sf1B_pvals_all <- extrct.pvals.do.math(sf1B_pvc, digits=2)
sf1C_pvals_all <- extrct.pvals.do.math(sf1C_pvc, digits=2)
sf1D_pvals_all <- extrct.pvals.do.math(sf1D_pvc, digits=2)

# Step 3: 
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
sf1A_pvals_flt <- sf1A_pvals_all[c(8,7),]
sf1A_pvals_flt[] <- lapply(sf1A_pvals_flt, as.character)
row.names(sf1A_pvals_flt) <- 1:nrow(sf1A_pvals_flt)
sf1B_pvals_flt <- sf1B_pvals_all[c(8,3),]
sf1B_pvals_flt[] <- lapply(sf1B_pvals_flt, as.character)
row.names(sf1B_pvals_flt) <- 1:nrow(sf1B_pvals_flt)
sf1C_pvals_flt <- sf1C_pvals_all[c(7,6),]
sf1C_pvals_flt[] <- lapply(sf1C_pvals_flt, as.character)
row.names(sf1C_pvals_flt) <- 1:nrow(sf1C_pvals_flt)
sf1D_pvals_flt <- sf1D_pvals_all[c(7,6),]
sf1D_pvals_flt[] <- lapply(sf1D_pvals_flt, as.character)
row.names(sf1D_pvals_flt) <- 1:nrow(sf1D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
sf1A_nodes_all <- intrnl.node.coords(sf1A_dend)
sf1B_nodes_all <- intrnl.node.coords(sf1B_dend)
sf1C_nodes_all <- intrnl.node.coords(sf1C_dend)
sf1D_nodes_all <- intrnl.node.coords(sf1D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
sf1A_plot.x <- sf1A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
sf1B_plot.x <- sf1B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
sf1C_plot.x <- sf1C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
sf1D_plot.x <- sf1D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
print(sf1A_plot.x) # ~6 and ~2
print(sf1B_plot.x) # ~6 and ~2.5
print(sf1C_plot.x) # ~7 and ~2.25
print(sf1D_plot.x) # ~7 and ~2

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
sf1A_nodes_flt <- sf1A_nodes_all[c(5,2),]
row.names(sf1A_nodes_flt) <- 1:nrow(sf1A_nodes_flt)
sf1B_nodes_flt <- sf1B_nodes_all[c(5,2),]
row.names(sf1B_nodes_flt) <- 1:nrow(sf1B_nodes_flt)
sf1C_nodes_flt <- sf1C_nodes_all[c(6,2),]
row.names(sf1C_nodes_flt) <- 1:nrow(sf1C_nodes_flt)
sf1D_nodes_flt <- sf1D_nodes_all[c(5,2),]
row.names(sf1D_nodes_flt) <- 1:nrow(sf1D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
sf1A_labs <- cbind(sf1A_pvals_flt, sf1A_nodes_flt)
sf1A_labs$clr <- "#ffffff"
sf1B_labs <- cbind(sf1B_pvals_flt, sf1B_nodes_flt)
sf1B_labs$clr <- "#ffffff"
sf1C_labs <- cbind(sf1C_pvals_flt, sf1C_nodes_flt)
sf1C_labs$clr <- "#ffffff"
sf1D_labs <- cbind(sf1D_pvals_flt, sf1D_nodes_flt)
sf1D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
sf1A_vecx <- sf1A_nodes_all[1,1]
sf1A_vecy <- sf1A_nodes_all[1,2]
sf1A_veclab <- as.character("AU value (%)")
sf1A_root_lab <- data.frame("x"=sf1A_vecx,"y"=sf1A_vecy,"lab"=sf1A_veclab)
sf1A_root_lab$clr <- "#ffffff"
sf1B_vecx <- sf1B_nodes_all[1,1]
sf1B_vecy <- sf1B_nodes_all[1,2]
sf1B_veclab <- as.character("AU value (%)")
sf1B_root_lab <- data.frame("x"=sf1B_vecx,"y"=sf1B_vecy,"lab"=sf1B_veclab)
sf1B_root_lab$clr <- "#ffffff"
sf1C_vecx <- sf1C_nodes_all[1,1]
sf1C_vecy <- sf1C_nodes_all[1,2]
sf1C_veclab <- as.character("AU value (%)")
sf1C_root_lab <- data.frame("x"=sf1C_vecx,"y"=sf1C_vecy,"lab"=sf1C_veclab)
sf1C_root_lab$clr <- "#ffffff"
sf1D_vecx <- sf1D_nodes_all[1,1]
sf1D_vecy <- sf1D_nodes_all[1,2]
sf1D_veclab <- as.character("AU value (%)")
sf1D_root_lab <- data.frame("x"=sf1D_vecx,"y"=sf1D_vecy,"lab"=sf1D_veclab)
sf1D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
sf1A_root_y <- sf1A_root_lab[1,2] - 0.1
sf1B_root_y <- sf1B_root_lab[1,2] - 0.1
sf1C_root_y <- sf1C_root_lab[1,2] - 0.1
sf1D_root_y <- sf1D_root_lab[1,2] - 0.1

# ggplot with AU % labels
sf1A_plot.frmt <- sf1A_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=10.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf1A_labs, label=sf1A_labs$au, x=sf1A_labs$x, y=sf1A_labs$y, 
             color=sf1A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf1A_root_lab, label=sf1A_root_lab$lab, x=sf1A_root_lab$x, y=sf1A_root_y,
             color=sf1A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf1B_plot.frmt <- sf1B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=10.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf1B_labs, label=sf1B_labs$au, x=sf1B_labs$x, y=sf1B_labs$y, 
             color=sf1B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf1B_root_lab, label=sf1B_root_lab$lab, x=sf1B_root_lab$x, y=sf1B_root_y,
             color=sf1B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf1C_plot.frmt <- sf1C_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=9.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf1C_labs, label=sf1C_labs$au, x=sf1C_labs$x, y=sf1C_labs$y, 
             color=sf1C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf1C_root_lab, label=sf1C_root_lab$lab, x=sf1C_root_lab$x, y=sf1C_root_y,
             color=sf1C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf1D_plot.frmt <- sf1D_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.048, ymax=-0.03, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=4.7, xmax=9.3, ymin=-0.048, ymax=-0.03, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf1D_labs, label=sf1D_labs$au, x=sf1D_labs$x, y=sf1D_labs$y, 
             color=sf1D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf1D_root_lab, label=sf1D_root_lab$lab, x=sf1D_root_lab$x, y=sf1D_root_y,
             color=sf1D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s1_fig <- grid.arrange(sf1A_plot.frmt, sf1B_plot.frmt, sf1C_plot.frmt, sf1D_plot.frmt,
                      ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s1_fig")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s1.tiff", plot=s1_fig, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S2 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s2_fig/")

# read in the distance matrices
sf2A_dm <- read.dm(file="uw_cBL_P24WT.txt")
sf2B_dm <- read.dm(file="w_cBL_P24WT.txt")
sf2C_dm <- read.dm(file="uw_cBL_P24KO.txt")
sf2D_dm <- read.dm(file="w_cBL_P24KO.txt")

# perform UPGMA clustering on the dm
sf2A_pvc <- clust.upgma(data=sf2A_dm, nboot=10000)
sf2B_pvc <- clust.upgma(data=sf2B_dm, nboot=10000)
sf2C_pvc <- clust.upgma(data=sf2C_dm, nboot=10000)
sf2D_pvc <- clust.upgma(data=sf2D_dm, nboot=10000)

# format the pvc data with the format file
sf2A_form <- format.ffile(data=sf2A_pvc, format.file=format_file)
sf2B_form <- format.ffile(data=sf2B_pvc, format.file=format_file)
sf2C_form <- format.ffile(data=sf2C_pvc, format.file=format_file)
sf2D_form <- format.ffile(data=sf2D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf2A_hc <- tip.labs(data=sf2A_pvc, format.file=sf2A_form, whichcol=sf2A_form$HC.facility)
sf2B_hc <- tip.labs(data=sf2B_pvc, format.file=sf2B_form, whichcol=sf2B_form$HC.facility)
sf2C_hc <- tip.labs(data=sf2C_pvc, format.file=sf2C_form, whichcol=sf2C_form$HC.facility)
sf2D_hc <- tip.labs(data=sf2D_pvc, format.file=sf2D_form, whichcol=sf2D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
sf2A_dend <- tip.cols(data=sf2A_hc, format.file=sf2A_form, whichcol=sf2A_form$HC.colorfacility)
sf2B_dend <- tip.cols(data=sf2B_hc, format.file=sf2B_form, whichcol=sf2B_form$HC.colorfacility)
sf2C_dend <- tip.cols(data=sf2C_hc, format.file=sf2C_form, whichcol=sf2C_form$HC.colorfacility)
sf2D_dend <- tip.cols(data=sf2D_hc, format.file=sf2D_form, whichcol=sf2D_form$HC.colorfacility)

# define tip label size
labels_cex(sf2A_dend) <- 0.4
labels_cex(sf2B_dend) <- 0.4
labels_cex(sf2C_dend) <- 0.4
labels_cex(sf2D_dend) <- 0.4

# define branch line width
sf2A_dend <- assign_values_to_branches_edgePar(dend=sf2A_dend, value=0.75, edgePar="lwd")
sf2B_dend <- assign_values_to_branches_edgePar(dend=sf2B_dend, value=0.75, edgePar="lwd")
sf2C_dend <- assign_values_to_branches_edgePar(dend=sf2C_dend, value=0.75, edgePar="lwd")
sf2D_dend <- assign_values_to_branches_edgePar(dend=sf2D_dend, value=0.75, edgePar="lwd")

# ggplot
sf2A_plot <- dend.plot(data=sf2A_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="A", subtitle="Unweighted UniFrac\nHSCR P24-WT Colon")
sf2B_plot <- dend.plot(data=sf2B_dend, ylim.min=-0.28, offst.lbl=-0.056,
                       title="B", subtitle="Weighted UniFrac\nHSCR P24-WT Colon")
sf2C_plot <- dend.plot(data=sf2C_dend, ylim.min=-0.25, offst.lbl=-0.05,
                       title="C", subtitle="Unweighted UniFrac\nHSCR P24-KO Colon")
sf2D_plot <- dend.plot(data=sf2D_dend, ylim.min=-0.32, offst.lbl=-0.064,
                       title="D", subtitle="Weighted UniFrac\nHSCR P24-KO Colon")

# add theme
sf2A_plot <- dend.theme(ggplot=sf2A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf2B_plot <- dend.theme(ggplot=sf2B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf2C_plot <- dend.theme(ggplot=sf2C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf2D_plot <- dend.theme(ggplot=sf2D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(sf2A_pvc) # edge 8 and 3
plot(sf2B_pvc) # edge 7 and 7
plot(sf2C_pvc) # edge 5 and 2
plot(sf2D_pvc) # edge 5 and 4

# Step 2:
# create a data.frame of all the AU/BP values
sf2A_pvals_all <- extrct.pvals.do.math(sf2A_pvc, digits=2)
sf2B_pvals_all <- extrct.pvals.do.math(sf2B_pvc, digits=2)
sf2C_pvals_all <- extrct.pvals.do.math(sf2C_pvc, digits=2)
sf2D_pvals_all <- extrct.pvals.do.math(sf2D_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
sf2A_pvals_flt <- sf2A_pvals_all[c(8,3),]
sf2A_pvals_flt[] <- lapply(sf2A_pvals_flt, as.character)
row.names(sf2A_pvals_flt) <- 1:nrow(sf2A_pvals_flt)
sf2B_pvals_flt <- sf2B_pvals_all[c(8,7),]
sf2B_pvals_flt[] <- lapply(sf2B_pvals_flt, as.character)
row.names(sf2B_pvals_flt) <- 1:nrow(sf2B_pvals_flt)
sf2C_pvals_flt <- sf2C_pvals_all[c(5,2),]
sf2C_pvals_flt[] <- lapply(sf2C_pvals_flt, as.character)
row.names(sf2C_pvals_flt) <- 1:nrow(sf2C_pvals_flt)
sf2D_pvals_flt <- sf2D_pvals_all[c(5,4),]
sf2D_pvals_flt[] <- lapply(sf2D_pvals_flt, as.character)
row.names(sf2D_pvals_flt) <- 1:nrow(sf2D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
sf2A_nodes_all <- intrnl.node.coords(sf2A_dend)
sf2B_nodes_all <- intrnl.node.coords(sf2B_dend)
sf2C_nodes_all <- intrnl.node.coords(sf2C_dend)
sf2D_nodes_all <- intrnl.node.coords(sf2D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
sf2A_plot.x <- sf2A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
sf2B_plot.x <- sf2B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
sf2C_plot.x <- sf2C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,7), breaks=c(1:7))
sf2D_plot.x <- sf2D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,7), breaks=c(1:7))
print(sf2A_plot.x) # ~5.5 and ~1.75
print(sf2B_plot.x) # ~8 and ~2.5
print(sf2C_plot.x) # ~5 and ~2
print(sf2D_plot.x) # ~5 and ~1.75

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
sf2A_nodes_flt <- sf2A_nodes_all[c(4,2),]
row.names(sf2A_nodes_flt) <- 1:nrow(sf2A_nodes_flt)
sf2B_nodes_flt <- sf2B_nodes_all[c(7,2),]
row.names(sf2B_nodes_flt) <- 1:nrow(sf2B_nodes_flt)
sf2C_nodes_flt <- sf2C_nodes_all[c(4,2),]
row.names(sf2C_nodes_flt) <- 1:nrow(sf2C_nodes_flt)
sf2D_nodes_flt <- sf2D_nodes_all[c(4,2),]
row.names(sf2D_nodes_flt) <- 1:nrow(sf2D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
sf2A_labs <- cbind(sf2A_pvals_flt, sf2A_nodes_flt)
sf2A_labs$clr <- "#ffffff"
sf2B_labs <- cbind(sf2B_pvals_flt, sf2B_nodes_flt)
sf2B_labs$clr <- "#ffffff"
sf2C_labs <- cbind(sf2C_pvals_flt, sf2C_nodes_flt)
sf2C_labs$clr <- "#ffffff"
sf2D_labs <- cbind(sf2D_pvals_flt, sf2D_nodes_flt)
sf2D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
sf2A_vecx <- sf2A_nodes_all[1,1]
sf2A_vecy <- sf2A_nodes_all[1,2]
sf2A_veclab <- as.character("AU value (%)")
sf2A_root_lab <- data.frame("x"=sf2A_vecx,"y"=sf2A_vecy,"lab"=sf2A_veclab)
sf2A_root_lab$clr <- "#ffffff"
sf2B_vecx <- sf2B_nodes_all[1,1]
sf2B_vecy <- sf2B_nodes_all[1,2]
sf2B_veclab <- as.character("AU value (%)")
sf2B_root_lab <- data.frame("x"=sf2B_vecx,"y"=sf2B_vecy,"lab"=sf2B_veclab)
sf2B_root_lab$clr <- "#ffffff"
sf2C_vecx <- sf2C_nodes_all[1,1]
sf2C_vecy <- sf2C_nodes_all[1,2]
sf2C_veclab <- as.character("AU value (%)")
sf2C_root_lab <- data.frame("x"=sf2C_vecx,"y"=sf2C_vecy,"lab"=sf2C_veclab)
sf2C_root_lab$clr <- "#ffffff"
sf2D_vecx <- sf2D_nodes_all[1,1]
sf2D_vecy <- sf2D_nodes_all[1,2]
sf2D_veclab <- as.character("AU value (%)")
sf2D_root_lab <- data.frame("x"=sf2D_vecx,"y"=sf2D_vecy,"lab"=sf2D_veclab)
sf2D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
sf2A_root_y <- sf2A_root_lab[1,2] - 0.1
sf2B_root_y <- sf2B_root_lab[1,2] - 0.1
sf2C_root_y <- sf2C_root_lab[1,2] - 0.1
sf2D_root_y <- sf2D_root_lab[1,2] - 0.1

# ggplot with AU % labels
sf2A_plot.frmt <- sf2A_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=3.7, xmax=10.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf2A_labs, label=sf2A_labs$au, x=sf2A_labs$x, y=sf2A_labs$y,
             color=sf2A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf2A_root_lab, label=sf2A_root_lab$lab, x=sf2A_root_lab$x, y=sf2A_root_y,
             color=sf2A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf2B_plot.frmt <- sf2B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=7.7, xmax=10.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf2B_labs, label=sf2B_labs$au, x=sf2B_labs$x, y=sf2B_labs$y,
             color=sf2B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf2B_root_lab, label=sf2B_root_lab$lab, x=sf2B_root_lab$x, y=sf2B_root_y,
             color=sf2B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf2C_plot.frmt <- sf2C_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=3.7, xmax=7.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf2C_labs, label=sf2C_labs$au, x=sf2C_labs$x, y=sf2C_labs$y,
             color=sf2C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf2C_root_lab, label=sf2C_root_lab$lab, x=sf2C_root_lab$x, y=sf2C_root_y,
             color=sf2C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf2D_plot.frmt <- sf2D_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=4.7, xmax=7.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf2D_labs, label=sf2D_labs$au, x=sf2D_labs$x, y=sf2D_labs$y,
             color=sf2D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=sf2D_root_lab, label=sf2D_root_lab$lab, x=sf2D_root_lab$x, y=sf2D_root_y,
             color=sf2D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s2_fig <- grid.arrange(sf2A_plot.frmt, sf2B_plot.frmt, sf2C_plot.frmt, sf2D_plot.frmt,
                       ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s2_fig")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s2.tiff", plot=s2_fig, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S3 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s3_fig/")

# read in the distance matrices
sf3A_dm <- read.dm(file="uw_cLar_P07.txt")
sf3B_dm <- read.dm(file="w_cLar_P07.txt")
sf3C_dm <- read.dm(file="uw_fLar_P07.txt")
sf3D_dm <- read.dm(file="w_fLar_P07.txt")

# perform UPGMA clustering on the dm
sf3A_pvc <- clust.upgma(data=sf3A_dm, nboot=10000)
sf3B_pvc <- clust.upgma(data=sf3B_dm, nboot=10000)
sf3C_pvc <- clust.upgma(data=sf3C_dm, nboot=10000)
sf3D_pvc <- clust.upgma(data=sf3D_dm, nboot=10000)

# format the pvc data with the format file
sf3A_form <- format.ffile(data=sf3A_pvc, format.file=format_file)
sf3B_form <- format.ffile(data=sf3B_pvc, format.file=format_file)
sf3C_form <- format.ffile(data=sf3C_pvc, format.file=format_file)
sf3D_form <- format.ffile(data=sf3D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf3A_hc <- tip.labs(data=sf3A_pvc, format.file=sf3A_form, whichcol=sf3A_form$HC.cage)
sf3B_hc <- tip.labs(data=sf3B_pvc, format.file=sf3B_form, whichcol=sf3B_form$HC.cage)
sf3C_hc <- tip.labs(data=sf3C_pvc, format.file=sf3C_form, whichcol=sf3C_form$HC.cage)
sf3D_hc <- tip.labs(data=sf3D_pvc, format.file=sf3D_form, whichcol=sf3D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
sf3A_dend <- tip.cols(data=sf3A_hc, format.file=sf3A_form, whichcol=sf3A_form$HC.colorcage)
sf3B_dend <- tip.cols(data=sf3B_hc, format.file=sf3B_form, whichcol=sf3B_form$HC.colorcage)
sf3C_dend <- tip.cols(data=sf3C_hc, format.file=sf3C_form, whichcol=sf3C_form$HC.colorcage)
sf3D_dend <- tip.cols(data=sf3D_hc, format.file=sf3D_form, whichcol=sf3D_form$HC.colorcage)

# define tip label size
labels_cex(sf3A_dend) <- 0.4
labels_cex(sf3B_dend) <- 0.4
labels_cex(sf3C_dend) <- 0.4
labels_cex(sf3D_dend) <- 0.4

# define branch line width
sf3A_dend <- assign_values_to_branches_edgePar(dend=sf3A_dend, value=0.75, edgePar="lwd")
sf3B_dend <- assign_values_to_branches_edgePar(dend=sf3B_dend, value=0.75, edgePar="lwd")
sf3C_dend <- assign_values_to_branches_edgePar(dend=sf3C_dend, value=0.75, edgePar="lwd")
sf3D_dend <- assign_values_to_branches_edgePar(dend=sf3D_dend, value=0.75, edgePar="lwd")

# ggplot
sf3A_plot <- dend.plot(data=sf3A_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                       title="A", subtitle="Unweighted UniFrac\nHSCR-Laramie P07 Colon")
sf3B_plot <- dend.plot(data=sf3B_dend, ylim.min=-0.28, offst.lbl=-0.056, 
                       title="B", subtitle="Weighted UniFrac\nHSCR-Laramie P07 Colon")
sf3C_plot <- dend.plot(data=sf3C_dend, ylim.min=-0.25, offst.lbl=-0.05, 
                       title="C", subtitle="Unweighted UniFrac\nHSCR-Laramie P07 Fecal")
sf3D_plot <- dend.plot(data=sf3D_dend, ylim.min=-0.28, offst.lbl=-0.056,
                       title="D", subtitle="Weighted UniFrac\nHSCR-Laramie P07 Fecal")

# add theme
sf3A_plot <- dend.theme(ggplot=sf3A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf3B_plot <- dend.theme(ggplot=sf3B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf3C_plot <- dend.theme(ggplot=sf3C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf3D_plot <- dend.theme(ggplot=sf3D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(sf3A_pvc) # edges 7 and 2
plot(sf3B_pvc) # edges 7 - 5 - 4 - 1
plot(sf3C_pvc) # edges 8 - 6 - 5 - 4 - 3 - 1
plot(sf3D_pvc) # edges 8 and 3

# Step 2:
# create a data.frame of all the AU/BP values
sf3A_pvals_all <- extrct.pvals.do.math(sf3A_pvc, digits=2)
sf3B_pvals_all <- extrct.pvals.do.math(sf3B_pvc, digits=2)
sf3C_pvals_all <- extrct.pvals.do.math(sf3C_pvc, digits=2)
sf3D_pvals_all <- extrct.pvals.do.math(sf3D_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
sf3A_pvals_flt <- sf3A_pvals_all[c(7,2),]
sf3A_pvals_flt[] <- lapply(sf3A_pvals_flt, as.character)
row.names(sf3A_pvals_flt) <- 1:nrow(sf3A_pvals_flt)
sf3B_pvals_flt <- sf3B_pvals_all[c(7,5,4,1),]
sf3B_pvals_flt[] <- lapply(sf3B_pvals_flt, as.character)
row.names(sf3B_pvals_flt) <- 1:nrow(sf3B_pvals_flt)
sf3C_pvals_flt <- sf3C_pvals_all[c(8,6,5,4,3,1),]
sf3C_pvals_flt[] <- lapply(sf3C_pvals_flt, as.character)
row.names(sf3C_pvals_flt) <- 1:nrow(sf3C_pvals_flt)
sf3D_pvals_flt <- sf3D_pvals_all[c(8,3),]
sf3D_pvals_flt[] <- lapply(sf3D_pvals_flt, as.character)
row.names(sf3D_pvals_flt) <- 1:nrow(sf3D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
sf3A_nodes_all <- intrnl.node.coords(sf3A_dend)
sf3B_nodes_all <- intrnl.node.coords(sf3B_dend)
sf3C_nodes_all <- intrnl.node.coords(sf3C_dend)
sf3D_nodes_all <- intrnl.node.coords(sf3D_dend)

# Step 5:
# re-plot the dendrogram plots from above of, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
sf3A_plot.x <- sf3A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
sf3B_plot.x <- sf3B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
sf3C_plot.x <- sf3C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
sf3D_plot.x <- sf3D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
print(sf3A_plot.x) # ~7.5 ~6.5
print(sf3B_plot.x) # ~5.5 ~1.5 ~3.75 ~4.5
print(sf3C_plot.x) # ~7 ~5 ~1.75 ~2.5 ~5.75 ~6.5
print(sf3D_plot.x) # ~8.5 ~7.5

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
sf3A_nodes_flt <- sf3A_nodes_all[c(6,7),]
row.names(sf3A_nodes_flt) <- 1:nrow(sf3A_nodes_flt)
sf3B_nodes_flt <- sf3B_nodes_all[c(3,2,4,5),]
row.names(sf3B_nodes_flt) <- 1:nrow(sf3B_nodes_flt)
sf3C_nodes_flt <- sf3C_nodes_all[c(4,5,2,3,6,7),]
row.names(sf3C_nodes_flt) <- 1:nrow(sf3C_nodes_flt)
sf3D_nodes_flt <- sf3D_nodes_all[c(7,8),]
row.names(sf3D_nodes_flt) <- 1:nrow(sf3D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
sf3A_labs <- cbind(sf3A_pvals_flt, sf3A_nodes_flt)
sf3A_labs$clr <- "#ffffff"
sf3B_labs <- cbind(sf3B_pvals_flt, sf3B_nodes_flt)
sf3B_labs$clr <- "#ffffff"
sf3C_labs <- cbind(sf3C_pvals_flt, sf3C_nodes_flt)
sf3C_labs$clr <- "#ffffff"
sf3D_labs <- cbind(sf3D_pvals_flt, sf3D_nodes_flt)
sf3D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
sf3A_vecx <- sf3A_nodes_all[1,1]
sf3A_vecy <- sf3A_nodes_all[1,2]
sf3A_veclab <- as.character("AU value (%)")
sf3A_root_lab <- data.frame("x"=sf3A_vecx,"y"=sf3A_vecy,"lab"=sf3A_veclab)
sf3A_root_lab$clr <- "#ffffff"
sf3B_vecx <- sf3B_nodes_all[1,1]
sf3B_vecy <- sf3B_nodes_all[1,2]
sf3B_veclab <- as.character("AU value (%)")
sf3B_root_lab <- data.frame("x"=sf3B_vecx,"y"=sf3B_vecy,"lab"=sf3B_veclab)
sf3B_root_lab$clr <- "#ffffff"
sf3C_vecx <- sf3C_nodes_all[1,1]
sf3C_vecy <- sf3C_nodes_all[1,2]
sf3C_veclab <- as.character("AU value (%)")
sf3C_root_lab <- data.frame("x"=sf3C_vecx,"y"=sf3C_vecy,"lab"=sf3C_veclab)
sf3C_root_lab$clr <- "#ffffff"
sf3D_vecx <- sf3D_nodes_all[1,1]
sf3D_vecy <- sf3D_nodes_all[1,2]
sf3D_veclab <- as.character("AU value (%)")
sf3D_root_lab <- data.frame("x"=sf3D_vecx,"y"=sf3D_vecy,"lab"=sf3D_veclab)
sf3D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
sf3A_root_y <- sf3A_root_lab[1,2] - 0.1
sf3B_root_y <- sf3B_root_lab[1,2] - 0.1
sf3C_root_y <- sf3C_root_lab[1,2] - 0.1
sf3D_root_y <- sf3D_root_lab[1,2] - 0.1

# ggplot with AU % labels
sf3A_plot.frmt <- sf3A_plot +
  # add cluster shading line for mice from the same cage
  annotate("rect", xmin=5.7, xmax=7.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#636363") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf3A_labs, label=sf3A_labs$au, x=sf3A_labs$x, y=sf3A_labs$y,
             color=sf3A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=sf3A_root_lab, label=sf3A_root_lab$lab, x=sf3A_root_lab$x, y=sf3A_root_y,
        #     color=sf3A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
           #  label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf3B_plot.frmt <- sf3B_plot +
  # add cluster shading lines for mice from the same cage
  annotate("rect", xmin=0.7, xmax=2.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#ff7f00") +
  annotate("rect", xmin=3.7, xmax=5.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#636363") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf3B_labs, label=sf3B_labs$au, x=sf3B_labs$x, y=sf3B_labs$y,
             color=sf3B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=sf3B_root_lab, label=sf3B_root_lab$lab, x=sf3B_root_lab$x, y=sf3B_root_y,
   #          color=sf3B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf3C_plot.frmt <- sf3C_plot +
  # add cluster shading lines for mice from the same cage
  annotate("rect", xmin=1.7, xmax=3.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#e41a1c") +
  annotate("rect", xmin=5.7, xmax=7.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#984ea3") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf3C_labs, label=sf3C_labs$au, x=sf3C_labs$x, y=sf3C_labs$y,
             color=sf3C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=sf3C_root_lab, label=sf3C_root_lab$lab, x=sf3C_root_lab$x, y=sf3C_root_y,
   #          color=sf3C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf3D_plot.frmt <- sf3D_plot +# add cluster shading lines for mice from the same cage
  annotate("rect", xmin=6.7, xmax=8.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#984ea3") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf3D_labs, label=sf3D_labs$au, x=sf3D_labs$x, y=sf3D_labs$y,
             color=sf3D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=sf3D_root_lab, label=sf3D_root_lab$lab, x=sf3D_root_lab$x, y=sf3D_root_y,
   #          color=sf3D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s3_fig <- grid.arrange(sf3A_plot.frmt, sf3B_plot.frmt, sf3C_plot.frmt, sf3D_plot.frmt,
                       ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s3_fig")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s3.tiff", plot=s3_fig, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S4 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s4_fig/")

# read in the distance matrices
sf4A_dm <- read.dm(file="uw_cLar_P20.txt")
sf4B_dm <- read.dm(file="w_cLar_P20.txt")
sf4C_dm <- read.dm(file="uw_fLar_P20.txt")
sf4D_dm <- read.dm(file="w_fLar_P20.txt")

# perform UPGMA clustering on the dm
sf4A_pvc <- clust.upgma(data=sf4A_dm, nboot=10000)
sf4B_pvc <- clust.upgma(data=sf4B_dm, nboot=10000)
sf4C_pvc <- clust.upgma(data=sf4C_dm, nboot=10000)
sf4D_pvc <- clust.upgma(data=sf4D_dm, nboot=10000)

# format the pvc data with the format file
sf4A_form <- format.ffile(data=sf4A_pvc, format.file=format_file)
sf4B_form <- format.ffile(data=sf4B_pvc, format.file=format_file)
sf4C_form <- format.ffile(data=sf4C_pvc, format.file=format_file)
sf4D_form <- format.ffile(data=sf4D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf4A_hc <- tip.labs(data=sf4A_pvc, format.file=sf4A_form, whichcol=sf4A_form$HC.cage)
sf4B_hc <- tip.labs(data=sf4B_pvc, format.file=sf4B_form, whichcol=sf4B_form$HC.cage)
sf4C_hc <- tip.labs(data=sf4C_pvc, format.file=sf4C_form, whichcol=sf4C_form$HC.cage)
sf4D_hc <- tip.labs(data=sf4D_pvc, format.file=sf4D_form, whichcol=sf4D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
sf4A_dend <- tip.cols(data=sf4A_hc, format.file=sf4A_form, whichcol=sf4A_form$HC.colorcage)
sf4B_dend <- tip.cols(data=sf4B_hc, format.file=sf4B_form, whichcol=sf4B_form$HC.colorcage)
sf4C_dend <- tip.cols(data=sf4C_hc, format.file=sf4C_form, whichcol=sf4C_form$HC.colorcage)
sf4D_dend <- tip.cols(data=sf4D_hc, format.file=sf4D_form, whichcol=sf4D_form$HC.colorcage)

# define tip label size
labels_cex(sf4A_dend) <- 0.4
labels_cex(sf4B_dend) <- 0.4
labels_cex(sf4C_dend) <- 0.4
labels_cex(sf4D_dend) <- 0.4

# define branch line width
sf4A_dend <- assign_values_to_branches_edgePar(dend=sf4A_dend, value=0.75, edgePar="lwd")
sf4B_dend <- assign_values_to_branches_edgePar(dend=sf4B_dend, value=0.75, edgePar="lwd")
sf4C_dend <- assign_values_to_branches_edgePar(dend=sf4C_dend, value=0.75, edgePar="lwd")
sf4D_dend <- assign_values_to_branches_edgePar(dend=sf4D_dend, value=0.75, edgePar="lwd")

# ggplot
sf4A_plot <- dend.plot(data=sf4A_dend, ylim.min=-0.25, offst.lbl=-0.025,
                       title="A", subtitle="Unweighted UniFrac\nHSCR-Laramie P20 Colon")
sf4B_plot <- dend.plot(data=sf4B_dend, ylim.min=-0.31, offst.lbl=-0.031,
                       title="B", subtitle="Weighted UniFrac\nHSCR-Laramie P20 Colon")
sf4C_plot <- dend.plot(data=sf4C_dend, ylim.min=-0.25, offst.lbl=-0.025,
                       title="C", subtitle="Unweighted UniFrac\nHSCR-Laramie P20 Fecal")
sf4D_plot <- dend.plot(data=sf4D_dend, ylim.min=-0.25, offst.lbl=-0.025,
                       title="D", subtitle="Weighted UniFrac\nHSCR-Laramie P20 Fecal")

# add theme
sf4A_plot <- dend.theme(ggplot=sf4A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf4B_plot <- dend.theme(ggplot=sf4B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf4C_plot <- dend.theme(ggplot=sf4C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf4D_plot <- dend.theme(ggplot=sf4D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# no clear clusters, skip to ggplot .frmt

# ggplot with AU % labels
sf4A_plot.frmt <- sf4A_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf4B_plot.frmt <- sf4B_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf4C_plot.frmt <- sf4C_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf4D_plot.frmt <- sf4D_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s4_fig <- grid.arrange(sf4A_plot.frmt, sf4B_plot.frmt, sf4C_plot.frmt, sf4D_plot.frmt,
                       ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s4_fig")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s4.tiff", plot=s4_fig, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S5 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s5_fig/")

# read in the distance matrices
sf5A_dm <- read.dm(file="uw_cLar_P24.txt")
sf5B_dm <- read.dm(file="w_cLar_P24.txt")
sf5C_dm <- read.dm(file="uw_fLar_P24.txt")
sf5D_dm <- read.dm(file="w_fLar_P24.txt")

# perform UPGMA clustering on the dm
sf5A_pvc <- clust.upgma(data=sf5A_dm, nboot=10000)
sf5B_pvc <- clust.upgma(data=sf5B_dm, nboot=10000)
sf5C_pvc <- clust.upgma(data=sf5C_dm, nboot=10000)
sf5D_pvc <- clust.upgma(data=sf5D_dm, nboot=10000)

# format the pvc data with the format file
sf5A_form <- format.ffile(data=sf5A_pvc, format.file=format_file)
sf5B_form <- format.ffile(data=sf5B_pvc, format.file=format_file)
sf5C_form <- format.ffile(data=sf5C_pvc, format.file=format_file)
sf5D_form <- format.ffile(data=sf5D_pvc, format.file=format_file)

# define tip labels (from the format file column), creates 'hclust' object
sf5A_hc <- tip.labs(data=sf5A_pvc, format.file=sf5A_form, whichcol=sf5A_form$HC.cage)
sf5B_hc <- tip.labs(data=sf5B_pvc, format.file=sf5B_form, whichcol=sf5B_form$HC.cage)
sf5C_hc <- tip.labs(data=sf5C_pvc, format.file=sf5C_form, whichcol=sf5C_form$HC.cage)
sf5D_hc <- tip.labs(data=sf5D_pvc, format.file=sf5D_form, whichcol=sf5D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
sf5A_dend <- tip.cols(data=sf5A_hc, format.file=sf5A_form, whichcol=sf5A_form$HC.colorcage)
sf5B_dend <- tip.cols(data=sf5B_hc, format.file=sf5B_form, whichcol=sf5B_form$HC.colorcage)
sf5C_dend <- tip.cols(data=sf5C_hc, format.file=sf5C_form, whichcol=sf5C_form$HC.colorcage)
sf5D_dend <- tip.cols(data=sf5D_hc, format.file=sf5D_form, whichcol=sf5D_form$HC.colorcage)

# define tip label size
labels_cex(sf5A_dend) <- 0.4
labels_cex(sf5B_dend) <- 0.4
labels_cex(sf5C_dend) <- 0.4
labels_cex(sf5D_dend) <- 0.4

# define branch line width
sf5A_dend <- assign_values_to_branches_edgePar(dend=sf5A_dend, value=0.75, edgePar="lwd")
sf5B_dend <- assign_values_to_branches_edgePar(dend=sf5B_dend, value=0.75, edgePar="lwd")
sf5C_dend <- assign_values_to_branches_edgePar(dend=sf5C_dend, value=0.75, edgePar="lwd")
sf5D_dend <- assign_values_to_branches_edgePar(dend=sf5D_dend, value=0.75, edgePar="lwd")

# ggplot
sf5A_plot <- dend.plot(data=sf5A_dend, ylim.min=-0.25, offst.lbl=-0.025,
                       title="A", subtitle="Unweighted UniFrac\nHSCR-Laramie P24 Colon")
sf5B_plot <- dend.plot(data=sf5B_dend, ylim.min=-0.31, offst.lbl=-0.031,
                       title="B", subtitle="Weighted UniFrac\nHSCR-Laramie P24 Colon")
sf5C_plot <- dend.plot(data=sf5C_dend, ylim.min=-0.25, offst.lbl=-0.025,
                       title="C", subtitle="Unweighted UniFrac\nHSCR-Laramie P24 Fecal")
sf5D_plot <- dend.plot(data=sf5D_dend, ylim.min=-0.36, offst.lbl=-0.072,
                       title="D", subtitle="Weighted UniFrac\nHSCR-Laramie P24 Fecal")

# add theme
sf5A_plot <- dend.theme(ggplot=sf5A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf5B_plot <- dend.theme(ggplot=sf5B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf5C_plot <- dend.theme(ggplot=sf5C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
sf5D_plot <- dend.theme(ggplot=sf5D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(sf5D_pvc) # edges 6 - 5 - 1

# Step 2:
# create a data.frame of all the AU/BP values
sf5D_pvals_all <- extrct.pvals.do.math(sf5D_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
sf5D_pvals_flt <- sf5D_pvals_all[c(6,5,1),]
sf5D_pvals_flt[] <- lapply(sf5D_pvals_flt, as.character)
row.names(sf5D_pvals_flt) <- 1:nrow(sf5D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
sf5D_nodes_all <- intrnl.node.coords(sf5D_dend)

# Step 5:
# re-plot the dendrogram plots from above of, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
sf5D_plot.x <- sf5D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,8), breaks=c(1:8))
print(sf5D_plot.x) # ~4.25 ~4.5 ~5.5

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
sf5D_nodes_flt <- sf5D_nodes_all[c(3,4,5),]
row.names(sf5D_nodes_flt) <- 1:nrow(sf5D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
sf5D_labs <- cbind(sf5D_pvals_flt, sf5D_nodes_flt)
sf5D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
sf5D_vecx <- sf5D_nodes_all[1,1]
sf5D_vecy <- sf5D_nodes_all[1,2]
sf5D_veclab <- as.character("AU value (%)")
sf5D_root_lab <- data.frame("x"=sf5D_vecx,"y"=sf5D_vecy,"lab"=sf5D_veclab)
sf5D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
sf5D_root_y <- sf5D_root_lab[1,2] - 0.1

# ggplot with AU % labels
sf5A_plot.frmt <- sf5A_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf5B_plot.frmt <- sf5B_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf5C_plot.frmt <- sf5C_plot +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

sf5D_plot.frmt <- sf5D_plot +
  # add cluster shading line for mice from the same cage
  annotate("rect", xmin=2.7, xmax=5.3, ymin=-0.0576, ymax=-0.036, alpha=0.55, fill="#636363") +
  # AU % labels for branch nodes of interest
  geom_label(data=sf5D_labs, label=sf5D_labs$au, x=sf5D_labs$x, y=sf5D_labs$y,
             color=sf5D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=sf5D_root_lab, label=sf5D_root_lab$lab, x=sf5D_root_lab$x, y=sf5D_root_y,
  #          color=sf5D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
  #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
require(grid)
require(gridExtra)
s5_fig <- grid.arrange(sf5A_plot.frmt, sf5B_plot.frmt, sf5C_plot.frmt, sf5D_plot.frmt,
                       ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/s5_fig")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s5.tiff", plot=s5_fig, dpi=600, width=85, height=119, units="mm", 
       device="tiff", type="cairo", compression="lzw")

##########################################
################ FIGURE 2 ################
##########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_2/")

# read in the distance matrices
f2A_dm <- read.dm(file="w_cBL_P20WTcore.txt")
f2B_dm <- read.dm(file="w_fBL_P20WTcore.txt")
f2C_dm <- read.dm(file="w_cBL_P20KOcore.txt")
f2D_dm <- read.dm(file="w_fBL_P20KOcore.txt")

require(ape)
# using package ape, perform principal coordinates analysis
f2A_pcoa <- pcoa(f2A_dm)
f2B_pcoa <- pcoa(f2B_dm)
f2C_pcoa <- pcoa(f2C_dm)
f2D_pcoa <- pcoa(f2D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
f2A_eigs <- iso.PC(f2A_pcoa)
f2B_eigs <- iso.PC(f2B_pcoa)
f2C_eigs <- iso.PC(f2C_pcoa)
f2D_eigs <- iso.PC(f2D_pcoa)

# create the axis labels
f2A_PC1 <- paste("PC 1 (", round(f2A_eigs[1]*100,0), "%)", sep ="")
f2A_PC2 <- paste("\nPC 2 (", round(f2A_eigs[2]*100,0), "%)", sep ="")
f2B_PC1 <- paste("PC 1 (", round(f2B_eigs[1]*100,0), "%)", sep ="")
f2B_PC2 <- paste("\nPC 2 (", round(f2B_eigs[2]*100,0), "%)", sep ="")
f2C_PC1 <- paste("PC 1 (", round(f2C_eigs[1]*100,0), "%)", sep ="")
f2C_PC2 <- paste("\nPC 2 (", round(f2C_eigs[2]*100,0), "%)", sep ="")
f2D_PC1 <- paste("PC 1 (", round(f2D_eigs[1]*100,0), "%)", sep ="")
f2D_PC2 <- paste("\nPC 2 (", round(f2D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
f2A_coords <- iso.coords(f2A_pcoa)
f2B_coords <- iso.coords(f2B_pcoa)
f2C_coords <- iso.coords(f2C_pcoa)
f2D_coords <- iso.coords(f2D_pcoa)

# merge in metadata from map
f2A_df <- merge(x=map_file, y=f2A_coords, by="SampleID", sort=FALSE, all=FALSE)
f2B_df <- merge(x=map_file, y=f2B_coords, by="SampleID", sort=FALSE, all=FALSE)
f2C_df <- merge(x=map_file, y=f2C_coords, by="SampleID", sort=FALSE, all=FALSE)
f2D_df <- merge(x=map_file, y=f2D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
f2A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")

# add shapes
f2A_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2B_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2C_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2D_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)

require(rKIN)
# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
f2A_ell <- estEllipse(f2A_df, x="X.Coord", y="Y.Coord", group="Facility",
                      levels=c(95), smallSamp=TRUE)
f2B_ell <- estEllipse(f2B_df, x="X.Coord", y="Y.Coord", group="Facility",
                      levels=c(95), smallSamp=TRUE)
f2C_ell <- estEllipse(f2C_df, x="X.Coord", y="Y.Coord", group="Facility",
                      levels=c(95), smallSamp=TRUE)
f2D_ell <- estEllipse(f2D_df, x="X.Coord", y="Y.Coord", group="Facility",
                      levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
f2A_olap <- calcOverlap(f2A_ell)
f2B_olap <- calcOverlap(f2B_ell)
f2C_olap <- calcOverlap(f2C_ell)
f2D_olap <- calcOverlap(f2D_ell)

# plot with defaults
f2A_plot <- pcoa.plot(data=f2A_ell, xlab=f2A_PC1, ylab=f2A_PC2, scaler=0.05, 
                      title="A", subtitle="Weighted UniFrac\nHSCR P20-WT Colon", alpha=0.16) 
f2B_plot <- pcoa.plot(data=f2B_ell, xlab=f2B_PC1, ylab=f2B_PC2, scaler=0.05, 
                      title="B", subtitle="Weighted UniFrac\nHSCR P20-WT Fecal", alpha=0.16)
f2C_plot <- pcoa.plot(data=f2C_ell, xlab=f2C_PC1, ylab=f2C_PC2, scaler=0.05, 
                      title="C", subtitle="Weighted UniFrac\nHSCR P20-KO Colon", alpha=0.16)
f2D_plot <- pcoa.plot(data=f2D_ell, xlab=f2D_PC1, ylab=f2D_PC2, scaler=0.05, 
                      title="D", subtitle="Weighted UniFrac\nHSCR P20-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
f2A_plot <- pcoa.theme(ggplot=f2A_plot, ttl.size=11, sub.ttl.size=7,
                       axs.txt.size=8, font.fam="Helvetica")+
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(f2A_plot)

f2B_plot <- pcoa.theme(ggplot=f2B_plot, ttl.size=11, sub.ttl.size=7,
                       axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(f2B_plot)

f2C_plot <- pcoa.theme(ggplot=f2C_plot, ttl.size=11, sub.ttl.size=7,
                       axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=4) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(f2C_plot)

f2D_plot <- pcoa.theme(ggplot=f2D_plot, ttl.size=11, sub.ttl.size=7,
                       axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=5) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(f2D_plot)

# customize points
f2A_plot.frmt <- f2A_plot +
  geom_point(inherit.aes=FALSE, data=f2A_df, x=f2A_df$X.Coord, y=f2A_df$Y.Coord,
             shape=f2A_df$fac.shp, color=f2A_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2B_plot.frmt <- f2B_plot +
  geom_point(inherit.aes=FALSE, data=f2B_df, x=f2B_df$X.Coord, y=f2B_df$Y.Coord,
             shape=f2B_df$fac.shp, color=f2B_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2C_plot.frmt <- f2C_plot +
  geom_point(inherit.aes=FALSE, data=f2C_df, x=f2C_df$X.Coord, y=f2C_df$Y.Coord,
             shape=f2C_df$fac.shp, color=f2C_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2D_plot.frmt <- f2D_plot +
  geom_point(inherit.aes=FALSE, data=f2D_df, x=f2D_df$X.Coord, y=f2D_df$Y.Coord,
             shape=f2D_df$fac.shp, color=f2D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# create custom legend using shapes to represent the proper groups
# create vector in order to create data.frame
vec.lgnd.x <- c(1,2)
vec.lgnd.y <- 1
vec.lgnd <- c("Boston","Laramie")
df_lgnd <- data.frame("x"=vec.lgnd.x, "y"=vec.lgnd.y, "fax"=vec.lgnd)

# define the legend labels
lbls <- c("Boston","Laramie")

# define shapes and colors for each facility
# contrast color scheme
vals.shp <- c(16,17)
vals.fll <- c("#1b7837","#762a83")

# ggplot
lgnd <- lgnd.plot(data=df_lgnd, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                  alpha=1, lbls=lbls, vals.fll=vals.fll, 
                  vals.clr=vals.fll, vals.shp=vals.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd <- lgnd.theme(ggplot=lgnd, txt.size=9, lgnd.shp.size=2, font.fam="Helvetica")

# arrange plots into panels
require(grid)
require(gridExtra)
fig_2 <- grid.arrange(f2A_plot.frmt, f2B_plot.frmt, f2C_plot.frmt, f2D_plot.frmt, lgnd,
                      ncol=3, nrow=2, layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_2/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_2.tiff", plot=fig_2, dpi=600, width=110, height=110, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S6 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s6_fig/")

# read in the distance matrices
sf6A_dm <- read.dm(file="w_cBL_P07WTcore.txt")
sf6B_dm <- read.dm(file="w_fBL_P07WTcore.txt")
sf6C_dm <- read.dm(file="w_cBL_P07KOcore.txt")
sf6D_dm <- read.dm(file="w_fBL_P07KOcore.txt")

require(ape)
# using package ape, perform principal coordinates analysis
sf6A_pcoa <- pcoa(sf6A_dm)
sf6B_pcoa <- pcoa(sf6B_dm)
sf6C_pcoa <- pcoa(sf6C_dm)
sf6D_pcoa <- pcoa(sf6D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
sf6A_eigs <- iso.PC(sf6A_pcoa)
sf6B_eigs <- iso.PC(sf6B_pcoa)
sf6C_eigs <- iso.PC(sf6C_pcoa)
sf6D_eigs <- iso.PC(sf6D_pcoa)

# create the axis labels
sf6A_PC1 <- paste("PC 1 (", round(sf6A_eigs[1]*100,0), "%)", sep ="")
sf6A_PC2 <- paste("\nPC 2 (", round(sf6A_eigs[2]*100,0), "%)", sep ="")
sf6B_PC1 <- paste("PC 1 (", round(sf6B_eigs[1]*100,0), "%)", sep ="")
sf6B_PC2 <- paste("\nPC 2 (", round(sf6B_eigs[2]*100,0), "%)", sep ="")
sf6C_PC1 <- paste("PC 1 (", round(sf6C_eigs[1]*100,0), "%)", sep ="")
sf6C_PC2 <- paste("\nPC 2 (", round(sf6C_eigs[2]*100,0), "%)", sep ="")
sf6D_PC1 <- paste("PC 1 (", round(sf6D_eigs[1]*100,0), "%)", sep ="")
sf6D_PC2 <- paste("\nPC 2 (", round(sf6D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
sf6A_coords <- iso.coords(sf6A_pcoa)
sf6B_coords <- iso.coords(sf6B_pcoa)
sf6C_coords <- iso.coords(sf6C_pcoa)
sf6D_coords <- iso.coords(sf6D_pcoa)

# merge in metadata from map
sf6A_df <- merge(x=map_file, y=sf6A_coords, by="SampleID", sort=FALSE, all=FALSE)
sf6B_df <- merge(x=map_file, y=sf6B_coords, by="SampleID", sort=FALSE, all=FALSE)
sf6C_df <- merge(x=map_file, y=sf6C_coords, by="SampleID", sort=FALSE, all=FALSE)
sf6D_df <- merge(x=map_file, y=sf6D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
sf6A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")
sf6B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")
sf6C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
sf6D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")

# add shapes
sf6A_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)
sf6B_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)
sf6C_df$fac.shp <- c(16,16,16,16,16,17,17,17,17)
sf6D_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)

require(rKIN)
# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
sf6A_ell <- estEllipse(sf6A_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf6B_ell <- estEllipse(sf6B_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf6C_ell <- estEllipse(sf6C_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf6D_ell <- estEllipse(sf6D_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
sf6A_olap <- calcOverlap(sf6A_ell)
sf6B_olap <- calcOverlap(sf6B_ell)
sf6C_olap <- calcOverlap(sf6C_ell)
sf6D_olap <- calcOverlap(sf6D_ell)

# plot with defaults
sf6A_plot <- pcoa.plot(data=sf6A_ell, xlab=sf6A_PC1, ylab=sf6A_PC2, scaler=0.05, 
                       title="A", subtitle="Weighted UniFrac\nHSCR P07-WT Colon", alpha=0.16) 
sf6B_plot <- pcoa.plot(data=sf6B_ell, xlab=sf6B_PC1, ylab=sf6B_PC2, scaler=0.05, 
                       title="B", subtitle="Weighted UniFrac\nHSCR P07-WT Fecal", alpha=0.16)
sf6C_plot <- pcoa.plot(data=sf6C_ell, xlab=sf6C_PC1, ylab=sf6C_PC2, scaler=0.05, 
                       title="C", subtitle="Weighted UniFrac\nHSCR P07-KO Colon", alpha=0.16)
sf6D_plot <- pcoa.plot(data=sf6D_ell, xlab=sf6D_PC1, ylab=sf6D_PC2, scaler=0.05, 
                       title="D", subtitle="Weighted UniFrac\nHSCR P07-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
sf6A_plot <- pcoa.theme(ggplot=sf6A_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica")+
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf6A_plot)

sf6B_plot <- pcoa.theme(ggplot=sf6B_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf6B_plot)

sf6C_plot <- pcoa.theme(ggplot=sf6C_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=4) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf6C_plot)

sf6D_plot <- pcoa.theme(ggplot=sf6D_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=5) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf6D_plot)

# customize points
sf6A_plot.frmt <- sf6A_plot +
  geom_point(inherit.aes=FALSE, data=sf6A_df, x=sf6A_df$X.Coord, y=sf6A_df$Y.Coord,
             shape=sf6A_df$fac.shp, color=sf6A_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf6B_plot.frmt <- sf6B_plot +
  geom_point(inherit.aes=FALSE, data=sf6B_df, x=sf6B_df$X.Coord, y=sf6B_df$Y.Coord,
             shape=sf6B_df$fac.shp, color=sf6B_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf6C_plot.frmt <- sf6C_plot +
  geom_point(inherit.aes=FALSE, data=sf6C_df, x=sf6C_df$X.Coord, y=sf6C_df$Y.Coord,
             shape=sf6C_df$fac.shp, color=sf6C_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf6D_plot.frmt <- sf6D_plot +
  geom_point(inherit.aes=FALSE, data=sf6D_df, x=sf6D_df$X.Coord, y=sf6D_df$Y.Coord,
             shape=sf6D_df$fac.shp, color=sf6D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# arrange plots into panels
require(grid)
require(gridExtra)
s6_fig <- grid.arrange(sf6A_plot.frmt, sf6B_plot.frmt, sf6C_plot.frmt, sf6D_plot.frmt, lgnd,
                       ncol=3, nrow=2, layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/s6_fig/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s6.tiff", plot=s6_fig, dpi=600, width=110, height=110, units="mm", 
       device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S7 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/s7_fig/")

# read in the distance matrices
sf7A_dm <- read.dm(file="w_cBL_P24WTcore.txt")
sf7B_dm <- read.dm(file="w_fBL_P24WTcore.txt")
sf7C_dm <- read.dm(file="w_cBL_P24KOcore.txt")
sf7D_dm <- read.dm(file="w_fBL_P24KOcore.txt")

require(ape)
# using package ape, perform principal coordinates analysis
sf7A_pcoa <- pcoa(sf7A_dm)
sf7B_pcoa <- pcoa(sf7B_dm)
sf7C_pcoa <- pcoa(sf7C_dm)
sf7D_pcoa <- pcoa(sf7D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
sf7A_eigs <- iso.PC(sf7A_pcoa)
sf7B_eigs <- iso.PC(sf7B_pcoa)
sf7C_eigs <- iso.PC(sf7C_pcoa)
sf7D_eigs <- iso.PC(sf7D_pcoa)

# create the axis labels
sf7A_PC1 <- paste("PC 1 (", round(sf7A_eigs[1]*100,0), "%)", sep ="")
sf7A_PC2 <- paste("\nPC 2 (", round(sf7A_eigs[2]*100,0), "%)", sep ="")
sf7B_PC1 <- paste("PC 1 (", round(sf7B_eigs[1]*100,0), "%)", sep ="")
sf7B_PC2 <- paste("\nPC 2 (", round(sf7B_eigs[2]*100,0), "%)", sep ="")
sf7C_PC1 <- paste("PC 1 (", round(sf7C_eigs[1]*100,0), "%)", sep ="")
sf7C_PC2 <- paste("\nPC 2 (", round(sf7C_eigs[2]*100,0), "%)", sep ="")
sf7D_PC1 <- paste("PC 1 (", round(sf7D_eigs[1]*100,0), "%)", sep ="")
sf7D_PC2 <- paste("\nPC 2 (", round(sf7D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
sf7A_coords <- iso.coords(sf7A_pcoa)
sf7B_coords <- iso.coords(sf7B_pcoa)
sf7C_coords <- iso.coords(sf7C_pcoa)
sf7D_coords <- iso.coords(sf7D_pcoa)

# merge in metadata from map
sf7A_df <- merge(x=map_file, y=sf7A_coords, by="SampleID", sort=FALSE, all=FALSE)
sf7B_df <- merge(x=map_file, y=sf7B_coords, by="SampleID", sort=FALSE, all=FALSE)
sf7C_df <- merge(x=map_file, y=sf7C_coords, by="SampleID", sort=FALSE, all=FALSE)
sf7D_df <- merge(x=map_file, y=sf7D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
sf7A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
sf7B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
sf7C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
sf7D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")

# add shapes
sf7A_df$fac.shp <- c(16,16,16,17,17,17,17,17,17,17)
sf7B_df$fac.shp <- c(16,16,16,17,17,17,17)
sf7C_df$fac.shp <- c(16,16,16,17,17,17,17)
sf7D_df$fac.shp <- c(16,16,16,17,17,17,17)

require(rKIN)
# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
sf7A_ell <- estEllipse(sf7A_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf7B_ell <- estEllipse(sf7B_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf7C_ell <- estEllipse(sf7C_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)
sf7D_ell <- estEllipse(sf7D_df, x="X.Coord", y="Y.Coord", group="Facility",
                       levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
sf7A_olap <- calcOverlap(sf7A_ell)
sf7B_olap <- calcOverlap(sf7B_ell)
sf7C_olap <- calcOverlap(sf7C_ell)
sf7D_olap <- calcOverlap(sf7D_ell)

# plot with defaults
sf7A_plot <- pcoa.plot(data=sf7A_ell, xlab=sf7A_PC1, ylab=sf7A_PC2, scaler=0.05, 
                       title="A", subtitle="Weighted UniFrac\nHSCR P24-WT Colon", alpha=0.16) 
sf7B_plot <- pcoa.plot(data=sf7B_ell, xlab=sf7B_PC1, ylab=sf7B_PC2, scaler=0.05, 
                       title="B", subtitle="Weighted UniFrac\nHSCR P24-WT Fecal", alpha=0.16)
sf7C_plot <- pcoa.plot(data=sf7C_ell, xlab=sf7C_PC1, ylab=sf7C_PC2, scaler=0.05, 
                       title="C", subtitle="Weighted UniFrac\nHSCR P24-KO Colon", alpha=0.16)
sf7D_plot <- pcoa.plot(data=sf7D_ell, xlab=sf7D_PC1, ylab=sf7D_PC2, scaler=0.05, 
                       title="D", subtitle="Weighted UniFrac\nHSCR P24-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
sf7A_plot <- pcoa.theme(ggplot=sf7A_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica")+
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf7A_plot)

sf7B_plot <- pcoa.theme(ggplot=sf7B_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf7B_plot)

sf7C_plot <- pcoa.theme(ggplot=sf7C_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=4) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf7C_plot)

sf7D_plot <- pcoa.theme(ggplot=sf7D_plot, ttl.size=11, sub.ttl.size=7,
                        axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=5) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))
print(sf7D_plot)

# customize points
sf7A_plot.frmt <- sf7A_plot +
  geom_point(inherit.aes=FALSE, data=sf7A_df, x=sf7A_df$X.Coord, y=sf7A_df$Y.Coord,
             shape=sf7A_df$fac.shp, color=sf7A_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf7B_plot.frmt <- sf7B_plot +
  geom_point(inherit.aes=FALSE, data=sf7B_df, x=sf7B_df$X.Coord, y=sf7B_df$Y.Coord,
             shape=sf7B_df$fac.shp, color=sf7B_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf7C_plot.frmt <- sf7C_plot +
  geom_point(inherit.aes=FALSE, data=sf7C_df, x=sf7C_df$X.Coord, y=sf7C_df$Y.Coord,
             shape=sf7C_df$fac.shp, color=sf7C_df$fac.clr, alpha=1, size=1.5, stroke=0)

sf7D_plot.frmt <- sf7D_plot +
  geom_point(inherit.aes=FALSE, data=sf7D_df, x=sf7D_df$X.Coord, y=sf7D_df$Y.Coord,
             shape=sf7D_df$fac.shp, color=sf7D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# add in overlap percentage labels for sf7A
# create vectors with percentage values, round them, multiply them
vec1.olap <- round(sf7A_olap[1,3], digits=2)*100
vec2.olap <- round(sf7A_olap[2,2], digits=2)*100

# create the labels
lab1.olap <- paste("Bos/Lar overlap = ", vec1.olap, "%", sep ="")
lab2.olap <- paste("Lar/Bos overlap =   ", vec2.olap, "%", sep ="")

# create vectors with x and y coordinates for labels and shading
x.lab.olap <- 0.445
y.lab.olap <- c(-0.415, -0.455)

# create a data.frame using the vectors above
olap.labs <- data.frame("label"=c(lab1.olap, lab2.olap), "x.lab"=x.lab.olap, 
                        "y.lab"=y.lab.olap, "clr"=c("#252525","#252525"))

# plot sf7A_plot.frmt with overlap percentage labels
sf7A_plot.frmt.olap <- sf7A_plot.frmt +
  geom_text(data=olap.labs, label=olap.labs$label, x=olap.labs$x.lab, y=olap.labs$y.lab, 
            color=olap.labs$clr, size=1.25, family="Helvetica")
print(sf7A_plot.frmt.olap)

# arrange plots into panels
require(grid)
require(gridExtra)
s7_fig <- grid.arrange(sf7A_plot.frmt.olap, sf7B_plot.frmt, sf7C_plot.frmt, sf7D_plot.frmt, lgnd,
                       ncol=3, nrow=2, layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/s7_fig/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
ggsave("fig_s7.tiff", plot=s7_fig, dpi=600, width=110, height=110, units="mm", 
       device="tiff", type="cairo", compression="lzw")

# save workspace
setwd("~/Desktop/r_analysis/")
save.image(file="R_Code_1_WS.Rdata")
