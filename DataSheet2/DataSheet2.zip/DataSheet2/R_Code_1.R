# NOTE: A lot happens in this file. I would recommend not hitting the 'Source' button
# rather, it will be computationally best to run each figure separately.

# packages required for this file
# "ape"
# "dendextend"
# "dplyr"
# "ggplot2"
# "gridExtra"
# "pvclust"
# "rKIN"
# NOTE: most package functions are called using the :: syntax (i.e. dplyr::filter())

# load packages
require(dendextend)
require(ggplot2)
require(pvclust)

########################################################
################ INTERNAL FUNCTIONS ####################
########################################################

# define several functions to make figure construction "smoother"

# read in a metadata mapping file
read.map <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# read in a distance matrix output from QIIME1: beta_diversity.py
read.dm <- function(file=""){
  file <- as.dist(read.table(file, header=TRUE, sep="\t", as.is=TRUE, row.name=1))
  return(file)
}

# # for Figures 1, S1, S2, S3, S4, S5
# read in a format file
read.ffile <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# define a function to return a filtered distance matrix and a filtered metadata mapping file in list form
flt.dm.and.meta <- function(meta, dist.obj, flt.col.intrst, flt.row.val, match.col){
  # create a vector of row.numbers in the metadata column of interest that match the row value of interest
  vec.row.nums <- which(meta[,flt.col.intrst] %in% flt.row.val)
  # create a new metadata data.frame with only the rows of interest
  new.meta <- meta[vec.row.nums,]
  # coerce distance matrix from class: 'dist' to class: 'matrix'
  dm <- as.matrix(dist.obj)
  # create a vector of row numbers in the distance matrix that match the specified column in the metadata.file
  dm.vec.nums <- which(row.names(dm) %in% new.meta[,match.col])
  # filter the distance matrix to retain only those numbers
  # NOTE: since we are in matrix land, the row numbers and column numbers will be identical, and we can take advantage of that
  new.dm <- dm[dm.vec.nums,dm.vec.nums]
  # match the order of the rows in new.meta with new.dm
  new.meta <- new.meta[match(x=row.names(new.dm), table=new.meta[,match.col]),]
  # convert new.dm back into class 'dist'
  new.dist <- as.dist(new.dm)
  # create a list containing new.meta and new.dist
  flt.list <- list(df=new.meta, dm=new.dist)
  return(flt.list)
}

# for Figures 1, S1, S2, S3, S4, S5
# perform hierarchical clustering using the UGPMA method
clust.upgma <- function(data, nboot){
  pv.clust <- pvclust::pvclust(as.matrix(data), method.hclust="average", nboot=nboot)
  return(pv.clust)
}

# for Figures 1, S1, S2, S3, S4, S5
# format the format file
format.ffile <- function(data,format.file=data.frame){
  # convert class pvclust to class hclust
  h.clust <- as.hclust(data)
  # create a data frame of existing tip labels
  df.tiplabs <- data.frame(h.clust$labels)
  # change column 1 to "HC.labels"
  names(df.tiplabs)[1] <- "HC.labels"
  # merge df.tiplabs with the format file
  df.merge <- merge(df.tiplabs, format.file, by="HC.labels", sort=FALSE, all=FALSE)
  return(df.merge)
}

# for Figures 1, S1, S2, S3, S4, S5
# format user-defined tip labels
tip.labs <- function(data,format.file=data.frame,whichcol){
  # define new tip labels
  h.clust.newlabs <- as.hclust(data)
  h.clust.newlabs$labels <- c(paste(whichcol))
  return(h.clust.newlabs)
}

# for Figures 1, S1, S2, S3, S4, S5
# format user-defined colors for the tip labels
tip.cols <- function(data,format.file=data.frame,whichcol){
  # convert class hclust to class dendrogram
  dend <- as.dendrogram(data)
  # paste hex color codes from the format file into a vector
  hex.cols <- paste(whichcol)
  # paste in '#' before each hex code (for proper formating)
  hex.cols.form <- paste("#", sep="", hex.cols)
  # define the tip label colors
  dend.cols <- dend
  dendextend::labels_colors(dend.cols) <- hex.cols.form[order.dendrogram(dend.cols)]
  return(dend.cols)
}

# for Figures 1, S1, S2, S3, S4, S5
# ggplot for UPGMA dendrograms
dend.plot <- function(data, ylim.min, offst.lbl, title="", subtitle=""){
  dendplot <- ggplot(dendextend::as.ggdend(data), offset_labels=offst.lbl) +
    ylim(min(ylim.min), max(dendextend::get_branches_heights(data))) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(dendplot)
}

# for Figures 1, S1, S2, S3, S4, S5
# add custom UPGMA dendrogram plot theme
# NOTE: this function is slightly different than the dend.theme function used in Figure 4A and 4B,
# specifically it has different title and subtitle formatting
dend.theme <- function(ggplot, ttl.size, sub.ttl.size, font.fam){
  dendtheme <- ggplot +
    # global theme
    dendextend::theme_dendro() +
    # title and subtitle parameters
    theme(plot.title=element_text(size=ttl.size, margin=margin(t=0, b=-7)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=-2))) +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(dendtheme)
}

# for Figures 1, S1, S2, S3, S4, S5
# define a function which extracts the au and bp values from a pvclust object
# and rounds all numeric values to specified number of digits
# and converts all numeric values into a percentage
extrct.pvals.do.math <- function(data, digits){
  # create a data.frame of pvclust edges
  df1 <- data$edges
  # retain the au and bp column
  df2 <- df1[,1:2]
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df2, mode) =='numeric'
  # round all numeric values to specified digits
  df2[num.cols] <- round(df2[num.cols], digits=digits)
  # convert all numeric values to a percentage
  df2[num.cols] <- df2[num.cols]*100
  return(df2)
}

# for Figures 1, S1, S2, S3, S4, S5
# define a function to extract x and y coordinates of internal nodes from a dendrogram object
intrnl.node.coords <- function(data){
  # create data frame of xy coords
  df1 <- as.data.frame(dendextend::get_nodes_xy(data))
  # change columns names to x and y
  df2 <- df1
  names(df2)[1] <- "x"
  names(df2)[2] <- "y"
  # create a vector of row #'s, based upon which rows of in column y are equal to 0
  zero.row <- which(df2$y == 0)
  # remove those rows from the data.frame
  df3 <- df2[-zero.row,]
  # renumber the rows
  row.names(df3) <- 1:nrow(df3)
  return(df3)
}

# for Figures 2, S6, S7
# isolate PC1 and PC2 axis percentages (aka the relative_eig values)
# these will become our X and Y axis labels
iso.PC <- function(data){
  # convert pcoa$values into a data frame
  df.vals <- data.frame(data$values)
  # create a vector of the first two relative_eig values
  vec.rel.eigs <- df.vals$Relative_eig[1:2]
  return(vec.rel.eigs)
}

# for Figures 2, S6, S7
# isolate dot/point (aka sample) coordinates
iso.coords <- function(data){
  # convert pcoa$vectors into a data frame
  df.vec <- data.frame(data$vec)
  # isolate column 1 and 2 (x and y)
  xy.coords <- df.vec[, 1:2]
  # rename the columns 1 and 2
  names(xy.coords)[1] <- "X.Coord"
  names(xy.coords)[2] <- "Y.Coord"
  # convert column 0 into a column title SampleID
  xy.coords <- data.frame(SampleID=row.names(xy.coords), xy.coords)
  # convert SampleID to a character
  xy.coords$SampleID <- as.character(xy.coords$SampleID)
  return(xy.coords)
}

# for Figures 2, S6, S7
# plotKIN and ggplot2 PCoA plot
pcoa.plot <- function(data, scaler, xlab, ylab, title="", subtitle="", alpha){
  pcoaplot <- rKIN::plotKIN(data, scaler=scaler, xlab=xlab, ylab=ylab, alpha=alpha) +
    ggplot2::labs(title=title, subtitle=subtitle)
  return(pcoaplot)
}

# for Figures 2, S6, S7
# add custom PCoA plot theme
# NOTE: this function is slightly different than the pcoa.theme function used in Figure 4C
# specifically it has different title and subtitle formatting
pcoa.theme <- function(ggplot, ttl.size, sub.ttl.size, 
                       axs.txt.size, font.fam){
  pcoatheme <- ggplot +
    # global theme
    theme_bw() +
    # blank the plot background/grids, bold the border
    theme(panel.background=element_blank(),
          panel.grid=element_blank(),
          panel.border=element_rect(fill=NA, color="black", size=1.1)) +
    # title and subtitle parameters
    theme(plot.title=element_text(hjust=-0.19, size=ttl.size, margin=margin(t=0,b=-8)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=4))) +
    # axis parameters
    theme(axis.text=element_blank(),
          axis.ticks=element_blank(),
          axis.title=element_text(size=axs.txt.size)) +
    # remove the legend
    theme(legend.position="none") +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(pcoatheme)
}

# for Figures 2, S6, S7
# ggplot for custom legend using shapes
lgnd.plot <- function(data, col.x, col.y, col.clr, col.shp, col.fll, alpha, labs.ttl, lbls, vals.fll, vals.clr, vals.shp){
  lgnd.plot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], color=names(data)[col.clr],
                        shape=names(data)[col.shp], fill=names(data)[col.fll]) +
    geom_point(stroke=0, size=4, alpha=alpha) +
    scale_fill_manual(values=vals.fll, labels=lbls) +
    scale_color_manual(values=vals.clr, labels=lbls) +
    scale_shape_manual(values=vals.shp, labels=lbls)
  return(lgnd.plot)
}

# for Figures 2, S6, S7
# ggplot theme for custom vertical legend using shapes
lgnd.theme <- function(ggplot, txt.size, lgnd.shp.size, font.fam){
  cstm.lgnd.theme <- ggplot +
    # global theme
    theme_bw() +
    # fill the plot with a white rectangle, blank the grid and the border
    theme(plot.background=element_rect(fill="white"),
          panel.ontop=TRUE,
          panel.border=element_blank(),
          panel.grid=element_blank()) +
    # axis parameters - blank all
    theme(axis.ticks=element_blank(),
          axis.title=element_blank(),
          axis.text=element_blank()) +
    # vertical legend parameters
    theme(legend.position=c(0.5,0.5),
          legend.direction="vertical",
          legend.title=element_blank(),
          legend.text=element_text(size=txt.size, lineheight=0.001)) +
    guides(color=guide_legend(label=TRUE, override.aes=list(size=lgnd.shp.size))) +
    theme(text=element_text(family=font.fam))
  return(cstm.lgnd.theme) 
}  

########################################################
################ Read in "global" files ################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/")

# format file (needed for dendograms)
df.frmt.hscr <- read.ffile(file="hscr_R_format_file.txt")

# metadata mapping file (needed for distance matrix filtering and for PCoA)
df.meta.hscr <- read.map(file="hscr_R_meta.txt")

# distance matrices (to be filtered)
uw_cBL_dm <- read.dm(file="bdiv/uw_cBL.txt")
w_cBL_dm <- read.dm(file="bdiv/w_cBL.txt")
uw_cLar_dm <- read.dm(file="bdiv/uw_cLar.txt")
w_cLar_dm <- read.dm(file="bdiv/w_cLar.txt")
uw_fLar_dm <- read.dm(file="bdiv/uw_fLar.txt")
w_fLar_dm <- read.dm(file="bdiv/w_fLar.txt")

##########################################
################ FIGURE 1 ################
##########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_1/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
f1A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P20-WT", match.col="SampleID")
f1A_dm <- f1A.list$dm
f1B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P20-WT", match.col="SampleID")
f1B_dm <- f1B.list$dm
f1C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P20-KO", match.col="SampleID")
f1C_dm <- f1C.list$dm
f1D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P20-KO", match.col="SampleID")
f1D_dm <- f1D.list$dm

# perform UPGMA clustering on the dm
f1A_pvc <- clust.upgma(data=f1A_dm, nboot=10000)
f1B_pvc <- clust.upgma(data=f1B_dm, nboot=10000)
f1C_pvc <- clust.upgma(data=f1C_dm, nboot=10000)
f1D_pvc <- clust.upgma(data=f1D_dm, nboot=10000)

# format the pvc data with the format file
f1A_form <- format.ffile(data=f1A_pvc, format.file=df.frmt.hscr)
f1B_form <- format.ffile(data=f1B_pvc, format.file=df.frmt.hscr)
f1C_form <- format.ffile(data=f1C_pvc, format.file=df.frmt.hscr)
f1D_form <- format.ffile(data=f1D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
f1A_hc <- tip.labs(data=f1A_pvc, format.file=f1A_form, whichcol=f1A_form$HC.facility)
f1B_hc <- tip.labs(data=f1B_pvc, format.file=f1B_form, whichcol=f1B_form$HC.facility)
f1C_hc <- tip.labs(data=f1C_pvc, format.file=f1C_form, whichcol=f1C_form$HC.facility)
f1D_hc <- tip.labs(data=f1D_pvc, format.file=f1D_form, whichcol=f1D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
f1A_dend <- tip.cols(data=f1A_hc, format.file=f1A_form, whichcol=f1A_form$HC.colorfacility)
f1B_dend <- tip.cols(data=f1B_hc, format.file=f1B_form, whichcol=f1B_form$HC.colorfacility)
f1C_dend <- tip.cols(data=f1C_hc, format.file=f1C_form, whichcol=f1C_form$HC.colorfacility)
f1D_dend <- tip.cols(data=f1D_hc, format.file=f1D_form, whichcol=f1D_form$HC.colorfacility)

# define tip label size
dendextend::labels_cex(f1A_dend) <- 0.4
dendextend::labels_cex(f1B_dend) <- 0.4
dendextend::labels_cex(f1C_dend) <- 0.4
dendextend::labels_cex(f1D_dend) <- 0.4

# define branch line width
f1A_dend <- dendextend::assign_values_to_branches_edgePar(dend=f1A_dend, value=0.75, edgePar="lwd")
f1B_dend <- dendextend::assign_values_to_branches_edgePar(dend=f1B_dend, value=0.75, edgePar="lwd")
f1C_dend <- dendextend::assign_values_to_branches_edgePar(dend=f1C_dend, value=0.75, edgePar="lwd")
f1D_dend <- dendextend::assign_values_to_branches_edgePar(dend=f1D_dend, value=0.75, edgePar="lwd")

# ggplot
f1A_plot <- dend.plot(data=f1A_dend, ylim.min=-0.25, offst.lbl=-0.05, title="A", subtitle="Unweighted UniFrac\nEdnrb P20-WT Colon")
f1B_plot <- dend.plot(data=f1B_dend, ylim.min=-0.31, offst.lbl=-0.062, title="B", subtitle="Weighted UniFrac\nEdnrb P20-WT Colon")
f1C_plot <- dend.plot(data=f1C_dend, ylim.min=-0.25, offst.lbl=-0.05, title="C", subtitle="Unweighted UniFrac\nEdnrb P20-KO Colon")
f1D_plot <- dend.plot(data=f1D_dend, ylim.min=-0.28, offst.lbl=-0.056, title="D", subtitle="Weighted UniFrac\nEdnrb P20-KO Colon")

# add theme
f1A_plot <- dend.theme(ggplot=f1A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1B_plot <- dend.theme(ggplot=f1B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1C_plot <- dend.theme(ggplot=f1C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
f1D_plot <- dend.theme(ggplot=f1D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(f1A_pvc) # edge 9 and 7
plot(f1B_pvc) # edge 9 and 7
plot(f1C_pvc) # edge 9 and 4
plot(f1D_pvc) # edge 9 and 8

# Step 2:
# create a data.frame of all the AU/BP values
f1A_pvals_all <- extrct.pvals.do.math(f1A_pvc, digits=2)
f1B_pvals_all <- extrct.pvals.do.math(f1B_pvc, digits=2)
f1C_pvals_all <- extrct.pvals.do.math(f1C_pvc, digits=2)
f1D_pvals_all <- extrct.pvals.do.math(f1D_pvc, digits=2)

# Step 3: 
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
f1A_pvals_flt <- f1A_pvals_all[c(9,7),]
f1A_pvals_flt[] <- lapply(f1A_pvals_flt, as.character)
row.names(f1A_pvals_flt) <- 1:nrow(f1A_pvals_flt)
f1B_pvals_flt <- f1B_pvals_all[c(9,7),]
f1B_pvals_flt[] <- lapply(f1B_pvals_flt, as.character)
row.names(f1B_pvals_flt) <- 1:nrow(f1B_pvals_flt)
f1C_pvals_flt <- f1C_pvals_all[c(9,4),]
f1C_pvals_flt[] <- lapply(f1C_pvals_flt, as.character)
row.names(f1C_pvals_flt) <- 1:nrow(f1C_pvals_flt)
f1D_pvals_flt <- f1D_pvals_all[c(9,8),]
f1D_pvals_flt[] <- lapply(f1D_pvals_flt, as.character)
row.names(f1D_pvals_flt) <- 1:nrow(f1D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
f1A_nodes_all <- intrnl.node.coords(f1A_dend)
f1B_nodes_all <- intrnl.node.coords(f1B_dend)
f1C_nodes_all <- intrnl.node.coords(f1C_dend)
f1D_nodes_all <- intrnl.node.coords(f1D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
f1A_plot.x <- f1A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                              axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1B_plot.x <- f1B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1C_plot.x <- f1C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
f1D_plot.x <- f1D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                               axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,11), breaks=c(1:11))
print(f1A_plot.x) # ~9 and ~2
print(f1B_plot.x) # ~7 and ~2.5
print(f1C_plot.x) # ~7 and ~2.5
print(f1D_plot.x) # ~8.5 and ~2

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
f1A_nodes_flt <- f1A_nodes_all[c(7,2),]
row.names(f1A_nodes_flt) <- 1:nrow(f1A_nodes_flt)
f1B_nodes_flt <- f1B_nodes_all[c(6,2),]
row.names(f1B_nodes_flt) <- 1:nrow(f1B_nodes_flt)
f1C_nodes_flt <- f1C_nodes_all[c(6,2),]
row.names(f1C_nodes_flt) <- 1:nrow(f1C_nodes_flt)
f1D_nodes_flt <- f1D_nodes_all[c(7,2),]
row.names(f1D_nodes_flt) <- 1:nrow(f1D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
f1A_labs <- cbind(f1A_pvals_flt, f1A_nodes_flt)
f1A_labs$clr <- "#ffffff"
f1B_labs <- cbind(f1B_pvals_flt, f1B_nodes_flt)
f1B_labs$clr <- "#ffffff"
f1C_labs <- cbind(f1C_pvals_flt, f1C_nodes_flt)
f1C_labs$clr <- "#ffffff"
f1D_labs <- cbind(f1D_pvals_flt, f1D_nodes_flt)
f1D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
f1A_vecx <- f1A_nodes_all[1,1]
f1A_vecy <- f1A_nodes_all[1,2]
f1A_veclab <- as.character("AU value (%)")
f1A_root_lab <- data.frame("x"=f1A_vecx,"y"=f1A_vecy,"lab"=f1A_veclab)
f1A_root_lab$clr <- "#ffffff"
f1B_vecx <- f1B_nodes_all[1,1]
f1B_vecy <- f1B_nodes_all[1,2]
f1B_veclab <- as.character("AU value (%)")
f1B_root_lab <- data.frame("x"=f1B_vecx,"y"=f1B_vecy,"lab"=f1B_veclab)
f1B_root_lab$clr <- "#ffffff"
f1C_vecx <- f1C_nodes_all[1,1]
f1C_vecy <- f1C_nodes_all[1,2]
f1C_veclab <- as.character("AU value (%)")
f1C_root_lab <- data.frame("x"=f1C_vecx,"y"=f1C_vecy,"lab"=f1C_veclab)
f1C_root_lab$clr <- "#ffffff"
f1D_vecx <- f1D_nodes_all[1,1]
f1D_vecy <- f1D_nodes_all[1,2]
f1D_veclab <- as.character("AU value (%)")
f1D_root_lab <- data.frame("x"=f1D_vecx,"y"=f1D_vecy,"lab"=f1D_veclab)
f1D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
f1A_root_y <- f1A_root_lab[1,2] - 0.1
f1B_root_y <- f1B_root_lab[1,2] - 0.1
f1C_root_y <- f1C_root_lab[1,2] - 0.1
f1D_root_y <- f1D_root_lab[1,2] - 0.1

# ggplot with AU % labels
f1A_plot.frmt <- f1A_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=6.7, xmax=11.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1A_labs, label=f1A_labs$au, x=f1A_labs$x, y=f1A_labs$y, 
             color=f1A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1A_root_lab, label=f1A_root_lab$lab, x=f1A_root_lab$x, y=f1A_root_y,
             color=f1A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1B_plot.frmt <- f1B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=11.3, ymin=-0.0496, ymax=-0.031, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.0496, ymax=-0.031, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1B_labs, label=f1B_labs$au, x=f1B_labs$x, y=f1B_labs$y, 
             color=f1B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1B_root_lab, label=f1B_root_lab$lab, x=f1B_root_lab$x, y=f1B_root_y,
             color=f1B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1C_plot.frmt <- f1C_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=11.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1C_labs, label=f1C_labs$au, x=f1C_labs$x, y=f1C_labs$y, 
             color=f1C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1C_root_lab, label=f1C_root_lab$lab, x=f1C_root_lab$x, y=f1C_root_y,
             color=f1C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

f1D_plot.frmt <- f1D_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=6.7, xmax=11.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=f1D_labs, label=f1D_labs$au, x=f1D_labs$x, y=f1D_labs$y, 
             color=f1D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=f1D_root_lab, label=f1D_root_lab$lab, x=f1D_root_lab$x, y=f1D_root_y,
             color=f1D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
fig_1 <- gridExtra::grid.arrange(f1A_plot.frmt, f1B_plot.frmt, f1C_plot.frmt, f1D_plot.frmt, ncol=2, widths=c(2,2),
                                 layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_1")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_1.tiff", plot=fig_1, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S1 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s1/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
fs1A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P07-WT", match.col="SampleID")
fs1A_dm <- fs1A.list$dm
fs1B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P07-WT", match.col="SampleID")
fs1B_dm <- fs1B.list$dm
fs1C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P07-KO", match.col="SampleID")
fs1C_dm <- fs1C.list$dm
fs1D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P07-KO", match.col="SampleID")
fs1D_dm <- fs1D.list$dm

# perform UPGMA clustering on the dm
fs1A_pvc <- clust.upgma(data=fs1A_dm, nboot=10000)
fs1B_pvc <- clust.upgma(data=fs1B_dm, nboot=10000)
fs1C_pvc <- clust.upgma(data=fs1C_dm, nboot=10000)
fs1D_pvc <- clust.upgma(data=fs1D_dm, nboot=10000)

# format the pvc data with the format file
fs1A_form <- format.ffile(data=fs1A_pvc, format.file=df.frmt.hscr)
fs1B_form <- format.ffile(data=fs1B_pvc, format.file=df.frmt.hscr)
fs1C_form <- format.ffile(data=fs1C_pvc, format.file=df.frmt.hscr)
fs1D_form <- format.ffile(data=fs1D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
fs1A_hc <- tip.labs(data=fs1A_pvc, format.file=fs1A_form, whichcol=fs1A_form$HC.facility)
fs1B_hc <- tip.labs(data=fs1B_pvc, format.file=fs1B_form, whichcol=fs1B_form$HC.facility)
fs1C_hc <- tip.labs(data=fs1C_pvc, format.file=fs1C_form, whichcol=fs1C_form$HC.facility)
fs1D_hc <- tip.labs(data=fs1D_pvc, format.file=fs1D_form, whichcol=fs1D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
fs1A_dend <- tip.cols(data=fs1A_hc, format.file=fs1A_form, whichcol=fs1A_form$HC.colorfacility)
fs1B_dend <- tip.cols(data=fs1B_hc, format.file=fs1B_form, whichcol=fs1B_form$HC.colorfacility)
fs1C_dend <- tip.cols(data=fs1C_hc, format.file=fs1C_form, whichcol=fs1C_form$HC.colorfacility)
fs1D_dend <- tip.cols(data=fs1D_hc, format.file=fs1D_form, whichcol=fs1D_form$HC.colorfacility)

# define tip label size
dendextend::labels_cex(fs1A_dend) <- 0.4
dendextend::labels_cex(fs1B_dend) <- 0.4
dendextend::labels_cex(fs1C_dend) <- 0.4
dendextend::labels_cex(fs1D_dend) <- 0.4

# define branch line width
fs1A_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs1A_dend, value=0.75, edgePar="lwd")
fs1B_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs1B_dend, value=0.75, edgePar="lwd")
fs1C_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs1C_dend, value=0.75, edgePar="lwd")
fs1D_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs1D_dend, value=0.75, edgePar="lwd")

# ggplot
fs1A_plot <- dend.plot(data=fs1A_dend, ylim.min=-0.25, offst.lbl=-0.05, title="A", subtitle="Unweighted UniFrac\nEdnrb P07-WT Colon")
fs1B_plot <- dend.plot(data=fs1B_dend, ylim.min=-0.32, offst.lbl=-0.064, title="B", subtitle="Weighted UniFrac\nEdnrb P07-WT Colon")
fs1C_plot <- dend.plot(data=fs1C_dend, ylim.min=-0.25, offst.lbl=-0.05, title="C", subtitle="Unweighted UniFrac\nEdnrb P07-KO Colon")
fs1D_plot <- dend.plot(data=fs1D_dend, ylim.min=-0.30, offst.lbl=-0.06, title="D", subtitle="Weighted UniFrac\nEdnrb P07-KO Colon")

# add theme
fs1A_plot <- dend.theme(ggplot=fs1A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs1B_plot <- dend.theme(ggplot=fs1B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs1C_plot <- dend.theme(ggplot=fs1C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs1D_plot <- dend.theme(ggplot=fs1D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(fs1A_pvc) # edge 8 and 4
plot(fs1B_pvc) # edge 8 and 3
plot(fs1C_pvc) # edge 7 and 6
plot(fs1D_pvc) # edge 7 and 6

# Step 2:
# create a data.frame of all the AU/BP values
fs1A_pvals_all <- extrct.pvals.do.math(fs1A_pvc, digits=2)
fs1B_pvals_all <- extrct.pvals.do.math(fs1B_pvc, digits=2)
fs1C_pvals_all <- extrct.pvals.do.math(fs1C_pvc, digits=2)
fs1D_pvals_all <- extrct.pvals.do.math(fs1D_pvc, digits=2)

# Step 3: 
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
fs1A_pvals_flt <- fs1A_pvals_all[c(8,4),]
fs1A_pvals_flt[] <- lapply(fs1A_pvals_flt, as.character)
row.names(fs1A_pvals_flt) <- 1:nrow(fs1A_pvals_flt)
fs1B_pvals_flt <- fs1B_pvals_all[c(8,3),]
fs1B_pvals_flt[] <- lapply(fs1B_pvals_flt, as.character)
row.names(fs1B_pvals_flt) <- 1:nrow(fs1B_pvals_flt)
fs1C_pvals_flt <- fs1C_pvals_all[c(7,6),]
fs1C_pvals_flt[] <- lapply(fs1C_pvals_flt, as.character)
row.names(fs1C_pvals_flt) <- 1:nrow(fs1C_pvals_flt)
fs1D_pvals_flt <- fs1D_pvals_all[c(7,6),]
fs1D_pvals_flt[] <- lapply(fs1D_pvals_flt, as.character)
row.names(fs1D_pvals_flt) <- 1:nrow(fs1D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
fs1A_nodes_all <- intrnl.node.coords(fs1A_dend)
fs1B_nodes_all <- intrnl.node.coords(fs1B_dend)
fs1C_nodes_all <- intrnl.node.coords(fs1C_dend)
fs1D_nodes_all <- intrnl.node.coords(fs1D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
fs1A_plot.x <- fs1A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
fs1B_plot.x <- fs1B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
fs1C_plot.x <- fs1C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
fs1D_plot.x <- fs1D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"), 
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
print(fs1A_plot.x) # ~6 and ~2
print(fs1B_plot.x) # ~6 and ~2.5
print(fs1C_plot.x) # ~7 and ~2.25
print(fs1D_plot.x) # ~7 and ~2

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
fs1A_nodes_flt <- fs1A_nodes_all[c(5,2),]
row.names(fs1A_nodes_flt) <- 1:nrow(fs1A_nodes_flt)
fs1B_nodes_flt <- fs1B_nodes_all[c(5,2),]
row.names(fs1B_nodes_flt) <- 1:nrow(fs1B_nodes_flt)
fs1C_nodes_flt <- fs1C_nodes_all[c(6,2),]
row.names(fs1C_nodes_flt) <- 1:nrow(fs1C_nodes_flt)
fs1D_nodes_flt <- fs1D_nodes_all[c(5,2),]
row.names(fs1D_nodes_flt) <- 1:nrow(fs1D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
fs1A_labs <- cbind(fs1A_pvals_flt, fs1A_nodes_flt)
fs1A_labs$clr <- "#ffffff"
fs1B_labs <- cbind(fs1B_pvals_flt, fs1B_nodes_flt)
fs1B_labs$clr <- "#ffffff"
fs1C_labs <- cbind(fs1C_pvals_flt, fs1C_nodes_flt)
fs1C_labs$clr <- "#ffffff"
fs1D_labs <- cbind(fs1D_pvals_flt, fs1D_nodes_flt)
fs1D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
fs1A_vecx <- fs1A_nodes_all[1,1]
fs1A_vecy <- fs1A_nodes_all[1,2]
fs1A_veclab <- as.character("AU value (%)")
fs1A_root_lab <- data.frame("x"=fs1A_vecx,"y"=fs1A_vecy,"lab"=fs1A_veclab)
fs1A_root_lab$clr <- "#ffffff"
fs1B_vecx <- fs1B_nodes_all[1,1]
fs1B_vecy <- fs1B_nodes_all[1,2]
fs1B_veclab <- as.character("AU value (%)")
fs1B_root_lab <- data.frame("x"=fs1B_vecx,"y"=fs1B_vecy,"lab"=fs1B_veclab)
fs1B_root_lab$clr <- "#ffffff"
fs1C_vecx <- fs1C_nodes_all[1,1]
fs1C_vecy <- fs1C_nodes_all[1,2]
fs1C_veclab <- as.character("AU value (%)")
fs1C_root_lab <- data.frame("x"=fs1C_vecx,"y"=fs1C_vecy,"lab"=fs1C_veclab)
fs1C_root_lab$clr <- "#ffffff"
fs1D_vecx <- fs1D_nodes_all[1,1]
fs1D_vecy <- fs1D_nodes_all[1,2]
fs1D_veclab <- as.character("AU value (%)")
fs1D_root_lab <- data.frame("x"=fs1D_vecx,"y"=fs1D_vecy,"lab"=fs1D_veclab)
fs1D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
fs1A_root_y <- fs1A_root_lab[1,2] - 0.1
fs1B_root_y <- fs1B_root_lab[1,2] - 0.1
fs1C_root_y <- fs1C_root_lab[1,2] - 0.1
fs1D_root_y <- fs1D_root_lab[1,2] - 0.1

# ggplot with AU % labels
fs1A_plot.frmt <- fs1A_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=10.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs1A_labs, label=fs1A_labs$au, x=fs1A_labs$x, y=fs1A_labs$y, 
             color=fs1A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs1A_root_lab, label=fs1A_root_lab$lab, x=fs1A_root_lab$x, y=fs1A_root_y,
             color=fs1A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs1B_plot.frmt <- fs1B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=10.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs1B_labs, label=fs1B_labs$au, x=fs1B_labs$x, y=fs1B_labs$y, 
             color=fs1B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs1B_root_lab, label=fs1B_root_lab$lab, x=fs1B_root_lab$x, y=fs1B_root_y,
             color=fs1B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs1C_plot.frmt <- fs1C_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=5.7, xmax=9.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=5.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs1C_labs, label=fs1C_labs$au, x=fs1C_labs$x, y=fs1C_labs$y, 
             color=fs1C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs1C_root_lab, label=fs1C_root_lab$lab, x=fs1C_root_lab$x, y=fs1C_root_y,
             color=fs1C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs1D_plot.frmt <- fs1D_plot + 
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=4.3, ymin=-0.048, ymax=-0.03, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=4.7, xmax=9.3, ymin=-0.048, ymax=-0.03, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs1D_labs, label=fs1D_labs$au, x=fs1D_labs$x, y=fs1D_labs$y, 
             color=fs1D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs1D_root_lab, label=fs1D_root_lab$lab, x=fs1D_root_lab$x, y=fs1D_root_y,
             color=fs1D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
fig_s1 <- gridExtra::grid.arrange(fs1A_plot.frmt, fs1B_plot.frmt, fs1C_plot.frmt, fs1D_plot.frmt,
                      ncol=2, widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s1")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s1.tiff", plot=fig_s1, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S2 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s2/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
fs2A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P24-WT", match.col="SampleID")
fs2A_dm <- fs2A.list$dm
fs2B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P24-WT", match.col="SampleID")
fs2B_dm <- fs2B.list$dm
fs2C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cBL_dm, flt.col.intrst="Group", flt.row.val="P24-KO", match.col="SampleID")
fs2C_dm <- fs2C.list$dm
fs2D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cBL_dm, flt.col.intrst="Group", flt.row.val="P24-KO", match.col="SampleID")
fs2D_dm <- fs2D.list$dm

# perform UPGMA clustering on the dm
fs2A_pvc <- clust.upgma(data=fs2A_dm, nboot=10000)
fs2B_pvc <- clust.upgma(data=fs2B_dm, nboot=10000)
fs2C_pvc <- clust.upgma(data=fs2C_dm, nboot=10000)
fs2D_pvc <- clust.upgma(data=fs2D_dm, nboot=10000)

# format the pvc data with the format file
fs2A_form <- format.ffile(data=fs2A_pvc, format.file=df.frmt.hscr)
fs2B_form <- format.ffile(data=fs2B_pvc, format.file=df.frmt.hscr)
fs2C_form <- format.ffile(data=fs2C_pvc, format.file=df.frmt.hscr)
fs2D_form <- format.ffile(data=fs2D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
fs2A_hc <- tip.labs(data=fs2A_pvc, format.file=fs2A_form, whichcol=fs2A_form$HC.facility)
fs2B_hc <- tip.labs(data=fs2B_pvc, format.file=fs2B_form, whichcol=fs2B_form$HC.facility)
fs2C_hc <- tip.labs(data=fs2C_pvc, format.file=fs2C_form, whichcol=fs2C_form$HC.facility)
fs2D_hc <- tip.labs(data=fs2D_pvc, format.file=fs2D_form, whichcol=fs2D_form$HC.facility)

# define tip colors (from the format file column), creates 'dendrogram' object
fs2A_dend <- tip.cols(data=fs2A_hc, format.file=fs2A_form, whichcol=fs2A_form$HC.colorfacility)
fs2B_dend <- tip.cols(data=fs2B_hc, format.file=fs2B_form, whichcol=fs2B_form$HC.colorfacility)
fs2C_dend <- tip.cols(data=fs2C_hc, format.file=fs2C_form, whichcol=fs2C_form$HC.colorfacility)
fs2D_dend <- tip.cols(data=fs2D_hc, format.file=fs2D_form, whichcol=fs2D_form$HC.colorfacility)

# define tip label size
dendextend::labels_cex(fs2A_dend) <- 0.4
dendextend::labels_cex(fs2B_dend) <- 0.4
dendextend::labels_cex(fs2C_dend) <- 0.4
dendextend::labels_cex(fs2D_dend) <- 0.4

# define branch line width
fs2A_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs2A_dend, value=0.75, edgePar="lwd")
fs2B_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs2B_dend, value=0.75, edgePar="lwd")
fs2C_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs2C_dend, value=0.75, edgePar="lwd")
fs2D_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs2D_dend, value=0.75, edgePar="lwd")

# ggplot
fs2A_plot <- dend.plot(data=fs2A_dend, ylim.min=-0.25, offst.lbl=-0.05, title="A", subtitle="Unweighted UniFrac\nEdnrb P24-WT Colon")
fs2B_plot <- dend.plot(data=fs2B_dend, ylim.min=-0.28, offst.lbl=-0.056, title="B", subtitle="Weighted UniFrac\nEdnrb P24-WT Colon")
fs2C_plot <- dend.plot(data=fs2C_dend, ylim.min=-0.25, offst.lbl=-0.05, title="C", subtitle="Unweighted UniFrac\nEdnrb P24-KO Colon")
fs2D_plot <- dend.plot(data=fs2D_dend, ylim.min=-0.32, offst.lbl=-0.064, title="D", subtitle="Weighted UniFrac\nEdnrb P24-KO Colon")

# add theme
fs2A_plot <- dend.theme(ggplot=fs2A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs2B_plot <- dend.theme(ggplot=fs2B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs2C_plot <- dend.theme(ggplot=fs2C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs2D_plot <- dend.theme(ggplot=fs2D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(fs2A_pvc) # edge 8 and 2
plot(fs2B_pvc) # edge 8 and 7
plot(fs2C_pvc) # edge 5 and 2
plot(fs2D_pvc) # edge 5 and 4

# Step 2:
# create a data.frame of all the AU/BP values
fs2A_pvals_all <- extrct.pvals.do.math(fs2A_pvc, digits=2)
fs2B_pvals_all <- extrct.pvals.do.math(fs2B_pvc, digits=2)
fs2C_pvals_all <- extrct.pvals.do.math(fs2C_pvc, digits=2)
fs2D_pvals_all <- extrct.pvals.do.math(fs2D_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
fs2A_pvals_flt <- fs2A_pvals_all[c(8,2),]
fs2A_pvals_flt[] <- lapply(fs2A_pvals_flt, as.character)
row.names(fs2A_pvals_flt) <- 1:nrow(fs2A_pvals_flt)
fs2B_pvals_flt <- fs2B_pvals_all[c(8,7),]
fs2B_pvals_flt[] <- lapply(fs2B_pvals_flt, as.character)
row.names(fs2B_pvals_flt) <- 1:nrow(fs2B_pvals_flt)
fs2C_pvals_flt <- fs2C_pvals_all[c(5,2),]
fs2C_pvals_flt[] <- lapply(fs2C_pvals_flt, as.character)
row.names(fs2C_pvals_flt) <- 1:nrow(fs2C_pvals_flt)
fs2D_pvals_flt <- fs2D_pvals_all[c(5,4),]
fs2D_pvals_flt[] <- lapply(fs2D_pvals_flt, as.character)
row.names(fs2D_pvals_flt) <- 1:nrow(fs2D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
fs2A_nodes_all <- intrnl.node.coords(fs2A_dend)
fs2B_nodes_all <- intrnl.node.coords(fs2B_dend)
fs2C_nodes_all <- intrnl.node.coords(fs2C_dend)
fs2D_nodes_all <- intrnl.node.coords(fs2D_dend)

# Step 5:
# re-plot the dendrogram plots from above, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
fs2A_plot.x <- fs2A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
fs2B_plot.x <- fs2B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
fs2C_plot.x <- fs2C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,7), breaks=c(1:7))
fs2D_plot.x <- fs2D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,7), breaks=c(1:7))
print(fs2A_plot.x) # ~5.5 and ~1.75
print(fs2B_plot.x) # ~8 and ~2.5
print(fs2C_plot.x) # ~5 and ~2
print(fs2D_plot.x) # ~5 and ~1.75

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
fs2A_nodes_flt <- fs2A_nodes_all[c(4,2),]
row.names(fs2A_nodes_flt) <- 1:nrow(fs2A_nodes_flt)
fs2B_nodes_flt <- fs2B_nodes_all[c(7,2),]
row.names(fs2B_nodes_flt) <- 1:nrow(fs2B_nodes_flt)
fs2C_nodes_flt <- fs2C_nodes_all[c(4,2),]
row.names(fs2C_nodes_flt) <- 1:nrow(fs2C_nodes_flt)
fs2D_nodes_flt <- fs2D_nodes_all[c(4,2),]
row.names(fs2D_nodes_flt) <- 1:nrow(fs2D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
fs2A_labs <- cbind(fs2A_pvals_flt, fs2A_nodes_flt)
fs2A_labs$clr <- "#ffffff"
fs2B_labs <- cbind(fs2B_pvals_flt, fs2B_nodes_flt)
fs2B_labs$clr <- "#ffffff"
fs2C_labs <- cbind(fs2C_pvals_flt, fs2C_nodes_flt)
fs2C_labs$clr <- "#ffffff"
fs2D_labs <- cbind(fs2D_pvals_flt, fs2D_nodes_flt)
fs2D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
fs2A_vecx <- fs2A_nodes_all[1,1]
fs2A_vecy <- fs2A_nodes_all[1,2]
fs2A_veclab <- as.character("AU value (%)")
fs2A_root_lab <- data.frame("x"=fs2A_vecx,"y"=fs2A_vecy,"lab"=fs2A_veclab)
fs2A_root_lab$clr <- "#ffffff"
fs2B_vecx <- fs2B_nodes_all[1,1]
fs2B_vecy <- fs2B_nodes_all[1,2]
fs2B_veclab <- as.character("AU value (%)")
fs2B_root_lab <- data.frame("x"=fs2B_vecx,"y"=fs2B_vecy,"lab"=fs2B_veclab)
fs2B_root_lab$clr <- "#ffffff"
fs2C_vecx <- fs2C_nodes_all[1,1]
fs2C_vecy <- fs2C_nodes_all[1,2]
fs2C_veclab <- as.character("AU value (%)")
fs2C_root_lab <- data.frame("x"=fs2C_vecx,"y"=fs2C_vecy,"lab"=fs2C_veclab)
fs2C_root_lab$clr <- "#ffffff"
fs2D_vecx <- fs2D_nodes_all[1,1]
fs2D_vecy <- fs2D_nodes_all[1,2]
fs2D_veclab <- as.character("AU value (%)")
fs2D_root_lab <- data.frame("x"=fs2D_vecx,"y"=fs2D_vecy,"lab"=fs2D_veclab)
fs2D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
fs2A_root_y <- fs2A_root_lab[1,2] - 0.1
fs2B_root_y <- fs2B_root_lab[1,2] - 0.1
fs2C_root_y <- fs2C_root_lab[1,2] - 0.1
fs2D_root_y <- fs2D_root_lab[1,2] - 0.1

# ggplot with AU % labels
fs2A_plot.frmt <- fs2A_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=3.7, xmax=10.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs2A_labs, label=fs2A_labs$au, x=fs2A_labs$x, y=fs2A_labs$y,
             color=fs2A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs2A_root_lab, label=fs2A_root_lab$lab, x=fs2A_root_lab$x, y=fs2A_root_y,
             color=fs2A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs2B_plot.frmt <- fs2B_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=6.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=7.7, xmax=10.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs2B_labs, label=fs2B_labs$au, x=fs2B_labs$x, y=fs2B_labs$y,
             color=fs2B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs2B_root_lab, label=fs2B_root_lab$lab, x=fs2B_root_lab$x, y=fs2B_root_y,
             color=fs2B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs2C_plot.frmt <- fs2C_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=3.7, xmax=7.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs2C_labs, label=fs2C_labs$au, x=fs2C_labs$x, y=fs2C_labs$y,
             color=fs2C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs2C_root_lab, label=fs2C_root_lab$lab, x=fs2C_root_lab$x, y=fs2C_root_y,
             color=fs2C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs2D_plot.frmt <- fs2D_plot +
  # optional: add cluster shading line for Laramie mice
  annotate("rect", xmin=0.7, xmax=3.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#af8dc3") +
  # optional: add cluster shading line for Boston mice
  annotate("rect", xmin=4.7, xmax=7.3, ymin=-0.0512, ymax=-0.032, alpha=0.55, fill="#7fbf7b") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs2D_labs, label=fs2D_labs$au, x=fs2D_labs$x, y=fs2D_labs$y,
             color=fs2D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node
  geom_label(data=fs2D_root_lab, label=fs2D_root_lab$lab, x=fs2D_root_lab$x, y=fs2D_root_y,
             color=fs2D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
fig_s2 <- gridExtra::grid.arrange(fs2A_plot.frmt, fs2B_plot.frmt, fs2C_plot.frmt, fs2D_plot.frmt, ncol=2, 
                                  widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s2")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s2.tiff", plot=fig_s2, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S3 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s3/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
fs3A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cLar_dm, flt.col.intrst="Age", flt.row.val="P07", match.col="SampleID")
fs3A_dm <- fs3A.list$dm
fs3B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cLar_dm, flt.col.intrst="Age", flt.row.val="P07", match.col="SampleID")
fs3B_dm <- fs3B.list$dm
fs3C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_fLar_dm, flt.col.intrst="Age", flt.row.val="P07", match.col="SampleID")
fs3C_dm <- fs3C.list$dm
fs3D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_fLar_dm, flt.col.intrst="Age", flt.row.val="P07", match.col="SampleID")
fs3D_dm <- fs3D.list$dm

# perform UPGMA clustering on the dm
fs3A_pvc <- clust.upgma(data=fs3A_dm, nboot=10000)
fs3B_pvc <- clust.upgma(data=fs3B_dm, nboot=10000)
fs3C_pvc <- clust.upgma(data=fs3C_dm, nboot=10000)
fs3D_pvc <- clust.upgma(data=fs3D_dm, nboot=10000)

# format the pvc data with the format file
fs3A_form <- format.ffile(data=fs3A_pvc, format.file=df.frmt.hscr)
fs3B_form <- format.ffile(data=fs3B_pvc, format.file=df.frmt.hscr)
fs3C_form <- format.ffile(data=fs3C_pvc, format.file=df.frmt.hscr)
fs3D_form <- format.ffile(data=fs3D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
fs3A_hc <- tip.labs(data=fs3A_pvc, format.file=fs3A_form, whichcol=fs3A_form$HC.cage)
fs3B_hc <- tip.labs(data=fs3B_pvc, format.file=fs3B_form, whichcol=fs3B_form$HC.cage)
fs3C_hc <- tip.labs(data=fs3C_pvc, format.file=fs3C_form, whichcol=fs3C_form$HC.cage)
fs3D_hc <- tip.labs(data=fs3D_pvc, format.file=fs3D_form, whichcol=fs3D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
fs3A_dend <- tip.cols(data=fs3A_hc, format.file=fs3A_form, whichcol=fs3A_form$HC.colorcage)
fs3B_dend <- tip.cols(data=fs3B_hc, format.file=fs3B_form, whichcol=fs3B_form$HC.colorcage)
fs3C_dend <- tip.cols(data=fs3C_hc, format.file=fs3C_form, whichcol=fs3C_form$HC.colorcage)
fs3D_dend <- tip.cols(data=fs3D_hc, format.file=fs3D_form, whichcol=fs3D_form$HC.colorcage)

# define tip label size
dendextend::labels_cex(fs3A_dend) <- 0.4
dendextend::labels_cex(fs3B_dend) <- 0.4
dendextend::labels_cex(fs3C_dend) <- 0.4
dendextend::labels_cex(fs3D_dend) <- 0.4

# define branch line width
fs3A_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs3A_dend, value=0.75, edgePar="lwd")
fs3B_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs3B_dend, value=0.75, edgePar="lwd")
fs3C_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs3C_dend, value=0.75, edgePar="lwd")
fs3D_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs3D_dend, value=0.75, edgePar="lwd")

# ggplot
fs3A_plot <- dend.plot(data=fs3A_dend, ylim.min=-0.25, offst.lbl=-0.05, title="A", subtitle="Unweighted UniFrac\nLaramie Ednrb P07 Colon")
fs3B_plot <- dend.plot(data=fs3B_dend, ylim.min=-0.28, offst.lbl=-0.056, title="B", subtitle="Weighted UniFrac\nLaramie Ednrb P07 Colon")
fs3C_plot <- dend.plot(data=fs3C_dend, ylim.min=-0.25, offst.lbl=-0.05, title="C", subtitle="Unweighted UniFrac\nLaramie Ednrb P07 Fecal")
fs3D_plot <- dend.plot(data=fs3D_dend, ylim.min=-0.28, offst.lbl=-0.056, title="D", subtitle="Weighted UniFrac\nLaramie Ednrb P07 Fecal")

# add theme
fs3A_plot <- dend.theme(ggplot=fs3A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs3B_plot <- dend.theme(ggplot=fs3B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs3C_plot <- dend.theme(ggplot=fs3C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs3D_plot <- dend.theme(ggplot=fs3D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# isolate information to plot AU % for the branch nodes of interest (8 steps)
# Step 1:
# plot the pvclust dendrograms
# manually (for now), take note of the edge #'s (light grey) for the branch nodes of interest
plot(fs3A_pvc) # edge 1
plot(fs3B_pvc) # edges 7 - 6 - 4 - 1
plot(fs3C_pvc) # edges 4 - 3 - 1
plot(fs3D_pvc) # edges 8 and 3

# Step 2:
# create a data.frame of all the AU/BP values
fs3A_pvals_all <- extrct.pvals.do.math(fs3A_pvc, digits=2)
fs3B_pvals_all <- extrct.pvals.do.math(fs3B_pvc, digits=2)
fs3C_pvals_all <- extrct.pvals.do.math(fs3C_pvc, digits=2)
fs3D_pvals_all <- extrct.pvals.do.math(fs3D_pvc, digits=2)

# Step 3:
# filter _pvals_all data.frame for the edge numbers (now row numbers), noted above
# order them from top down - this is important for merging later on
# convert all numeric values into characters
# renumber the rows
fs3A_pvals_flt <- fs3A_pvals_all[c(1),]
fs3A_pvals_flt[] <- lapply(fs3A_pvals_flt, as.character)
row.names(fs3A_pvals_flt) <- 1:nrow(fs3A_pvals_flt)
fs3B_pvals_flt <- fs3B_pvals_all[c(7,6,4,1),]
fs3B_pvals_flt[] <- lapply(fs3B_pvals_flt, as.character)
row.names(fs3B_pvals_flt) <- 1:nrow(fs3B_pvals_flt)
fs3C_pvals_flt <- fs3C_pvals_all[c(4,3,1),]
fs3C_pvals_flt[] <- lapply(fs3C_pvals_flt, as.character)
row.names(fs3C_pvals_flt) <- 1:nrow(fs3C_pvals_flt)
fs3D_pvals_flt <- fs3D_pvals_all[c(8,3),]
fs3D_pvals_flt[] <- lapply(fs3D_pvals_flt, as.character)
row.names(fs3D_pvals_flt) <- 1:nrow(fs3D_pvals_flt)

# Step 4:
# create a data.frame of (x,y) coordinates for each internal node
fs3A_nodes_all <- intrnl.node.coords(fs3A_dend)
fs3B_nodes_all <- intrnl.node.coords(fs3B_dend)
fs3C_nodes_all <- intrnl.node.coords(fs3C_dend)
fs3D_nodes_all <- intrnl.node.coords(fs3D_dend)

# Step 5:
# re-plot the dendrogram plots from above of, adding an x-axis scale
# print, and manually (for now), take note of the approximate location of each node along the x-axis
fs3A_plot.x <- fs3A_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
fs3B_plot.x <- fs3B_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,9), breaks=c(1:9))
fs3C_plot.x <- fs3C_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
fs3D_plot.x <- fs3D_plot + theme(axis.text.x=element_text(size=18, family="Helvetica"),
                                 axis.ticks.x=element_line(),axis.line.x=element_line()) +
  scale_x_continuous(limits=c(1,10), breaks=c(1:10))
print(fs3A_plot.x) # ~1.5
print(fs3B_plot.x) # ~5.5 ~1.5 ~3.75 ~4.5
print(fs3C_plot.x) # ~2.5 ~3.75 ~4.5
print(fs3D_plot.x) # ~8.5 ~7.5

# Step 6:
# filter _nodes_all data.frame for the nodes (now rows in column 'x') of interest, noted above
# NOTE: filtering row numbers with appropriate value in column 'x'
# order them from top down (based upon value in column 'y') - this is important for merging later on
# renumber the rows
fs3A_nodes_flt <- fs3A_nodes_all[c(2),]
row.names(fs3A_nodes_flt) <- 1:nrow(fs3A_nodes_flt)
fs3B_nodes_flt <- fs3B_nodes_all[c(3,2,4,5),]
row.names(fs3B_nodes_flt) <- 1:nrow(fs3B_nodes_flt)
fs3C_nodes_flt <- fs3C_nodes_all[c(2,4,5),]
row.names(fs3C_nodes_flt) <- 1:nrow(fs3C_nodes_flt)
fs3D_nodes_flt <- fs3D_nodes_all[c(7,8),]
row.names(fs3D_nodes_flt) <- 1:nrow(fs3D_nodes_flt)

# Step 7:
# combine _pvals_flt and _nodes_flt
# add in a column for color
fs3A_labs <- cbind(fs3A_pvals_flt, fs3A_nodes_flt)
fs3A_labs$clr <- "#ffffff"
fs3B_labs <- cbind(fs3B_pvals_flt, fs3B_nodes_flt)
fs3B_labs$clr <- "#ffffff"
fs3C_labs <- cbind(fs3C_pvals_flt, fs3C_nodes_flt)
fs3C_labs$clr <- "#ffffff"
fs3D_labs <- cbind(fs3D_pvals_flt, fs3D_nodes_flt)
fs3D_labs$clr <- "#ffffff"

# Step 8:
# create a data frame to label the root node
# first, create vectors with appropriate values
# next, merge them into a data.frame,
# finally, add in a column for color
fs3A_vecx <- fs3A_nodes_all[1,1]
fs3A_vecy <- fs3A_nodes_all[1,2]
fs3A_veclab <- as.character("AU value (%)")
fs3A_root_lab <- data.frame("x"=fs3A_vecx,"y"=fs3A_vecy,"lab"=fs3A_veclab)
fs3A_root_lab$clr <- "#ffffff"
fs3B_vecx <- fs3B_nodes_all[1,1]
fs3B_vecy <- fs3B_nodes_all[1,2]
fs3B_veclab <- as.character("AU value (%)")
fs3B_root_lab <- data.frame("x"=fs3B_vecx,"y"=fs3B_vecy,"lab"=fs3B_veclab)
fs3B_root_lab$clr <- "#ffffff"
fs3C_vecx <- fs3C_nodes_all[1,1]
fs3C_vecy <- fs3C_nodes_all[1,2]
fs3C_veclab <- as.character("AU value (%)")
fs3C_root_lab <- data.frame("x"=fs3C_vecx,"y"=fs3C_vecy,"lab"=fs3C_veclab)
fs3C_root_lab$clr <- "#ffffff"
fs3D_vecx <- fs3D_nodes_all[1,1]
fs3D_vecy <- fs3D_nodes_all[1,2]
fs3D_veclab <- as.character("AU value (%)")
fs3D_root_lab <- data.frame("x"=fs3D_vecx,"y"=fs3D_vecy,"lab"=fs3D_veclab)
fs3D_root_lab$clr <- "#ffffff"

# NOTE: the x and y-values isolated in _root_lab data.frames above may or may not...
# ... need altered to achieve proper placement in the final plot below
# if needed, add or subtract from them, creating a new vector in the process
fs3A_root_y <- fs3A_root_lab[1,2] - 0.1
fs3B_root_y <- fs3B_root_lab[1,2] - 0.1
fs3C_root_y <- fs3C_root_lab[1,2] - 0.1
fs3D_root_y <- fs3D_root_lab[1,2] - 0.1

# ggplot with AU % labels
fs3A_plot.frmt <- fs3A_plot +
  # add cluster shading line for mice from the same cage
  annotate("rect", xmin=0.7, xmax=2.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#636363") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs3A_labs, label=fs3A_labs$au, x=fs3A_labs$x, y=fs3A_labs$y,
             color=fs3A_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=fs3A_root_lab, label=fs3A_root_lab$lab, x=fs3A_root_lab$x, y=fs3A_root_y,
        #     color=fs3A_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
           #  label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs3B_plot.frmt <- fs3B_plot +
  # add cluster shading lines for mice from the same cage
  annotate("rect", xmin=0.7, xmax=2.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#ff7f00") +
  annotate("rect", xmin=3.7, xmax=5.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#636363") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs3B_labs, label=fs3B_labs$au, x=fs3B_labs$x, y=fs3B_labs$y,
             color=fs3B_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=fs3B_root_lab, label=fs3B_root_lab$lab, x=fs3B_root_lab$x, y=fs3B_root_y,
   #          color=fs3B_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs3C_plot.frmt <- fs3C_plot +
  # add cluster shading lines for mice from the same cage
  annotate("rect", xmin=3.7, xmax=5.3, ymin=-0.04, ymax=-0.025, alpha=0.55, fill="#984ea3") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs3C_labs, label=fs3C_labs$au, x=fs3C_labs$x, y=fs3C_labs$y,
             color=fs3C_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=fs3C_root_lab, label=fs3C_root_lab$lab, x=fs3C_root_lab$x, y=fs3C_root_y,
   #          color=fs3C_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs3D_plot.frmt <- fs3D_plot +# add cluster shading lines for mice from the same cage
  annotate("rect", xmin=6.7, xmax=8.3, ymin=-0.0448, ymax=-0.028, alpha=0.55, fill="#984ea3") +
  # AU % labels for branch nodes of interest
  geom_label(data=fs3D_labs, label=fs3D_labs$au, x=fs3D_labs$x, y=fs3D_labs$y,
             color=fs3D_labs$clr, label.r=unit(0,"mm"), label.padding=unit(.4,"mm"),
             label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  # AU % label for root node (hashed-out, because it has been defined in the legend)
  #geom_label(data=fs3D_root_lab, label=fs3D_root_lab$lab, x=fs3D_root_lab$x, y=fs3D_root_y,
   #          color=fs3D_root_lab$clr, label.r=unit(0,"mm"), label.padding=unit(0.7,"mm"),
    #         label.size=NA, size=1.5, fill="black", vjust="middle", hjust="middle", family="Helvetica") +
  theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
fig_s3 <- gridExtra::grid.arrange(fs3A_plot.frmt, fs3B_plot.frmt, fs3C_plot.frmt, fs3D_plot.frmt, ncol=2, 
                                  widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s3")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s3.tiff", plot=fig_s3, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S4 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s4/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
fs4A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cLar_dm, flt.col.intrst="Age", flt.row.val="P20", match.col="SampleID")
fs4A_dm <- fs4A.list$dm
fs4B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cLar_dm, flt.col.intrst="Age", flt.row.val="P20", match.col="SampleID")
fs4B_dm <- fs4B.list$dm
fs4C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_fLar_dm, flt.col.intrst="Age", flt.row.val="P20", match.col="SampleID")
fs4C_dm <- fs4C.list$dm
fs4D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_fLar_dm, flt.col.intrst="Age", flt.row.val="P20", match.col="SampleID")
fs4D_dm <- fs4D.list$dm

# perform UPGMA clustering on the dm
fs4A_pvc <- clust.upgma(data=fs4A_dm, nboot=10000)
fs4B_pvc <- clust.upgma(data=fs4B_dm, nboot=10000)
fs4C_pvc <- clust.upgma(data=fs4C_dm, nboot=10000)
fs4D_pvc <- clust.upgma(data=fs4D_dm, nboot=10000)

# format the pvc data with the format file
fs4A_form <- format.ffile(data=fs4A_pvc, format.file=df.frmt.hscr)
fs4B_form <- format.ffile(data=fs4B_pvc, format.file=df.frmt.hscr)
fs4C_form <- format.ffile(data=fs4C_pvc, format.file=df.frmt.hscr)
fs4D_form <- format.ffile(data=fs4D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
fs4A_hc <- tip.labs(data=fs4A_pvc, format.file=fs4A_form, whichcol=fs4A_form$HC.cage)
fs4B_hc <- tip.labs(data=fs4B_pvc, format.file=fs4B_form, whichcol=fs4B_form$HC.cage)
fs4C_hc <- tip.labs(data=fs4C_pvc, format.file=fs4C_form, whichcol=fs4C_form$HC.cage)
fs4D_hc <- tip.labs(data=fs4D_pvc, format.file=fs4D_form, whichcol=fs4D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
fs4A_dend <- tip.cols(data=fs4A_hc, format.file=fs4A_form, whichcol=fs4A_form$HC.colorcage)
fs4B_dend <- tip.cols(data=fs4B_hc, format.file=fs4B_form, whichcol=fs4B_form$HC.colorcage)
fs4C_dend <- tip.cols(data=fs4C_hc, format.file=fs4C_form, whichcol=fs4C_form$HC.colorcage)
fs4D_dend <- tip.cols(data=fs4D_hc, format.file=fs4D_form, whichcol=fs4D_form$HC.colorcage)

# define tip label size
dendextend::labels_cex(fs4A_dend) <- 0.4
dendextend::labels_cex(fs4B_dend) <- 0.4
dendextend::labels_cex(fs4C_dend) <- 0.4
dendextend::labels_cex(fs4D_dend) <- 0.4

# define branch line width
fs4A_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs4A_dend, value=0.75, edgePar="lwd")
fs4B_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs4B_dend, value=0.75, edgePar="lwd")
fs4C_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs4C_dend, value=0.75, edgePar="lwd")
fs4D_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs4D_dend, value=0.75, edgePar="lwd")

# ggplot
fs4A_plot <- dend.plot(data=fs4A_dend, ylim.min=-0.25, offst.lbl=-0.025, title="A", subtitle="Unweighted UniFrac\nLaramie Ednrb P20 Colon")
fs4B_plot <- dend.plot(data=fs4B_dend, ylim.min=-0.31, offst.lbl=-0.031, title="B", subtitle="Weighted UniFrac\nLaramie Ednrb P20 Colon")
fs4C_plot <- dend.plot(data=fs4C_dend, ylim.min=-0.25, offst.lbl=-0.025, title="C", subtitle="Unweighted UniFrac\nLaramie Ednrb P20 Fecal")
fs4D_plot <- dend.plot(data=fs4D_dend, ylim.min=-0.25, offst.lbl=-0.025, title="D", subtitle="Weighted UniFrac\nLaramie Ednrb P20 Fecal")

# add theme
fs4A_plot <- dend.theme(ggplot=fs4A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs4B_plot <- dend.theme(ggplot=fs4B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs4C_plot <- dend.theme(ggplot=fs4C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs4D_plot <- dend.theme(ggplot=fs4D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# no clear clusters, skip to ggplot .frmt

# ggplot with formatting
fs4A_plot.frmt <- fs4A_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs4B_plot.frmt <- fs4B_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs4C_plot.frmt <- fs4C_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs4D_plot.frmt <- fs4D_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels

fig_s4 <- gridExtra::grid.arrange(fs4A_plot.frmt, fs4B_plot.frmt, fs4C_plot.frmt, fs4D_plot.frmt, ncol=2, 
                                  widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s4")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s4.tiff", plot=fig_s4, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S5 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s5/")

# filter distance matrix for the appropriate groups
# NOTE: the filtered metadata file is uneeded
fs5A.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_cLar_dm, flt.col.intrst="Age", flt.row.val="P24", match.col="SampleID")
fs5A_dm <- fs5A.list$dm
fs5B.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_cLar_dm, flt.col.intrst="Age", flt.row.val="P24", match.col="SampleID")
fs5B_dm <- fs5B.list$dm
fs5C.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=uw_fLar_dm, flt.col.intrst="Age", flt.row.val="P24", match.col="SampleID")
fs5C_dm <- fs5C.list$dm
fs5D.list <- flt.dm.and.meta(meta=df.meta.hscr, dist.obj=w_fLar_dm, flt.col.intrst="Age", flt.row.val="P24", match.col="SampleID")
fs5D_dm <- fs5D.list$dm

# perform UPGMA clustering on the dm
fs5A_pvc <- clust.upgma(data=fs5A_dm, nboot=10000)
fs5B_pvc <- clust.upgma(data=fs5B_dm, nboot=10000)
fs5C_pvc <- clust.upgma(data=fs5C_dm, nboot=10000)
fs5D_pvc <- clust.upgma(data=fs5D_dm, nboot=10000)

# format the pvc data with the format file
fs5A_form <- format.ffile(data=fs5A_pvc, format.file=df.frmt.hscr)
fs5B_form <- format.ffile(data=fs5B_pvc, format.file=df.frmt.hscr)
fs5C_form <- format.ffile(data=fs5C_pvc, format.file=df.frmt.hscr)
fs5D_form <- format.ffile(data=fs5D_pvc, format.file=df.frmt.hscr)

# define tip labels (from the format file column), creates 'hclust' object
fs5A_hc <- tip.labs(data=fs5A_pvc, format.file=fs5A_form, whichcol=fs5A_form$HC.cage)
fs5B_hc <- tip.labs(data=fs5B_pvc, format.file=fs5B_form, whichcol=fs5B_form$HC.cage)
fs5C_hc <- tip.labs(data=fs5C_pvc, format.file=fs5C_form, whichcol=fs5C_form$HC.cage)
fs5D_hc <- tip.labs(data=fs5D_pvc, format.file=fs5D_form, whichcol=fs5D_form$HC.cage)

# define tip colors (from the format file column), creates 'dendrogram' object
fs5A_dend <- tip.cols(data=fs5A_hc, format.file=fs5A_form, whichcol=fs5A_form$HC.colorcage)
fs5B_dend <- tip.cols(data=fs5B_hc, format.file=fs5B_form, whichcol=fs5B_form$HC.colorcage)
fs5C_dend <- tip.cols(data=fs5C_hc, format.file=fs5C_form, whichcol=fs5C_form$HC.colorcage)
fs5D_dend <- tip.cols(data=fs5D_hc, format.file=fs5D_form, whichcol=fs5D_form$HC.colorcage)

# define tip label size
dendextend::labels_cex(fs5A_dend) <- 0.4
dendextend::labels_cex(fs5B_dend) <- 0.4
dendextend::labels_cex(fs5C_dend) <- 0.4
dendextend::labels_cex(fs5D_dend) <- 0.4

# define branch line width
fs5A_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs5A_dend, value=0.75, edgePar="lwd")
fs5B_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs5B_dend, value=0.75, edgePar="lwd")
fs5C_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs5C_dend, value=0.75, edgePar="lwd")
fs5D_dend <- dendextend::assign_values_to_branches_edgePar(dend=fs5D_dend, value=0.75, edgePar="lwd")

# ggplot
fs5A_plot <- dend.plot(data=fs5A_dend, ylim.min=-0.25, offst.lbl=-0.025, title="A", subtitle="Unweighted UniFrac\nLaramie Ednrb P24 Colon")
fs5B_plot <- dend.plot(data=fs5B_dend, ylim.min=-0.31, offst.lbl=-0.031, title="B", subtitle="Weighted UniFrac\nLaramie Ednrb P24 Colon")
fs5C_plot <- dend.plot(data=fs5C_dend, ylim.min=-0.25, offst.lbl=-0.025, title="C", subtitle="Unweighted UniFrac\nLaramie Ednrb P24 Fecal")
fs5D_plot <- dend.plot(data=fs5D_dend, ylim.min=-0.36, offst.lbl=-0.072, title="D", subtitle="Weighted UniFrac\nLaramie Ednrb P24 Fecal")

# add theme
fs5A_plot <- dend.theme(ggplot=fs5A_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs5B_plot <- dend.theme(ggplot=fs5B_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs5C_plot <- dend.theme(ggplot=fs5C_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")
fs5D_plot <- dend.theme(ggplot=fs5D_plot, ttl.size=11, sub.ttl.size=7, font.fam="Helvetica")

# no clear clusters, skip to ggplot .frmt

# ggplot with formatting
fs5A_plot.frmt <- fs5A_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs5B_plot.frmt <- fs5B_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs5C_plot.frmt <- fs5C_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

fs5D_plot.frmt <- fs5D_plot + theme(plot.margin=unit(c(0.25,0,-1,0), "lines"))

# arrange plots into panels
fig_s5 <- gridExtra::grid.arrange(fs5A_plot.frmt, fs5B_plot.frmt, fs5C_plot.frmt, fs5D_plot.frmt, ncol=2, 
                                  widths=c(2,2), layout_matrix=cbind(c(1,1,3,3), c(2,2,4,4)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s5")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s5.tiff", plot=fig_s5, dpi=600, width=85, height=119, units="mm", device="tiff", type="cairo", compression="lzw")

##########################################
################ FIGURE 2 ################
##########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_2/")

# read in the distance matrices
f2A_dm <- read.dm(file="w_cBL_P20WTcore.txt")
f2B_dm <- read.dm(file="w_fBL_P20WTcore.txt")
f2C_dm <- read.dm(file="w_cBL_P20KOcore.txt")
f2D_dm <- read.dm(file="w_fBL_P20KOcore.txt")

# using package ape, perform principal coordinates analysis
f2A_pcoa <- ape::pcoa(f2A_dm)
f2B_pcoa <- ape::pcoa(f2B_dm)
f2C_pcoa <- ape::pcoa(f2C_dm)
f2D_pcoa <- ape::pcoa(f2D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
f2A_eigs <- iso.PC(f2A_pcoa)
f2B_eigs <- iso.PC(f2B_pcoa)
f2C_eigs <- iso.PC(f2C_pcoa)
f2D_eigs <- iso.PC(f2D_pcoa)

# create the axis labels
f2A_PC1 <- paste("PC 1 (", round(f2A_eigs[1]*100,0), "%)", sep ="")
f2A_PC2 <- paste("\nPC 2 (", round(f2A_eigs[2]*100,0), "%)", sep ="")
f2B_PC1 <- paste("PC 1 (", round(f2B_eigs[1]*100,0), "%)", sep ="")
f2B_PC2 <- paste("\nPC 2 (", round(f2B_eigs[2]*100,0), "%)", sep ="")
f2C_PC1 <- paste("PC 1 (", round(f2C_eigs[1]*100,0), "%)", sep ="")
f2C_PC2 <- paste("\nPC 2 (", round(f2C_eigs[2]*100,0), "%)", sep ="")
f2D_PC1 <- paste("PC 1 (", round(f2D_eigs[1]*100,0), "%)", sep ="")
f2D_PC2 <- paste("\nPC 2 (", round(f2D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
f2A_coords <- iso.coords(f2A_pcoa)
f2B_coords <- iso.coords(f2B_pcoa)
f2C_coords <- iso.coords(f2C_pcoa)
f2D_coords <- iso.coords(f2D_pcoa)

# merge in metadata from map
f2A_df <- merge(x=df.meta.hscr, y=f2A_coords, by="SampleID", sort=FALSE, all=FALSE)
f2B_df <- merge(x=df.meta.hscr, y=f2B_coords, by="SampleID", sort=FALSE, all=FALSE)
f2C_df <- merge(x=df.meta.hscr, y=f2C_coords, by="SampleID", sort=FALSE, all=FALSE)
f2D_df <- merge(x=df.meta.hscr, y=f2D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
f2A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
f2D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                    "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")

# add shapes
f2A_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2B_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2C_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)
f2D_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17,17)

# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
f2A_ell <- rKIN::estEllipse(f2A_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
f2B_ell <- rKIN::estEllipse(f2B_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
f2C_ell <- rKIN::estEllipse(f2C_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
f2D_ell <- rKIN::estEllipse(f2D_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
f2A_olap <- rKIN::calcOverlap(f2A_ell)
f2B_olap <- rKIN::calcOverlap(f2B_ell)
f2C_olap <- rKIN::calcOverlap(f2C_ell)
f2D_olap <- rKIN::calcOverlap(f2D_ell)

# plot with defaults
f2A_plot <- pcoa.plot(data=f2A_ell, xlab=f2A_PC1, ylab=f2A_PC2, scaler=0.05,  title="A", 
                      subtitle="Weighted UniFrac\nEdnrb P20-WT Colon", alpha=0.16) 
f2B_plot <- pcoa.plot(data=f2B_ell, xlab=f2B_PC1, ylab=f2B_PC2, scaler=0.05, title="B",
                      subtitle="Weighted UniFrac\nEdnrb P20-WT Fecal", alpha=0.16)
f2C_plot <- pcoa.plot(data=f2C_ell, xlab=f2C_PC1, ylab=f2C_PC2, scaler=0.05, title="C", 
                      subtitle="Weighted UniFrac\nEdnrb P20-KO Colon", alpha=0.16)
f2D_plot <- pcoa.plot(data=f2D_ell, xlab=f2D_PC1, ylab=f2D_PC2, scaler=0.05, title="D", 
                      subtitle="Weighted UniFrac\nEdnrb P20-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
f2A_plot <- pcoa.theme(ggplot=f2A_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

f2B_plot <- pcoa.theme(ggplot=f2B_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

f2C_plot <- pcoa.theme(ggplot=f2C_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

f2D_plot <- pcoa.theme(ggplot=f2D_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

# customize points
f2A_plot.frmt <- f2A_plot +
  geom_point(inherit.aes=FALSE, data=f2A_df, x=f2A_df$X.Coord, y=f2A_df$Y.Coord,
             shape=f2A_df$fac.shp, color=f2A_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2B_plot.frmt <- f2B_plot +
  geom_point(inherit.aes=FALSE, data=f2B_df, x=f2B_df$X.Coord, y=f2B_df$Y.Coord,
             shape=f2B_df$fac.shp, color=f2B_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2C_plot.frmt <- f2C_plot +
  geom_point(inherit.aes=FALSE, data=f2C_df, x=f2C_df$X.Coord, y=f2C_df$Y.Coord,
             shape=f2C_df$fac.shp, color=f2C_df$fac.clr, alpha=1, size=1.5, stroke=0)

f2D_plot.frmt <- f2D_plot +
  geom_point(inherit.aes=FALSE, data=f2D_df, x=f2D_df$X.Coord, y=f2D_df$Y.Coord,
             shape=f2D_df$fac.shp, color=f2D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# create custom legend using shapes to represent the proper groups
# create vector in order to create data.frame
vec.lgnd.x <- c(1,2)
vec.lgnd.y <- 1
vec.lgnd <- c("Boston","Laramie")
df_lgnd <- data.frame("x"=vec.lgnd.x, "y"=vec.lgnd.y, "fax"=vec.lgnd)

# define the legend labels
lbls <- c("Boston","Laramie")

# define shapes and colors for each facility
# contrast color scheme
vals.shp <- c(16,17)
vals.fll <- c("#1b7837","#762a83")

# ggplot
lgnd <- lgnd.plot(data=df_lgnd, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                  alpha=1, lbls=lbls, vals.fll=vals.fll, vals.clr=vals.fll, vals.shp=vals.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd <- lgnd.theme(ggplot=lgnd, txt.size=9, lgnd.shp.size=2, font.fam="Helvetica")

# NOTE: only one legend is created as the legend is identical in Figures 2, S6, S7

# arrange plots into panels
fig_2 <- gridExtra::grid.arrange(f2A_plot.frmt, f2B_plot.frmt, f2C_plot.frmt, f2D_plot.frmt, lgnd, ncol=3, nrow=2, 
                                 layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_2/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_2.tiff", plot=fig_2, dpi=600, width=110, height=110, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S6 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s6/")

# read in the distance matrices
fs6A_dm <- read.dm(file="w_cBL_P07WTcore.txt")
fs6B_dm <- read.dm(file="w_fBL_P07WTcore.txt")
fs6C_dm <- read.dm(file="w_cBL_P07KOcore.txt")
fs6D_dm <- read.dm(file="w_fBL_P07KOcore.txt")

# using package ape, perform principal coordinates analysis
fs6A_pcoa <- ape::pcoa(fs6A_dm)
fs6B_pcoa <- ape::pcoa(fs6B_dm)
fs6C_pcoa <- ape::pcoa(fs6C_dm)
fs6D_pcoa <- ape::pcoa(fs6D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
fs6A_eigs <- iso.PC(fs6A_pcoa)
fs6B_eigs <- iso.PC(fs6B_pcoa)
fs6C_eigs <- iso.PC(fs6C_pcoa)
fs6D_eigs <- iso.PC(fs6D_pcoa)

# create the axis labels
fs6A_PC1 <- paste("PC 1 (", round(fs6A_eigs[1]*100,0), "%)", sep ="")
fs6A_PC2 <- paste("\nPC 2 (", round(fs6A_eigs[2]*100,0), "%)", sep ="")
fs6B_PC1 <- paste("PC 1 (", round(fs6B_eigs[1]*100,0), "%)", sep ="")
fs6B_PC2 <- paste("\nPC 2 (", round(fs6B_eigs[2]*100,0), "%)", sep ="")
fs6C_PC1 <- paste("PC 1 (", round(fs6C_eigs[1]*100,0), "%)", sep ="")
fs6C_PC2 <- paste("\nPC 2 (", round(fs6C_eigs[2]*100,0), "%)", sep ="")
fs6D_PC1 <- paste("PC 1 (", round(fs6D_eigs[1]*100,0), "%)", sep ="")
fs6D_PC2 <- paste("\nPC 2 (", round(fs6D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
fs6A_coords <- iso.coords(fs6A_pcoa)
fs6B_coords <- iso.coords(fs6B_pcoa)
fs6C_coords <- iso.coords(fs6C_pcoa)
fs6D_coords <- iso.coords(fs6D_pcoa)

# merge in metadata from map
fs6A_df <- merge(x=df.meta.hscr, y=fs6A_coords, by="SampleID", sort=FALSE, all=FALSE)
fs6B_df <- merge(x=df.meta.hscr, y=fs6B_coords, by="SampleID", sort=FALSE, all=FALSE)
fs6C_df <- merge(x=df.meta.hscr, y=fs6C_coords, by="SampleID", sort=FALSE, all=FALSE)
fs6D_df <- merge(x=df.meta.hscr, y=fs6D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
fs6A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")
fs6B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")
fs6C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
fs6D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83")

# add shapes
fs6A_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)
fs6B_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)
fs6C_df$fac.shp <- c(16,16,16,16,16,17,17,17,17)
fs6D_df$fac.shp <- c(16,16,16,16,16,17,17,17,17,17)

# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
fs6A_ell <- rKIN::estEllipse(fs6A_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs6B_ell <- rKIN::estEllipse(fs6B_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs6C_ell <- rKIN::estEllipse(fs6C_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs6D_ell <- rKIN::estEllipse(fs6D_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
fs6A_olap <- rKIN::calcOverlap(fs6A_ell)
fs6B_olap <- rKIN::calcOverlap(fs6B_ell)
fs6C_olap <- rKIN::calcOverlap(fs6C_ell)
fs6D_olap <- rKIN::calcOverlap(fs6D_ell)

# plot with defaults
fs6A_plot <- pcoa.plot(data=fs6A_ell, xlab=fs6A_PC1, ylab=fs6A_PC2, scaler=0.05, title="A", 
                       subtitle="Weighted UniFrac\nEdnrb P07-WT Colon", alpha=0.16) 
fs6B_plot <- pcoa.plot(data=fs6B_ell, xlab=fs6B_PC1, ylab=fs6B_PC2, scaler=0.05, title="B", 
                       subtitle="Weighted UniFrac\nEdnrb P07-WT Fecal", alpha=0.16)
fs6C_plot <- pcoa.plot(data=fs6C_ell, xlab=fs6C_PC1, ylab=fs6C_PC2, scaler=0.05, title="C", 
                       subtitle="Weighted UniFrac\nEdnrb P07-KO Colon", alpha=0.16)
fs6D_plot <- pcoa.plot(data=fs6D_ell, xlab=fs6D_PC1, ylab=fs6D_PC2, scaler=0.05, title="D", 
                       subtitle="Weighted UniFrac\nEdnrb P07-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
fs6A_plot <- pcoa.theme(ggplot=fs6A_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs6B_plot <- pcoa.theme(ggplot=fs6B_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs6C_plot <- pcoa.theme(ggplot=fs6C_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs6D_plot <- pcoa.theme(ggplot=fs6D_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

# customize points
fs6A_plot.frmt <- fs6A_plot +
  geom_point(inherit.aes=FALSE, data=fs6A_df, x=fs6A_df$X.Coord, y=fs6A_df$Y.Coord,
             shape=fs6A_df$fac.shp, color=fs6A_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs6B_plot.frmt <- fs6B_plot +
  geom_point(inherit.aes=FALSE, data=fs6B_df, x=fs6B_df$X.Coord, y=fs6B_df$Y.Coord,
             shape=fs6B_df$fac.shp, color=fs6B_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs6C_plot.frmt <- fs6C_plot +
  geom_point(inherit.aes=FALSE, data=fs6C_df, x=fs6C_df$X.Coord, y=fs6C_df$Y.Coord,
             shape=fs6C_df$fac.shp, color=fs6C_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs6D_plot.frmt <- fs6D_plot +
  geom_point(inherit.aes=FALSE, data=fs6D_df, x=fs6D_df$X.Coord, y=fs6D_df$Y.Coord,
             shape=fs6D_df$fac.shp, color=fs6D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# arrange plots into panels
fig_s6 <- gridExtra::grid.arrange(fs6A_plot.frmt, fs6B_plot.frmt, fs6C_plot.frmt, fs6D_plot.frmt, lgnd, ncol=3, 
                                  nrow=2, layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s6/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s6.tiff", plot=fig_s6, dpi=600, width=110, height=110, units="mm", device="tiff", type="cairo", compression="lzw")

###########################################
################ FIGURE S7 ################
###########################################

# set the working directory
setwd("~/Desktop/r_analysis/fig_s7/")

# read in the distance matrices
fs7A_dm <- read.dm(file="w_cBL_P24WTcore.txt")
fs7B_dm <- read.dm(file="w_fBL_P24WTcore.txt")
fs7C_dm <- read.dm(file="w_cBL_P24KOcore.txt")
fs7D_dm <- read.dm(file="w_fBL_P24KOcore.txt")

# using package ape, perform principal coordinates analysis
fs7A_pcoa <- ape::pcoa(fs7A_dm)
fs7B_pcoa <- ape::pcoa(fs7B_dm)
fs7C_pcoa <- ape::pcoa(fs7C_dm)
fs7D_pcoa <- ape::pcoa(fs7D_dm)

# isolate PC1 and PC2 axis percentages
# these will become our X and Y axis labels
fs7A_eigs <- iso.PC(fs7A_pcoa)
fs7B_eigs <- iso.PC(fs7B_pcoa)
fs7C_eigs <- iso.PC(fs7C_pcoa)
fs7D_eigs <- iso.PC(fs7D_pcoa)

# create the axis labels
fs7A_PC1 <- paste("PC 1 (", round(fs7A_eigs[1]*100,0), "%)", sep ="")
fs7A_PC2 <- paste("\nPC 2 (", round(fs7A_eigs[2]*100,0), "%)", sep ="")
fs7B_PC1 <- paste("PC 1 (", round(fs7B_eigs[1]*100,0), "%)", sep ="")
fs7B_PC2 <- paste("\nPC 2 (", round(fs7B_eigs[2]*100,0), "%)", sep ="")
fs7C_PC1 <- paste("PC 1 (", round(fs7C_eigs[1]*100,0), "%)", sep ="")
fs7C_PC2 <- paste("\nPC 2 (", round(fs7C_eigs[2]*100,0), "%)", sep ="")
fs7D_PC1 <- paste("PC 1 (", round(fs7D_eigs[1]*100,0), "%)", sep ="")
fs7D_PC2 <- paste("\nPC 2 (", round(fs7D_eigs[2]*100,0), "%)", sep ="")

# isolate coordinates for each point
fs7A_coords <- iso.coords(fs7A_pcoa)
fs7B_coords <- iso.coords(fs7B_pcoa)
fs7C_coords <- iso.coords(fs7C_pcoa)
fs7D_coords <- iso.coords(fs7D_pcoa)

# merge in metadata from map
fs7A_df <- merge(x=df.meta.hscr, y=fs7A_coords, by="SampleID", sort=FALSE, all=FALSE)
fs7B_df <- merge(x=df.meta.hscr, y=fs7B_coords, by="SampleID", sort=FALSE, all=FALSE)
fs7C_df <- merge(x=df.meta.hscr, y=fs7C_coords, by="SampleID", sort=FALSE, all=FALSE)
fs7D_df <- merge(x=df.meta.hscr, y=fs7D_coords, by="SampleID", sort=FALSE, all=FALSE)

# add color scheme
fs7A_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83","#762a83","#762a83","#762a83")
fs7B_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
fs7C_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")
fs7D_df$fac.clr <- c("#1b7837","#1b7837","#1b7837",
                     "#762a83","#762a83","#762a83","#762a83")

# add shapes
fs7A_df$fac.shp <- c(16,16,16,17,17,17,17,17,17,17)
fs7B_df$fac.shp <- c(16,16,16,17,17,17,17)
fs7C_df$fac.shp <- c(16,16,16,17,17,17,17)
fs7D_df$fac.shp <- c(16,16,16,17,17,17,17)

# using package rKIN, calculate 95% confidence ellipses
# smallSamp = TRUE allows for less than 10 samples/group to be used
fs7A_ell <- rKIN::estEllipse(fs7A_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs7B_ell <- rKIN::estEllipse(fs7B_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs7C_ell <- rKIN::estEllipse(fs7C_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)
fs7D_ell <- rKIN::estEllipse(fs7D_df, x="X.Coord", y="Y.Coord", group="Facility", levels=c(95), smallSamp=TRUE)

# calculate ellipse overlap
fs7A_olap <- rKIN::calcOverlap(fs7A_ell)
fs7B_olap <- rKIN::calcOverlap(fs7B_ell)
fs7C_olap <- rKIN::calcOverlap(fs7C_ell)
fs7D_olap <- rKIN::calcOverlap(fs7D_ell)

# plot with defaults
fs7A_plot <- pcoa.plot(data=fs7A_ell, xlab=fs7A_PC1, ylab=fs7A_PC2, scaler=0.05, title="A", 
                       subtitle="Weighted UniFrac\nEdnrb P24-WT Colon", alpha=0.16) 
fs7B_plot <- pcoa.plot(data=fs7B_ell, xlab=fs7B_PC1, ylab=fs7B_PC2, scaler=0.05, title="B", 
                       subtitle="Weighted UniFrac\nEdnrb P24-WT Fecal", alpha=0.16)
fs7C_plot <- pcoa.plot(data=fs7C_ell, xlab=fs7C_PC1, ylab=fs7C_PC2, scaler=0.05, title="C", 
                       subtitle="Weighted UniFrac\nEdnrb P24-KO Colon", alpha=0.16)
fs7D_plot <- pcoa.plot(data=fs7D_ell, xlab=fs7D_PC1, ylab=fs7D_PC2, scaler=0.05, title="D", 
                       subtitle="Weighted UniFrac\nEdnrb P24-KO Fecal", alpha=0.16)

# add pcoa.theme, customize ellipse colors, blank points
fs7A_plot <- pcoa.theme(ggplot=fs7A_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs7B_plot <- pcoa.theme(ggplot=fs7B_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs7C_plot <- pcoa.theme(ggplot=fs7C_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

fs7D_plot <- pcoa.theme(ggplot=fs7D_plot, ttl.size=11, sub.ttl.size=7, axs.txt.size=8, font.fam="Helvetica") +
  geom_point(size=3) +
  scale_fill_manual(values=c("#1b7837","#762a83"), guide=FALSE) +
  scale_color_manual(values=c("#1b7837","#762a83")) +
  scale_shape_manual(values=c(32,32)) +
  theme(plot.margin=unit(c(-0.1,0,-0.1,0), "lines"))

# customize points
fs7A_plot.frmt <- fs7A_plot +
  geom_point(inherit.aes=FALSE, data=fs7A_df, x=fs7A_df$X.Coord, y=fs7A_df$Y.Coord,
             shape=fs7A_df$fac.shp, color=fs7A_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs7B_plot.frmt <- fs7B_plot +
  geom_point(inherit.aes=FALSE, data=fs7B_df, x=fs7B_df$X.Coord, y=fs7B_df$Y.Coord,
             shape=fs7B_df$fac.shp, color=fs7B_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs7C_plot.frmt <- fs7C_plot +
  geom_point(inherit.aes=FALSE, data=fs7C_df, x=fs7C_df$X.Coord, y=fs7C_df$Y.Coord,
             shape=fs7C_df$fac.shp, color=fs7C_df$fac.clr, alpha=1, size=1.5, stroke=0)

fs7D_plot.frmt <- fs7D_plot +
  geom_point(inherit.aes=FALSE, data=fs7D_df, x=fs7D_df$X.Coord, y=fs7D_df$Y.Coord,
             shape=fs7D_df$fac.shp, color=fs7D_df$fac.clr, alpha=1, size=1.5, stroke=0)

# add in overlap percentage labels for fs7A
# create vectors with percentage values, round them, multiply them
vec1.olap <- round(fs7A_olap[1,3], digits=2)*100
vec2.olap <- round(fs7A_olap[2,2], digits=2)*100

# create the labels
lab1.olap <- paste("Bos/Lar overlap = ", vec1.olap, "%", sep ="")
lab2.olap <- paste("Lar/Bos overlap =   ", vec2.olap, "%", sep ="")

# create vectors with x and y coordinates for labels and shading
x.lab.olap <- 0.445
y.lab.olap <- c(-0.415, -0.455)

# create a data.frame using the vectors above
olap.labs <- data.frame("label"=c(lab1.olap, lab2.olap), "x.lab"=x.lab.olap, 
                        "y.lab"=y.lab.olap, "clr"=c("#252525","#252525"))

# plot fs7A_plot.frmt with overlap percentage labels
fs7A_plot.frmt.olap <- fs7A_plot.frmt +
  geom_text(data=olap.labs, label=olap.labs$label, x=olap.labs$x.lab, y=olap.labs$y.lab, 
            color=olap.labs$clr, size=1.25, family="Helvetica")

# arrange plots into panels
fig_s7 <- gridExtra::grid.arrange(fs7A_plot.frmt.olap, fs7B_plot.frmt, fs7C_plot.frmt, fs7D_plot.frmt, lgnd, 
                                  ncol=3, nrow=2, layout_matrix=rbind(c(1,1,2,2,5), c(3,3,4,4,5)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_s7/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_s7.tiff", plot=fig_s7, dpi=600, width=110, height=110, units="mm", device="tiff", type="cairo", compression="lzw")

# save workspace
setwd("~/Desktop/r_analysis/")
save.image(file="R_Code_1_WS.Rdata")
