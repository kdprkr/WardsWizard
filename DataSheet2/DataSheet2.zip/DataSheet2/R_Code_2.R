# packages required for this file to 'Source'
# "dplyr"
# "ggplot2"
# "grid"
# "gridExtra"
# NOTE: most package functions are called using the :: syntax (i.e. dplyr::filter())

# load package
require(ggplot2)

########################################################
################ INTERNAL FUNCTIONS ####################
########################################################

# define several functions to make figure construction "smoother"

# read in a metadata mapping file
read.map <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# read in a taxa table output from QIIME1: summarize_taxa.py
read.taxa <- function(file=""){
  file <- read.delim(file, header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)
  return(file)
}

# define a function to truncate the column names of a taxonomy table to the Phylum level
trnc.phy <- function(colName){
  newname <- "SampleID"
  for(i in 2:length(colName)){
    p <- strsplit(colName[i], ".p__")[[1]][2]
    # save phylum name
    newname <- c(newname, paste("", strsplit(p, "\\.")[[1]][1], sep=""))
  }
  return(newname)
}

# define a function which converts all numeric values in a data.frame into a percentage
calc.prcnt <- function(data=data.frame){
  df1 <- data
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df1, mode) == 'numeric'
  # convert all numeric values to a percentage
  df1[num.cols] <- df1[num.cols]*100
  return(df1)
}

# define a function to obtain column numbers with any row possessing greater than X% abundance
# NOTE: this excludes the first column, which in this case is 'SampleID'
get.cols.ra <- function(data=data.frame, threshold){
  goodCol <- as.integer()
  for(i in 2:ncol(data)){
    col <- which(data[,i] > threshold)
    if(length(col)>0) goodCol <- c(goodCol, i)
  }
  return(goodCol)
}

# ggplot for stacked phylum bars
# NOTE: this function is slightly different than the phy.plot function used in Figure 4D,
# specifically it has added x.brks and x.labs 
phy.plot <- function(data, col.x, col.y, col.fll, title="", subtitle="", x.axis.lab="", y.axis.lab="", fll.lab="", vals.fll, y.lims, x.brks, x.labs){
  phyplot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], fill=names(data)[col.fll]) +
    geom_bar(stat="identity") + 
    ggplot2::labs(title=title, subtitle=subtitle, x=x.axis.lab, y=y.axis.lab, fill=fll.lab) +
    scale_fill_manual(values=vals.fll) +
    scale_y_continuous(limits=y.lims, expand=c(0,0)) +
    scale_x_continuous(breaks=x.brks, labels=x.labs, expand=c(0,0.1))
  return(phyplot)
}

# add custom stacked phylum bar plot theme
# NOTE: this function is slightly different than the phy.theme function used in Figure 4D,
# specifically it has different title and subtitle formatting
phy.theme <- function(ggplot, ttl.size, sub.ttl.size, axs.ttl.size, axs.txt.size, font.fam){
  phytheme <- ggplot +
    # global theme
    theme_bw() +
    # remove facet labels at the top
    theme(strip.text.x = element_blank()) +
    # blank the plot background/grids, bold the border
    theme(panel.grid.major=element_blank(),
          panel.grid.minor=element_blank(),
          panel.border=element_rect(fill=NA, size=1.1, color="black")) +
    # title and subtitle parameters
    theme(plot.title=element_text(hjust=-0.105, size=ttl.size, margin=margin(t=0,b=-4)),
          plot.subtitle=element_text(hjust=0.5, size=sub.ttl.size, margin=margin(t=0,b=4))) +
    # axis parameters
    theme(axis.title=element_text(size=axs.ttl.size, face="bold"),
          axis.text=element_text(size=axs.txt.size)) +
    # remove the legend
    theme(legend.position="none") +
    # global font family for the plot
    theme(text=element_text(family=font.fam))
  return(phytheme)
}

# ggplot for custom legend using shapes
lgnd.plot <- function(data, col.x, col.y, col.clr, col.shp, col.fll, alpha, labs.ttl, lbls, vals.fll, vals.clr, vals.shp){
  lgnd.plot <- ggplot(data=data) +
    ggplot2::aes_string(x=names(data)[col.x], y=names(data)[col.y], color=names(data)[col.clr],
                        shape=names(data)[col.shp], fill=names(data)[col.fll]) +
    geom_point(stroke=0, size=4, alpha=alpha) +
    scale_fill_manual(values=vals.fll, labels=lbls) +
    scale_color_manual(values=vals.clr, labels=lbls) +
    scale_shape_manual(values=vals.shp, labels=lbls)
  return(lgnd.plot)
}

# ggplot theme for custom vertical legend using shapes
lgnd.theme <- function(ggplot, txt.size, lgnd.shp.size, font.fam){
  cstm.lgnd.theme <- ggplot +
    # global theme
    theme_bw() +
    # fill the plot with a white rectangle, blank the grid and the border
    theme(plot.background=element_rect(fill="white"),
          panel.ontop=TRUE,
          panel.border=element_blank(),
          panel.grid=element_blank()) +
    # axis parameters - blank all
    theme(axis.ticks=element_blank(),
          axis.title=element_blank(),
          axis.text=element_blank()) +
    # vertical legend parameters
    theme(legend.position=c(0.5,0.5),
          legend.direction="vertical",
          legend.title=element_blank(),
          legend.text=element_text(size=txt.size, lineheight=0.001)) +
    guides(color=guide_legend(label=TRUE, override.aes=list(size=lgnd.shp.size))) +
    theme(text=element_text(family=font.fam))
  return(cstm.lgnd.theme)
}

########################################################
################ Read in "global" files ################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/")

# metadata mapping file
df.meta <- read.map(file="hscr_R_meta.txt")

##########################################
################ FIGURE 3 ################
##########################################

# set working directory
setwd("~/Desktop/r_analysis/fig_3/")

# read in the output from QIIME 1: summarize_taxa.py
f3_phy <- read.taxa(file="HSCR_phylum.txt")

# remove unwanted columns
# print names
# create a data.frame of unwanted columns
# create a vector from the unwanted column names
# remove columns from the data.frame
names(f3_phy)
cols <- f3_phy[,2:25]
cols <- names(cols)
rm_cols <- which(names(f3_phy) %in% cols)
f3_phy <- f3_phy[, - c(rm_cols)]

# change column 2 name from: "Unassigned.Other" to "k__Unassigned.p__Unassigned"
# change column 3 name from: "k__Bacteria.Other" to "k__Bacteria.p__Other1"
# change column 29 name from: "k__Bacteria.p__WPS2" to "k__Bacteria.p__WPS2"
# change column 29 name from: "k__Bacteria.p__.Thermi." to "k__Bacteria.p__Thermi"
# check name, change, check the change
# NOTE: without changes, these columns will cause a foramtting error in the functions below
names(f3_phy)[2]
names(f3_phy)[2] <- "k__Unassigned.p__Unassigned"
names(f3_phy)[2]
names(f3_phy)[3]
names(f3_phy)[3] <- "k__Bacteria.p__Other1"
names(f3_phy)[3]
names(f3_phy)[28]
names(f3_phy)[28] <- "k__Bacteria.p__WPS2"
names(f3_phy)[28]
names(f3_phy)[29]
names(f3_phy)[29] <- "k__Bacteria.p__Thermi"
names(f3_phy)[29]

# tuncate column names
names(f3_phy) <- trnc.phy(names(f3_phy))

# convert decimals to percentages
f3_phy <- calc.prcnt(f3_phy)

# search the data.frame for columns with relative abundance above X%
# and create a vector of columns names
f3_high_cols <- get.cols.ra(data=f3_phy, threshold=5.99)

# create a new data.frame with high relative abundance phyla
f3_df_abv <- f3_phy[,c(1:1, f3_high_cols)]

# create a new data.frame with low relative abundance phyla
f3_df_blw <- f3_phy[,-c(0:0, f3_high_cols)]

# sum phyla in df_blw, add them to Other (exclude SampleID and Unassigned)
f3_df_blw$Other <- rowSums(f3_df_blw[,-c(1,2)])

# retain only columns SampleID, Unassigned, Other
f3_df_blw <- f3_df_blw[,c("SampleID","Unassigned", "Other")]

# merge df_abv and df_blo by SampleID
f3_df_all <- merge(f3_df_abv, f3_df_blw, by="SampleID", all.x = TRUE, sort = FALSE)

# merge in metadata from map
f3_df_all <- merge(f3_df_all, df.meta, by="SampleID", all.x=TRUE, sort=FALSE)

# using package dplyr summarize and group each Phylum by GroupFacilityType
# first print the column names
# add phylum name to new column: 'Phylum'
names(f3_df_all)
Act <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                 Mean=mean(Actinobacteria))
Act$Phylum <- "Actinobacteria"

Bact <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                  Mean=mean(Bacteroidetes))
Bact$Phylum <- "Bacteroidetes"

Cyan <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                  Mean=mean(Cyanobacteria))
Cyan$Phylum <- "Cyanobacteria"

Firm <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                  Mean=mean(Firmicutes))
Firm$Phylum <- "Firmicutes"

Prot <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                  Mean=mean(Proteobacteria))
Prot$Phylum <- "Proteobacteria"

TM7 <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                 Mean=mean(TM7))
TM7$Phylum <- "TM7"

Verr <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type),
                  Mean=mean(Verrucomicrobia))
Verr$Phylum <- "Verrucomicrobia"

Una <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type), 
                        Mean=mean(Unassigned))
Una$Phylum <- "Unassigned"

Oth <- dplyr::summarise(dplyr::group_by(f3_df_all, GroupFacilityType, GroupFacility, Geno, Age, Facility, Type), 
                        Mean=mean(Other))
Oth$Phylum <- "Other"

# we want to filter any of the mean relative abundances that are below 6%
# if any two values in column 'Mean' (column 7) are above 5.99...
# ... then we want to keep the entire Phylum
# So, if the test dataframe has any observations, we retain the Phylum
# if the test dataframe has 0 obs, we need to add this Phylum to 'Other'
test_Act <- Act[which(Act[,7]> 5.99),] # 3 obs.
test_Bact <- Bact[which(Bact[,7]> 5.99),] # 19 obs.
test_Cyan <- Cyan[which(Cyan[,7]> 5.99),] # 0 obs.
test_Firm <- Firm[which(Firm[,7]> 5.99),] # 24 obs.
test_Prot <- Prot[which(Prot[,7]> 5.99),] # 9 obs.
test_TM7 <- TM7[which(TM7[,7]> 5.99),] # 0 obs.
test_Verr <- Verr[which(Verr[,7]> 5.99),] # 0 obs.

# add Cyan, TM7, Verr have to the mean in column Oth
Oth$Mean <- Oth$Mean + Cyan$Mean + TM7$Mean + Verr$Mean

# combine the data.frames
f3_df_phy <- rbind(Act,Bact,Firm,Prot,Una,Oth)

# split f3_df_phy into colon and fecal samples
# paste to create to new data.frames
splt.type <- split.data.frame(x=f3_df_phy, f=f3_df_phy$Type)
f3_c_phy <- splt.type$colon
f3_f_phy <- splt.type$fecal

# split f3_c_phy and f3_f_phy by genotype
# add in the scale numbers for plotting
# colon
splt.geno <- split.data.frame(x=f3_c_phy,f=f3_c_phy$Geno)
f3A_phy <- splt.geno$WT
f3A_phy$scale <- c(1,2,3,4,5,6)
f3B_phy <- splt.geno$KO
f3B_phy$scale <- c(1,2,3,4,5,6)

# fecal
splt.geno <- split.data.frame(x=f3_f_phy,f=f3_f_phy$Geno)
f3C_phy <- splt.geno$WT
f3C_phy$scale <- c(1,2,3,4,5,6)
f3D_phy <- splt.geno$KO
f3D_phy$scale <- c(1,2,3,4,5,6)

# define the locations of each phylum within each stack
# aka where the bars of each phylum stack in each column
lvls <- c("Unassigned","Other","Actinobacteria","Proteobacteria","Bacteroidetes","Firmicutes")
f3A_phy$Phylum <- factor(f3A_phy$Phylum, levels=lvls)
f3B_phy$Phylum <- factor(f3B_phy$Phylum, levels=lvls)
f3C_phy$Phylum <- factor(f3C_phy$Phylum, levels=lvls)
f3D_phy$Phylum <- factor(f3D_phy$Phylum, levels=lvls)

# define the colors for each phylum
# 102372 is TARDIS blue for the eleventh doctor, kudos if that's releveant to you
# grayscale
#PhyCols <- c("#43a2ca","#102372","#d9d9d9","#969696","#636363","#252525")
# blue scheme
PhyCols <- c("#fdb863","#e66101","#bae4bc","#7bccc4","#43a2ca","#102372")

# define facility labels found below each column
# combine them into one data frame
t1 <- data.frame(xpos=1, ypos=-2.25, label="Boston", clr="#1b7837", shp=16,
                 Age=factor("P07", levels=c("P07","P20","P24")))
t2 <- data.frame(xpos=2, ypos=-2.5, label="Laramie", clr="#762a83", shp=17,
                 Age=factor("P07", levels=c("P07","P20","P24")))
t3 <- data.frame(xpos=3, ypos=-2.25, label="Boston", clr="#1b7837", shp=16,
                 Age=factor("P20", levels=c("P07","P20","P24")))
t4 <- data.frame(xpos=4, ypos=-2.5, label="Laramie", clr="#762a83", shp=17,
                 Age=factor("P20", levels=c("P07","P20","P24")))
t5 <- data.frame(xpos=5, ypos=-2.25, label="Boston", clr="#1b7837", shp=16,
                 Age=factor("P24", levels=c("P07","P20","P24")))
t6 <- data.frame(xpos=6, ypos=-2.5, label="Laramie", clr="#762a83", shp=17,
                 Age=factor("P24", levels=c("P07","P20","P24")))
txt <- rbind(t1,t2,t3,t4,t5,t6)

# ggplot with shapes for facility and facet by Age
# col.x = scale, col.y = Mean, col.fll = Phylum
f3A_plot <- phy.plot(data=f3A_phy, col.x=9, col.y=7, col.fll=8,
                     title="A", subtitle="Ednrb WT Colon", x.axis.lab="Age",
                     y.axis.lab="Mean Relative Abundance (%)", 
                     fll.lab="Phylum\n", vals.fll=PhyCols, y.lims=c(-5.85,101), 
                     x.brks=c(1.5,3.5,5.5), x.labs=c("P07","P20","P24")) +
  geom_point(data=txt, color=txt$clr, shape=txt$shp, x=txt$xpos, y=txt$ypos,
             stroke=0, size=2, inherit.aes=FALSE) +
  facet_grid(. ~ Age, scales="free_x", space="free_x")

f3B_plot <- phy.plot(data=f3B_phy, col.x=9, col.y=7, col.fll=8,
                     title="B", subtitle="Ednrb KO Colon", x.axis.lab="Age",
                     y.axis.lab="Mean Relative Abundance (%)", 
                     fll.lab="Phylum\n", vals.fll=PhyCols, y.lims=c(-5.85,101), 
                     x.brks=c(1.5,3.5,5.5), x.labs=c("P07","P20","P24")) +
  geom_point(data=txt, color=txt$clr, shape=txt$shp, x=txt$xpos, y=txt$ypos,
             stroke=0, size=2, inherit.aes=FALSE) +
  facet_grid(. ~ Age, scales="free_x", space="free_x")

f3C_plot <- phy.plot(data=f3C_phy, col.x=9, col.y=7, col.fll=8,
                     title="C", subtitle="Ednrb WT Fecal", x.axis.lab="Age",
                     y.axis.lab="Mean Relative Abundance (%)", 
                     fll.lab="Phylum\n", vals.fll=PhyCols, y.lims=c(-5.85,101), 
                     x.brks=c(1.5,3.5,5.5), x.labs=c("P07","P20","P24")) +
  geom_point(data=txt, color=txt$clr, shape=txt$shp, x=txt$xpos, y=txt$ypos,
             stroke=0, size=2, inherit.aes=FALSE) +
  facet_grid(. ~ Age, scales="free_x", space="free_x")

f3D_plot <- phy.plot(data=f3D_phy, col.x=9, col.y=7, col.fll=8,
                     title="D", subtitle="Ednrb KO Fecal", x.axis.lab="Age",
                     y.axis.lab="Mean Relative Abundance (%)", 
                     fll.lab="Phylum\n", vals.fll=PhyCols, y.lims=c(-5.85,101), 
                     x.brks=c(1.5,3.5,5.5), x.labs=c("P07","P20","P24")) +
  geom_point(data=txt, color=txt$clr, shape=txt$shp, x=txt$xpos, y=txt$ypos,
             stroke=0, size=2, inherit.aes=FALSE) +
  facet_grid(. ~ Age, scales="free_x", space="free_x")

# add custom theme
f3A_plot.frmt <- phy.theme(ggplot=f3A_plot, ttl.size=13, sub.ttl.size=9,
                      axs.ttl.size=9, axs.txt.size=7, font.fam="Helvetica")
f3B_plot.frmt <- phy.theme(ggplot=f3B_plot, ttl.size=13, sub.ttl.size=9,
                      axs.ttl.size=9, axs.txt.size=7, font.fam="Helvetica")
f3C_plot.frmt <- phy.theme(ggplot=f3C_plot, ttl.size=13, sub.ttl.size=9,
                      axs.ttl.size=9, axs.txt.size=7, font.fam="Helvetica")
f3D_plot.frmt <- phy.theme(ggplot=f3D_plot, ttl.size=13, sub.ttl.size=9,
                      axs.ttl.size=9, axs.txt.size=7, font.fam="Helvetica")

# create custom legends (one for facility shapes, one for phylum colors)
# facility shapes/colors
# create vector in order to create data.frame
vec.fac.x <- c(1,2)
vec.fac.y <- 1
vec.fac.lbl <- c("Boston","Laramie")
df_lgnd.fac <- data.frame("x"=vec.fac.x, "y"=vec.fac.y, "fax"=vec.fac.lbl)

# define the legend title and labels
lbls.fac <- c("Boston           ","Laramie           ")

# define shapes and colors
# contrast color scheme
fac.shp <- c(16,17)
fac.fll <- c("#1b7837","#762a83")

# ggplot
lgnd.fac <- lgnd.plot(data=df_lgnd.fac, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                  alpha=1, lbls=lbls.fac, vals.fll=fac.fll, vals.clr=fac.fll, vals.shp=fac.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd.fac <- lgnd.theme(ggplot=lgnd.fac, txt.size=9, lgnd.shp.size=3, font.fam="Helvetica")

# phylum colors
# create vector in order to create data.frame
vec.phy.x <- c(1:6)
vec.phy.y <- 1
vec.phy.lbl <- c("Unassigned","Other","Actinobacteria","Proteobacteria","Bacteroidetes","Firmicutes")
df_lgnd.phy <- data.frame("x"=vec.phy.x, "y"=vec.phy.y, "fax"=vec.phy.lbl)

# define the legend labels
lbls.phy <- c("Unassigned  ","Other  ","Actinobacteria  ","Proteobacteria  ","Bacteroidetes  ","Firmicutes  ")

# define shapes and colors
# contrast color scheme
phy.shp <- c(15,15,15,15,15,15)
phy.fll <- c("#fdb863","#e66101","#bae4bc","#7bccc4","#43a2ca","#102372")

# ggplot
lgnd.phy <- lgnd.plot(data=df_lgnd.phy, col.x=1, col.y=2, col.clr=3, col.shp=3, col.fll=3, 
                      alpha=1, lbls=lbls.phy, vals.fll=phy.fll, vals.clr=phy.fll, vals.shp=phy.shp)

# ggplot theme for custom horizontal legend using shapes
lgnd.phy <- lgnd.theme(ggplot=lgnd.phy, txt.size=9, lgnd.shp.size=4.5, font.fam="Helvetica")

# grid arrange
# add letters denoting each panel (A,B,C,D)
fig_3 <- gridExtra::grid.arrange((f3A_plot.frmt + theme(axis.title=element_blank())), 
                                 (f3B_plot.frmt + theme(axis.title=element_blank())), 
                                 lgnd.phy,
                                 (f3C_plot.frmt + theme(axis.title=element_blank())), 
                                 (f3D_plot.frmt + theme(axis.title=element_blank())), 
                                 lgnd.fac,
                                 ncol=3, nrow=2, widths=c(6,6,2.5),
                                 left=grid::textGrob("Relative Abundance(%)\n", rot=90, vjust=1,
                                                     gp=grid::gpar(fontface="bold", fontfamily="Helvetica", fontsize=9)),
                                 bottom=grid::textGrob("Age", vjust=0.4, hjust=2.5,
                                                       gp=grid::gpar(fontface="bold", fontfamily="Helvetica", fontsize=9)))

# set the working directory
setwd("~/Desktop/r_analysis/fig_3/")

# save high resolution tiff (NOTE: type="cairo" is required for proper compression)
# and cairo will require you to have XQuartz installed
ggsave("fig_3.tiff", plot=fig_3, dpi=600, width=180, height=150, units="mm", device="tiff", type="cairo", compression="lzw")

# save workspace
setwd("~/Desktop/r_analysis/")
save.image(file="R_Code_2_WS.Rdata")
