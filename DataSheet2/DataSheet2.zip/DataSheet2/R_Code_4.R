# packages required for this file to 'Source'
# "dplyr"
# "PMCMR"
# "reshape2"
# "vegan"
# NOTE: package functions are called using the :: syntax (i.e. dplyr::filter())

########################################################
################ INTERNAL FUNCTIONS ####################
########################################################

# define several functions to make table construction "smoother"

# read in a metadata mapping file
read.map <- function(file=""){
  file <- read.table(file, header=TRUE, sep="\t", as.is=TRUE)
  return(file)
}

# read in a distance matrix output from QIIME1: beta_diversity.py
read.dm <- function(file=""){
  file <- as.dist(read.table(file, header=TRUE, sep="\t", as.is=TRUE, row.name=1))
  return(file)
}

# read in a taxa table output from QIIME1: summarize_taxa.py
read.taxa <- function(file=""){
  file <- read.delim(file, header=TRUE, sep="\t", as.is=TRUE, stringsAsFactors=FALSE)
  return(file)
}

# for Tables 1 and S7
# input = results from differential abundance testing using QIIME 1: group_significance.py
# NOTE: this is a very specific function
GetSigsOTUs <- function(data=data.frame){
  # specifiy the order of columns, and drop unneeded columns in the process
  df1 <- data[,c(1,3,6:8)]
  df2 <- df1
  # split the columns (3 and 4) with Age-Genotype (i.e. column 3 name is: P24.WT_mean)
  # place them into vectors, age becomes new column 'Age'
  # col3 becomes new column 3 name, col4 becomes new column 4 name
  age <- strsplit(names(df2)[3],"\\.")[[1]][1]
  df2$Age <- age
  col3 <- strsplit(names(df2)[3],"\\.")[[1]][2]
  names(df2)[3] <- col3
  col4 <- strsplit(names(df2)[4],"\\.")[[1]][2]
  names(df2)[4] <- col4
  df3 <- df2
  # filter column P, based upon significance
  df3 <- dplyr::filter(df3, P < 0.05)
  # if no P-values are < 0.05, paste 1 into each row
  # this allows the function to proceed
  if(nrow(df3) == 0){df3[1,] <- 1}
  df4 <- df3
  # reorder columns to ensure that KO_mean is column 3, and WT_mean is column 4
  coltest <- as.numeric(which(colnames(df4) == "KO_mean"))
  if(coltest==4){df4 <- df4[,c(1:2,4,3,5:6)]}
  df5 <- df4
  # calculate log2 Fold Change (KO to WT)
  df5$log2FC <- (log2(df5[3]) - log2(df5[4]))
  df6 <- df5
  # replace any Inf and -Inf values with 10 and -10 respectively
  df6[,7][df6[,7] == "Inf"] <- "10"
  df6[,7][df6[,7] == "-Inf"] <- "-10"
  return(df6)
}

# for Tables 1 and S7
# input = results from differential abundance testing using QIIME 1: group_significance.py
# NOTE: this is a very specific function
GetSigsTaxa <- function(data=data.frame){
  # specifiy the order of columns, and drop unneeded columns in the process
  # and change column name 'OTU' to 'Taxon'
  df1 <- data[,c(1,3,6:7)]
  names(df1)[1] <- "Taxon"
  df2 <- df1
  # split the columns (3 and 4) with Age-Genotype (i.e. column 3 name is: P24.WT_mean)
  # place them into vectors, age becomes new column 'Age'
  # col3 becomes new column 3 name, col4 becomes new column 4 name
  age <- strsplit(names(df2)[3],"\\.")[[1]][1]
  df2$Age <- age
  col3 <- strsplit(names(df2)[3],"\\.")[[1]][2]
  names(df2)[3] <- col3
  col4 <- strsplit(names(df2)[4],"\\.")[[1]][2]
  names(df2)[4] <- col4
  df3 <- df2
  # filter column P, based upon significance
  df3 <- dplyr::filter(df3, P < 0.05)
  # if no P-values are < 0.05, paste 1 into each row
  # this allows the function to proceed
  if(nrow(df3) == 0){df3[1,] <- 1}
  df4 <- df3
  # reorder columns to ensure that KO_mean is column 3, and WT_mean is column 4
  coltest <- as.numeric(which(colnames(df4) == "KO_mean"))
  if(coltest==4){df4 <- df4[,c(1:2,4,3,5)]}
  df5 <- df4
  # calculate log2 Fold Change (KO to WT)
  df5$log2FC <- (log2(df5[3]) - log2(df5[4]))
  df6 <- df5
  # replace any Inf and -Inf values with 10 and -10 respectively
  df6[,6][df6[,6] == "Inf"] <- "10"
  df6[,6][df6[,6] == "-Inf"] <- "-10"
  return(df6)
}

# for Tables S1 and S5
# define a function to return a filtered distance matrix and a filtered metadata mapping file in list form
# NOTE: this function is required for pwise.adon to run properly
flt.dm.and.meta <- function(meta, dist.obj, flt.col.intrst, flt.row.val, match.col){
  # create a vector of row.numbers in the metadata column of interest that match the row value of interest
  vec.row.nums <- which(meta[,flt.col.intrst] %in% flt.row.val)
  # create a new metadata data.frame with only the rows of interest
  new.meta <- meta[vec.row.nums,]
  # coerce distance matrix from class: 'dist' to class: 'matrix'
  dm <- as.matrix(dist.obj)
  # create a vector of row numbers in the distance matrix that match the specified column in the metadata.file
  dm.vec.nums <- which(row.names(dm) %in% new.meta[,match.col])
  # filter the distance matrix to retain only those numbers
  # NOTE: since we are in matrix land, the row numbers and column numbers will be identical, and we can take advantage of that
  new.dm <- dm[dm.vec.nums,dm.vec.nums]
  # match the order of the rows in new.meta with new.dm
  new.meta <- new.meta[match(x=row.names(new.dm), table=new.meta[,match.col]),]
  # convert new.dm back into class 'dist'
  new.dist <- as.dist(new.dm)
  # create a list containing new.meta and new.dist
  flt.list <- list(df=new.meta, dm=new.dist)
  return(flt.list)
}

# for Tables S1 and S5
# NOTE: this function requires the function: 'flt.dm.and.meta' to run properly
# define a function to make pairwise comparisons using PERMANOVA (adonis)
# returns a data.frame with: Comparison, F.Model, R2, unadjusted p's (p.val), adjusted p's (p.adj)
pwise.adon <- function(meta, flt.col.intrst, dist.obj, match.col, comp.formula, n.perms, p.adj.method, digits){
  # create a vector of row values in the metadata column of interest
  meta.col <- meta[,flt.col.intrst]
  # create unique factors for row values in metadata column of interest
  factors <- as.factor(unique(meta.col))
  # obtain all pairwise (2) comparisons of row values within metadata column of interest
  comps <- combn(x=unique(meta.col), m=2)
  # create empty vectors to store values obtained in the for loop below
  pairs.lbls <- c()
  F.Model <- c()
  R2 <- c()
  p.val <- c()
  # loop through the data to make adonis comparisons for each pair in comps
  for(i in 1:ncol(comps)){
    # create a vector for an individual pair
    pair <- as.vector(factors[factors %in% c(comps[1,i],comps[2,i])])
    # filter the metadata data.frame and the distance matrix for the individual pair
    flt.list <- flt.dm.and.meta(meta=meta, dist.obj=dist.obj, flt.col.intrst=flt.col.intrst, flt.row.val=pair, match.col=match.col)
    # create new metadata data.frame reflecting the filtering step above
    flt.meta <- flt.list$df
    # create new distance matrix reflecting the filtering step above
    flt.dm <- flt.list$dm
    # perform adonis on the filtered data
    adon <- vegan::adonis(formula=comp.formula, data=flt.meta, permutations=n.perms)
    # define labels for the individual pair
    pairs.lbls <- c(pairs.lbls, paste(pair[1],'vs',pair[2]))
    # store information from the adonis data.frame
    # unneeded: F.Model <- c(F.Model, adon$aov.tab[1,4])
    R2 <- c(R2, adon$aov.tab[1,5])
    p.val <- c(p.val, adon$aov.tab[1,6])
  }
  # adjust p.vals for multiple comparisons
  # NOTE: number of comparisons (n) is determined by length(p), but make sure this number is correct!!!!
  p.adj <- p.adjust(p=p.val, method=p.adj.method, n=length(p.val))
  # create new data.frame containing the relvant information
  # if keeping F.Model statistic: df.pwise <- data.frame("Comparison"=pairs.lbls, F.Model, R2, p.val, p.adj)
  df.pwise <- data.frame("Comparison"=pairs.lbls, R2, p.val, p.adj)
  # round all numeric values to specified number of decimal places
  df.pwise.rnd <- dplyr::mutate_if(df.pwise, is.numeric, dplyr::funs(round(., digits)))
  return(df.pwise.rnd)
}

# for Tables S3, S4, S6
# define a function to perform pairwise Kruskal-Wallis with Dunn's post hoc and an FDR correction
kw.plus.dunn.post <- function(data=data.frame, col.intrst){
  # create empty vectors to store values obtained in the for loop below
  rawDunn <- data.frame()
  meltDunn <- data.frame()
  # loop through the data to make comparisons for each pair in the columns of the data.frame
  for(i in 3:(ncol(data))){
    # perform Dunn's post hoc with fdr correction
    kwd <- PMCMR::posthoc.kruskal.dunn.test(data[,i] ~ data[,col.intrst], p.adjust.method="fdr")
    kdf <- data.frame(kwd$p.value)
    kdf <- data.frame(Metric=rep(names(data)[i], nrow(kdf)), Class=row.names(kdf), kdf)
    rawDunn <- rbind(rawDunn, kdf)
    # melt rawDunn into workable data.frame
    meltDunn <- reshape2::melt(rawDunn, id.vars=c("Metric","Class"), variable.name="PairClass", value.name="p.adj")
    # convert column 'Metric' to character
    meltDunn$Metric <- as.character(meltDunn$Metric)
    # rename columns 'Class' and 'PairClass'
    names(meltDunn)[2] <- as.character("Pair1")
    names(meltDunn)[3] <- as.character("Pair2")
  }
  return(meltDunn)
}

# for Tables S3, S4, S6
# define a function to perform pairwise Wilcoxon with an FDR correction
pwise.wilc <- function(data=data.frame, col.intrst){
  # create empty vectors to store values obtained in the for loop below
  rawWilc<- data.frame()
  meltWilc<- data.frame()
  # loop through the data to make comparisons for each pair in the columns of the data.frame
  for(i in 3:(ncol(data))){
    # perform pairwise Wilcoxon with fdr correction
    wilc <- pairwise.wilcox.test(data[,i], data[,col.intrst], p.adjust.method="fdr", paired=FALSE, exact=FALSE)
    wdf <- data.frame(wilc$p.value)
    wdf <- data.frame(Metric=rep(names(data)[i], nrow(wdf)), Class=row.names(wdf), wdf)
    rawWilc <- rbind(rawWilc, wdf)
    # melt rawWilc into workable data.frame
    meltWilc <- reshape2::melt(rawWilc, id.vars=c("Metric","Class"), variable.name="PairClass", value.name="p.adj")
    # convert column 'Metric' to character
    meltWilc$Metric <- as.character(meltWilc$Metric)
    # rename columns 'Class' and 'PairClass'
    names(meltWilc)[2] <- as.character("Pair1")
    names(meltWilc)[3] <- as.character("Pair2")
  }
  return(meltWilc)
}

# for Tables S3, S4, S6
# define a function to filter INTER facility comparisons from the pairwise data.frames
# NOTE: this is a very specific function
flt.inter.fac <- function(data=data.frame){
  # create dfs containing the specific groups of interest
  df1 <- dplyr::filter(data, Pair1 == "P07-WT-Lar" & Pair2 == "P07.WT.Bos")
  df2 <- dplyr::filter(data, Pair1 == "P07-WT-Bos" & Pair2 == "P07.WT.Lar")
  df3 <- dplyr::filter(data, Pair1 == "P20-WT-Lar" & Pair2 == "P20.WT.Bos")
  df4 <- dplyr::filter(data, Pair1 == "P20-WT-Bos" & Pair2 == "P20.WT.Lar")
  df5 <- dplyr::filter(data, Pair1 == "P24-WT-Lar" & Pair2 == "P24.WT.Bos")
  df6 <- dplyr::filter(data, Pair1 == "P24-WT-Bos" & Pair2 == "P24.WT.Lar")
  df11 <- dplyr::filter(data, Pair1 == "P07-KO-Lar" & Pair2 == "P07.KO.Bos")
  df12 <- dplyr::filter(data, Pair1 == "P07-KO-Bos" & Pair2 == "P07.KO.Lar")
  df13 <- dplyr::filter(data, Pair1 == "P20-KO-Lar" & Pair2 == "P20.KO.Bos")
  df14 <- dplyr::filter(data, Pair1 == "P20-KO-Bos" & Pair2 == "P20.KO.Lar")
  df15 <- dplyr::filter(data, Pair1 == "P24-KO-Lar" & Pair2 == "P24.KO.Bos")
  df16 <- dplyr::filter(data, Pair1 == "P24-KO-Bos" & Pair2 == "P24.KO.Lar")
  # combine the dfs
  df.flt <- rbind(df1,df2,df3,df4,df5,df6,df11,df12,df13,df14,df15,df16)
  # retain only rows with no NA values
  new.df <- df.flt[complete.cases(df.flt), ]
  # order new.df by rows in column 'Metric'
  new.df <- new.df[order(new.df$Metric),]
  return(new.df)
}

# for Tables S3, S4, S6
# define a function to filter INTRA facility comparisons from the pairwise data.frames
# NOTE: this is a very specific function
flt.intra.fac <- function(data=data.frame){
  # create dfs containing the specific groups of interest
  df1 <- dplyr::filter(data, Pair1 == "P07-WT" & Pair2 == "P07.KO")
  df2 <- dplyr::filter(data, Pair1 == "P07-KO" & Pair2 == "P07.WT")
  df3 <- dplyr::filter(data, Pair1 == "P20-WT" & Pair2 == "P20.KO")
  df4 <- dplyr::filter(data, Pair1 == "P20-KO" & Pair2 == "P20.WT")
  df5 <- dplyr::filter(data, Pair1 == "P24-WT" & Pair2 == "P24.KO")
  df6 <- dplyr::filter(data, Pair1 == "P24-KO" & Pair2 == "P24.WT")
  # combine the dfs
  df.flt <- rbind(df1,df2,df3,df4,df5,df6)
  # retain only rows with no NA values
  new.df <- df.flt[complete.cases(df.flt), ]
  # order new.df by rows in column 'Metric'
  new.df <- new.df[order(new.df$Metric),]
  return(new.df)
}

# for Tables S4 and S6
# define a function which converts all numeric values in a data.frame into a percentage
calc.prcnt <- function(data=data.frame){
  df1 <- data
  # create a vector with information on which columns have numeric values
  num.cols <- sapply(df1, mode) =='numeric'
  # convert all numeric values to a percentage
  df1[num.cols] <- df1[num.cols]*100
  return(df1)
}

# for Tables S4 and S6
# define a function to obtain column numbers with any row possessing greater than X% abundance
# NOTE: this excludes the first column, which in this case is 'SampleID'
get.cols.ra <- function(data=data.frame, threshold){
  goodCol <- as.integer()
  for(i in 2:ncol(data)){
    col <- which(data[,i] > threshold)
    if(length(col)>0) goodCol <- c(goodCol, i)
  }
  return(goodCol)
}

# for Tables S4 and S6
# define a function to replace characters in rows of a single column
# NOTE: this function works only for two replacements
# it is likely not any more efficient to employ this function...
# ... than to employ the gsub lines on their own, but the function is here
rplace.chars <- function(data=data.frame, col, pat1, rep1, pat2, rep2){
  df <- data
  df[,col] <- gsub(pattern=pat1, replacement=rep1, x=df[,col])
  df[,col] <- gsub(pattern=pat2, replacement=rep2, x=df[,col])
  return(df)
}

# for Tables S4 and S6
# define a function to filter a larger data.frame using information from a smaller data.frame
flt.tax.df <- function(data1=data.frame, data2=data.frame, d2.col1, d2.col2, d2.col3, d1.col, keep.cols){
  # create a vector of column numbers from data1 that match the rows in the specified column of data2
  vec.cols <- which(names(data1) %in% data2[,d2.col1])
  # create a new data.frame for data1 that retains only the columns determined above
  df1 <- dplyr::select(data1, keep.cols, vec.cols)
  # create a vector of row numbers from a column in df1 that match rows from two columns in df2
  vec.rows.1 <- which(df1[,d1.col] %in% data2[,d2.col2] | df1[,d1.col] %in% data2[,d2.col3])
  # create a new data.frame that retains the rows determined above
  new.df <- df1[vec.rows.1,]
}

# for Tables S4 and S6
# define a function to add mean relative abundance information back into a .SIGS data.frame
# NOTE: this function is specific to .mRA and .SIGS dataf.frames
merge.mRA.SIGS <- function(df.mRA=data.frame, df.SIGS=data.frame, mRA.col, merge.col, col.rnme, 
                           SIGS.col1, new.col.name1, SIGS.col2, new.col.name2){
  # create a vector of row numbers from .mRA data.frame that match rows in column of .SIGS data.frame
  vec.rows.p1 <- which(df.mRA[,mRA.col] %in% df.SIGS[,SIGS.col1])
  # create new data.frame from those rows
  new.df.mRA.p1 <- df.mRA[vec.rows.p1,]
  # merge new.df with .SIGS data.frame
  df.p1 <- merge(x=df.SIGS, y=new.df.mRA.p1, by.x=c(merge.col,SIGS.col1), by.y=c(merge.col,mRA.col), sort=FALSE)
  # rename column in df.p1
  vec.new.col.1 <- which(names(df.p1)==col.rnme)
  names(df.p1)[vec.new.col.1] <- new.col.name1
  # perform the above again for the second column
  vec.rows.p2 <- which(df.mRA[,mRA.col] %in% df.SIGS[,SIGS.col2])
  new.df.mRA.p2 <- df.mRA[vec.rows.p2,]
  df.p2 <- merge(x=df.SIGS, y=new.df.mRA.p2, by.x=c(merge.col,SIGS.col2), by.y=c(merge.col,mRA.col), sort=FALSE)
  vec.new.col.2 <- which(names(df.p2)==col.rnme)
  names(df.p2)[vec.new.col.2] <- new.col.name2
  # join df.p1 and df.p2 with dplyr
  new.df.mRA.SIGS <- dplyr::inner_join(x=df.p1,y=df.p2)
  return(new.df.mRA.SIGS)
}

########################################################
################ Read in "global" files ################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/")

# metadata mapping files (needed for alpha diversity, and distance matrix filtering)
df.meta.hscr <- read.map(file="hscr_R_meta.txt")
df.meta.c57 <- read.map(file="c57_R_meta.txt")

#######################################################
################ TABLE 1 and TABLE S7 #################
#######################################################

# set the working directory
setwd("~/Desktop/r_analysis/tab_1_tab_s7")

# read in differential abundance testing results - OTUS
# there will be a lot of files here, don't panic
# Boston - colon
cBos_P07_KW <- read.table(file="otus/cBos_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW <- read.table(file="otus/cBos_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW <- read.table(file="otus/cBos_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT <- read.table(file="otus/cBos_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT <- read.table(file="otus/cBos_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT <- read.table(file="otus/cBos_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_GT <- read.table(file="otus/cBos_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_GT <- read.table(file="otus/cBos_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_GT <- read.table(file="otus/cBos_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - colon
cLar_P07_KW <- read.table(file="otus/cLar_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW <- read.table(file="otus/cLar_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW <- read.table(file="otus/cLar_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT <- read.table(file="otus/cLar_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT <- read.table(file="otus/cLar_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT <- read.table(file="otus/cLar_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_GT <- read.table(file="otus/cLar_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_GT <- read.table(file="otus/cLar_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_GT <- read.table(file="otus/cLar_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Boston - fecal
fBos_P07_KW <- read.table(file="otus/fBos_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW <- read.table(file="otus/fBos_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW <- read.table(file="otus/fBos_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT <- read.table(file="otus/fBos_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT <- read.table(file="otus/fBos_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT <- read.table(file="otus/fBos_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_GT <- read.table(file="otus/fBos_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_GT <- read.table(file="otus/fBos_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_GT <- read.table(file="otus/fBos_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - fecal
fLar_P07_KW <- read.table(file="otus/fLar_P07_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW <- read.table(file="otus/fLar_P20_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW <- read.table(file="otus/fLar_P24_KW.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT <- read.table(file="otus/fLar_P07_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT <- read.table(file="otus/fLar_P20_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT <- read.table(file="otus/fLar_P24_NPT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_GT <- read.table(file="otus/fLar_P07_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_GT <- read.table(file="otus/fLar_P20_GT.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_GT <- read.table(file="otus/fLar_P24_GT.txt", header=TRUE, sep="\t", as.is=TRUE)

# use function GetSigsOTUs to filter each data.frame for 'significant' P-values
# Boston - colon
cBos_P07_KW.sig <- GetSigsOTUs(cBos_P07_KW)
cBos_P20_KW.sig <- GetSigsOTUs(cBos_P20_KW)
cBos_P24_KW.sig <- GetSigsOTUs(cBos_P24_KW)
cBos_P07_NPT.sig <- GetSigsOTUs(cBos_P07_NPT)
cBos_P20_NPT.sig <- GetSigsOTUs(cBos_P20_NPT)
cBos_P24_NPT.sig <- GetSigsOTUs(cBos_P24_NPT)
cBos_P07_GT.sig <- GetSigsOTUs(cBos_P07_GT)
cBos_P20_GT.sig <- GetSigsOTUs(cBos_P20_GT)
cBos_P24_GT.sig <- GetSigsOTUs(cBos_P24_GT)
# Laramie - colon
cLar_P07_KW.sig <- GetSigsOTUs(cLar_P07_KW)
cLar_P20_KW.sig <- GetSigsOTUs(cLar_P20_KW)
cLar_P24_KW.sig <- GetSigsOTUs(cLar_P24_KW)
cLar_P07_NPT.sig <- GetSigsOTUs(cLar_P07_NPT)
cLar_P20_NPT.sig <- GetSigsOTUs(cLar_P20_NPT)
cLar_P24_NPT.sig <- GetSigsOTUs(cLar_P24_NPT)
cLar_P07_GT.sig <- GetSigsOTUs(cLar_P07_GT)
cLar_P20_GT.sig <- GetSigsOTUs(cLar_P20_GT)
cLar_P24_GT.sig <- GetSigsOTUs(cLar_P24_GT)
# Boston - fecal
fBos_P07_KW.sig <- GetSigsOTUs(fBos_P07_KW)
fBos_P20_KW.sig <- GetSigsOTUs(fBos_P20_KW)
fBos_P24_KW.sig <- GetSigsOTUs(fBos_P24_KW)
fBos_P07_NPT.sig <- GetSigsOTUs(fBos_P07_NPT)
fBos_P20_NPT.sig <- GetSigsOTUs(fBos_P20_NPT)
fBos_P24_NPT.sig <- GetSigsOTUs(fBos_P24_NPT)
fBos_P07_GT.sig <- GetSigsOTUs(fBos_P07_GT)
fBos_P20_GT.sig <- GetSigsOTUs(fBos_P20_GT)
fBos_P24_GT.sig <- GetSigsOTUs(fBos_P24_GT)
# Laramie - fecal
fLar_P07_KW.sig <- GetSigsOTUs(fLar_P07_KW)
fLar_P20_KW.sig <- GetSigsOTUs(fLar_P20_KW)
fLar_P24_KW.sig <- GetSigsOTUs(fLar_P24_KW)
fLar_P07_NPT.sig <- GetSigsOTUs(fLar_P07_NPT)
fLar_P20_NPT.sig <- GetSigsOTUs(fLar_P20_NPT)
fLar_P24_NPT.sig <- GetSigsOTUs(fLar_P24_NPT)
fLar_P07_GT.sig <- GetSigsOTUs(fLar_P07_GT)
fLar_P20_GT.sig <- GetSigsOTUs(fLar_P20_GT)
fLar_P24_GT.sig <- GetSigsOTUs(fLar_P24_GT)

# add relevant metadata into appropriate columns
# Boston - colon
cBos_P07_KW.sig$Facility <- "Boston"
cBos_P07_KW.sig$Type <- "colon"
cBos_P07_KW.sig$Test <- "krusk_wall"
cBos_P20_KW.sig$Facility <- "Boston"
cBos_P20_KW.sig$Type <- "colon"
cBos_P20_KW.sig$Test <- "krusk_wall"
cBos_P24_KW.sig$Facility <- "Boston"
cBos_P24_KW.sig$Type <- "colon"
cBos_P24_KW.sig$Test <- "krusk_wall"
cBos_P07_NPT.sig$Facility <- "Boston"
cBos_P07_NPT.sig$Type <- "colon"
cBos_P07_NPT.sig$Test <- "nonparam-T"
cBos_P20_NPT.sig$Facility <- "Boston"
cBos_P20_NPT.sig$Type <- "colon"
cBos_P20_NPT.sig$Test <- "nonparam-T"
cBos_P24_NPT.sig$Facility <- "Boston"
cBos_P24_NPT.sig$Type <- "colon"
cBos_P24_NPT.sig$Test <- "nonparam-T"
cBos_P07_GT.sig$Facility <- "Boston"
cBos_P07_GT.sig$Type <- "colon"
cBos_P07_GT.sig$Test <- "g-test"
cBos_P20_GT.sig$Facility <- "Boston"
cBos_P20_GT.sig$Type <- "colon"
cBos_P20_GT.sig$Test <- "g-test"
cBos_P24_GT.sig$Facility <- "Boston"
cBos_P24_GT.sig$Type <- "colon"
cBos_P24_GT.sig$Test <- "g-test"
# Laramie - colon
cLar_P07_KW.sig$Facility <- "Laramie"
cLar_P07_KW.sig$Type <- "colon"
cLar_P07_KW.sig$Test <- "krusk_wall"
cLar_P20_KW.sig$Facility <- "Laramie"
cLar_P20_KW.sig$Type <- "colon"
cLar_P20_KW.sig$Test <- "krusk_wall"
cLar_P24_KW.sig$Facility <- "Laramie"
cLar_P24_KW.sig$Type <- "colon"
cLar_P24_KW.sig$Test <- "krusk_wall"
cLar_P07_NPT.sig$Facility <- "Laramie"
cLar_P07_NPT.sig$Type <- "colon"
cLar_P07_NPT.sig$Test <- "nonparam-T"
cLar_P20_NPT.sig$Facility <- "Laramie"
cLar_P20_NPT.sig$Type <- "colon"
cLar_P20_NPT.sig$Test <- "nonparam-T"
cLar_P24_NPT.sig$Facility <- "Laramie"
cLar_P24_NPT.sig$Type <- "colon"
cLar_P24_NPT.sig$Test <- "nonparam-T"
cLar_P07_GT.sig$Facility <- "Laramie"
cLar_P07_GT.sig$Type <- "colon"
cLar_P07_GT.sig$Test <- "g-test"
cLar_P20_GT.sig$Facility <- "Laramie"
cLar_P20_GT.sig$Type <- "colon"
cLar_P20_GT.sig$Test <- "g-test"
cLar_P24_GT.sig$Facility <- "Laramie"
cLar_P24_GT.sig$Type <- "colon"
cLar_P24_GT.sig$Test <- "g-test"
# Boston - fecal
fBos_P07_KW.sig$Facility <- "Boston"
fBos_P07_KW.sig$Type <- "fecal"
fBos_P07_KW.sig$Test <- "krusk_wall"
fBos_P20_KW.sig$Facility <- "Boston"
fBos_P20_KW.sig$Type <- "fecal"
fBos_P20_KW.sig$Test <- "krusk_wall"
fBos_P24_KW.sig$Facility <- "Boston"
fBos_P24_KW.sig$Type <- "fecal"
fBos_P24_KW.sig$Test <- "krusk_wall"
fBos_P07_NPT.sig$Facility <- "Boston"
fBos_P07_NPT.sig$Type <- "fecal"
fBos_P07_NPT.sig$Test <- "nonparam-T"
fBos_P20_NPT.sig$Facility <- "Boston"
fBos_P20_NPT.sig$Type <- "fecal"
fBos_P20_NPT.sig$Test <- "nonparam-T"
fBos_P24_NPT.sig$Facility <- "Boston"
fBos_P24_NPT.sig$Type <- "fecal"
fBos_P24_NPT.sig$Test <- "nonparam-T"
fBos_P07_GT.sig$Facility <- "Boston"
fBos_P07_GT.sig$Type <- "fecal"
fBos_P07_GT.sig$Test <- "g-test"
fBos_P20_GT.sig$Facility <- "Boston"
fBos_P20_GT.sig$Type <- "fecal"
fBos_P20_GT.sig$Test <- "g-test"
fBos_P24_GT.sig$Facility <- "Boston"
fBos_P24_GT.sig$Type <- "fecal"
fBos_P24_GT.sig$Test <- "g-test"
# Laramie - fecal
fLar_P07_KW.sig$Facility <- "Laramie"
fLar_P07_KW.sig$Type <- "fecal"
fLar_P07_KW.sig$Test <- "krusk_wall"
fLar_P20_KW.sig$Facility <- "Laramie"
fLar_P20_KW.sig$Type <- "fecal"
fLar_P20_KW.sig$Test <- "krusk_wall"
fLar_P24_KW.sig$Facility <- "Laramie"
fLar_P24_KW.sig$Type <- "fecal"
fLar_P24_KW.sig$Test <- "krusk_wall"
fLar_P07_NPT.sig$Facility <- "Laramie"
fLar_P07_NPT.sig$Type <- "fecal"
fLar_P07_NPT.sig$Test <- "nonparam-T"
fLar_P20_NPT.sig$Facility <- "Laramie"
fLar_P20_NPT.sig$Type <- "fecal"
fLar_P20_NPT.sig$Test <- "nonparam-T"
fLar_P24_NPT.sig$Facility <- "Laramie"
fLar_P24_NPT.sig$Type <- "fecal"
fLar_P24_NPT.sig$Test <- "nonparam-T"
fLar_P07_GT.sig$Facility <- "Laramie"
fLar_P07_GT.sig$Type <- "fecal"
fLar_P07_GT.sig$Test <- "g-test"
fLar_P20_GT.sig$Facility <- "Laramie"
fLar_P20_GT.sig$Type <- "fecal"
fLar_P20_GT.sig$Test <- "g-test"
fLar_P24_GT.sig$Facility <- "Laramie"
fLar_P24_GT.sig$Type <- "fecal"
fLar_P24_GT.sig$Test <- "g-test"

# Merge age- and type- matched dataframes from each Facility
# Then filter the merged df for NA's in two columns,
# This returns a df which retains OTUs that were present in both Facilities
# Finally, rbind the df by column to return our conserved candidates in a legible format

# P07 - colon
cdf07_KW <- merge(cBos_P07_KW.sig,cLar_P07_KW.sig, by="OTU", all=TRUE, sort=FALSE)
cdf07_KW <- cdf07_KW[!is.na(cdf07_KW$P.x) & !is.na(cdf07_KW$P.y),]
cdf07_KW <- rbind(cBos_P07_KW.sig[cBos_P07_KW.sig$OTU %in% cdf07_KW$OTU,], cLar_P07_KW.sig[cLar_P07_KW.sig$OTU %in% cdf07_KW$OTU,])
cdf07_NPT <- merge(cBos_P07_NPT.sig,cLar_P07_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf07_NPT <- cdf07_NPT[!is.na(cdf07_NPT$P.x) & !is.na(cdf07_NPT$P.y),]
cdf07_NPT <- rbind(cBos_P07_NPT.sig[cBos_P07_NPT.sig$OTU %in% cdf07_NPT$OTU,], cLar_P07_NPT.sig[cLar_P07_NPT.sig$OTU %in% cdf07_NPT$OTU,])
cdf07_GT <- merge(cBos_P07_GT.sig,cLar_P07_GT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf07_GT <- cdf07_GT[!is.na(cdf07_GT$P.x) & !is.na(cdf07_GT$P.y),]
cdf07_GT <- rbind(cBos_P07_GT.sig[cBos_P07_GT.sig$OTU %in% cdf07_GT$OTU,], cLar_P07_GT.sig[cLar_P07_GT.sig$OTU %in% cdf07_GT$OTU,])

# P20 - colon
cdf20_KW <- merge(cBos_P20_KW.sig,cLar_P20_KW.sig, by="OTU", all=TRUE, sort=FALSE)
cdf20_KW <- cdf20_KW[!is.na(cdf20_KW$P.x) & !is.na(cdf20_KW$P.y),]
cdf20_KW <- rbind(cBos_P20_KW.sig[cBos_P20_KW.sig$OTU %in% cdf20_KW$OTU,], cLar_P20_KW.sig[cLar_P20_KW.sig$OTU %in% cdf20_KW$OTU,])
cdf20_NPT <- merge(cBos_P20_NPT.sig,cLar_P20_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf20_NPT <- cdf20_NPT[!is.na(cdf20_NPT$P.x) & !is.na(cdf20_NPT$P.y),]
cdf20_NPT <- rbind(cBos_P20_NPT.sig[cBos_P20_NPT.sig$OTU %in% cdf20_NPT$OTU,], cLar_P20_NPT.sig[cLar_P20_NPT.sig$OTU %in% cdf20_NPT$OTU,])
cdf20_GT <- merge(cBos_P20_GT.sig,cLar_P20_GT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf20_GT <- cdf20_GT[!is.na(cdf20_GT$P.x) & !is.na(cdf20_GT$P.y),]
cdf20_GT <- rbind(cBos_P20_GT.sig[cBos_P20_GT.sig$OTU %in% cdf20_GT$OTU,], cLar_P20_GT.sig[cLar_P20_GT.sig$OTU %in% cdf20_GT$OTU,])

# P24 - colon
cdf24_KW <- merge(cBos_P24_KW.sig,cLar_P24_KW.sig, by="OTU", all=TRUE, sort=FALSE)
cdf24_KW <- cdf24_KW[!is.na(cdf24_KW$P.x) & !is.na(cdf24_KW$P.y),]
cdf24_KW <- rbind(cBos_P24_KW.sig[cBos_P24_KW.sig$OTU %in% cdf24_KW$OTU,], cLar_P24_KW.sig[cLar_P24_KW.sig$OTU %in% cdf24_KW$OTU,])
cdf24_NPT <- merge(cBos_P24_NPT.sig,cLar_P24_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf24_NPT <- cdf24_NPT[!is.na(cdf24_NPT$P.x) & !is.na(cdf24_NPT$P.y),]
cdf24_NPT <- rbind(cBos_P24_NPT.sig[cBos_P24_NPT.sig$OTU %in% cdf24_NPT$OTU,], cLar_P24_NPT.sig[cLar_P24_NPT.sig$OTU %in% cdf24_NPT$OTU,])
cdf24_GT <- merge(cBos_P24_GT.sig,cLar_P24_GT.sig, by="OTU", all=TRUE, sort=FALSE)
cdf24_GT <- cdf24_GT[!is.na(cdf24_GT$P.x) & !is.na(cdf24_GT$P.y),]
cdf24_GT <- rbind(cBos_P24_GT.sig[cBos_P24_GT.sig$OTU %in% cdf24_GT$OTU,], cLar_P24_GT.sig[cLar_P24_GT.sig$OTU %in% cdf24_GT$OTU,])

# P07 - fecal
fdf07_KW <- merge(fBos_P07_KW.sig,fLar_P07_KW.sig, by="OTU", all=TRUE, sort=FALSE)
fdf07_KW <- fdf07_KW[!is.na(fdf07_KW$P.x) & !is.na(fdf07_KW$P.y),]
fdf07_KW <- rbind(fBos_P07_KW.sig[fBos_P07_KW.sig$OTU %in% fdf07_KW$OTU,], fLar_P07_KW.sig[fLar_P07_KW.sig$OTU %in% fdf07_KW$OTU,])
fdf07_NPT <- merge(fBos_P07_NPT.sig,fLar_P07_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf07_NPT <- fdf07_NPT[!is.na(fdf07_NPT$P.x) & !is.na(fdf07_NPT$P.y),]
fdf07_NPT <- rbind(fBos_P07_NPT.sig[fBos_P07_NPT.sig$OTU %in% fdf07_NPT$OTU,], fLar_P07_NPT.sig[fLar_P07_NPT.sig$OTU %in% fdf07_NPT$OTU,])
fdf07_GT <- merge(fBos_P07_GT.sig,fLar_P07_GT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf07_GT <- fdf07_GT[!is.na(fdf07_GT$P.x) & !is.na(fdf07_GT$P.y),]
fdf07_GT <- rbind(fBos_P07_GT.sig[fBos_P07_GT.sig$OTU %in% fdf07_GT$OTU,], fLar_P07_GT.sig[fLar_P07_GT.sig$OTU %in% fdf07_GT$OTU,])

# P20 - fecal
fdf20_KW <- merge(fBos_P20_KW.sig,fLar_P20_KW.sig, by="OTU", all=TRUE, sort=FALSE)
fdf20_KW <- fdf20_KW[!is.na(fdf20_KW$P.x) & !is.na(fdf20_KW$P.y),]
fdf20_KW <- rbind(fBos_P20_KW.sig[fBos_P20_KW.sig$OTU %in% fdf20_KW$OTU,], fLar_P20_KW.sig[fLar_P20_KW.sig$OTU %in% fdf20_KW$OTU,])
fdf20_NPT <- merge(fBos_P20_NPT.sig,fLar_P20_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf20_NPT <- fdf20_NPT[!is.na(fdf20_NPT$P.x) & !is.na(fdf20_NPT$P.y),]
fdf20_NPT <- rbind(fBos_P20_NPT.sig[fBos_P20_NPT.sig$OTU %in% fdf20_NPT$OTU,], fLar_P20_NPT.sig[fLar_P20_NPT.sig$OTU %in% fdf20_NPT$OTU,])
fdf20_GT <- merge(fBos_P20_GT.sig,fLar_P20_GT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf20_GT <- fdf20_GT[!is.na(fdf20_GT$P.x) & !is.na(fdf20_GT$P.y),]
fdf20_GT <- rbind(fBos_P20_GT.sig[fBos_P20_GT.sig$OTU %in% fdf20_GT$OTU,], fLar_P20_GT.sig[fLar_P20_GT.sig$OTU %in% fdf20_GT$OTU,])

# P24 - fecal
fdf24_KW <- merge(fBos_P24_KW.sig,fLar_P24_KW.sig, by="OTU", all=TRUE, sort=FALSE)
fdf24_KW <- fdf24_KW[!is.na(fdf24_KW$P.x) & !is.na(fdf24_KW$P.y),]
fdf24_KW <- rbind(fBos_P24_KW.sig[fBos_P24_KW.sig$OTU %in% fdf24_KW$OTU,], fLar_P24_KW.sig[fLar_P24_KW.sig$OTU %in% fdf24_KW$OTU,])
fdf24_NPT <- merge(fBos_P24_NPT.sig,fLar_P24_NPT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf24_NPT <- fdf24_NPT[!is.na(fdf24_NPT$P.x) & !is.na(fdf24_NPT$P.y),]
fdf24_NPT <- rbind(fBos_P24_NPT.sig[fBos_P24_NPT.sig$OTU %in% fdf24_NPT$OTU,], fLar_P24_NPT.sig[fLar_P24_NPT.sig$OTU %in% fdf24_NPT$OTU,])
fdf24_GT <- merge(fBos_P24_GT.sig,fLar_P24_GT.sig, by="OTU", all=TRUE, sort=FALSE)
fdf24_GT <- fdf24_GT[!is.na(fdf24_GT$P.x) & !is.na(fdf24_GT$P.y),]
fdf24_GT <- rbind(fBos_P24_GT.sig[fBos_P24_GT.sig$OTU %in% fdf24_GT$OTU,], fLar_P24_GT.sig[fLar_P24_GT.sig$OTU %in% fdf24_GT$OTU,])

# combine (rbind) each age-test-type data.frame
# sort the columns of each data.frame and then sort rows within columns by Age and OTU
# NOTE: data.frames with 0 obs. will disappear because they have no information to combine
# colon
cdf.otu <- rbind(cdf07_KW,cdf07_NPT,cdf07_GT,cdf20_KW,cdf20_NPT,cdf20_GT,cdf24_KW,cdf24_NPT,cdf24_GT)
cdf.otu <- dplyr::select(cdf.otu, c(Age, Type, Facility, KO_mean, WT_mean, log2FC, OTU, taxonomy, Test, P))
cdf.otu <- cdf.otu[order(cdf.otu$Age, cdf.otu$OTU),]

# fecal
fdf.otu <- rbind(fdf07_KW,fdf07_NPT,fdf07_GT,fdf20_KW,fdf20_NPT,fdf20_GT,fdf24_KW,fdf24_NPT,fdf24_GT)
fdf.otu <- dplyr::select(fdf.otu, c(Age, Type, Facility, KO_mean, WT_mean, log2FC, OTU, taxonomy, Test, P))
fdf.otu <- fdf.otu[order(fdf.otu$Age, fdf.otu$OTU),]

# finally, rbind cdf.otu and fdf.otu, and again sort by Age and OTU
cons_otu <- rbind(cdf.otu,fdf.otu)
cons_otu <- cons_otu[order(cons_otu$Age, cons_otu$OTU),]

# save tables
setwd("~/Desktop/r_analysis/tab_1_tab_s7")
write.table(cdf.otu, file="colon_cons_otu.txt", sep="\t", row.names=FALSE)
write.table(fdf.otu, file="fecal_cons_otu.txt", sep="\t", row.names=FALSE)
write.table(cons_otu, file="cons_otu.txt", sep="\t", row.names=FALSE)

# read in differential abundance testing results - Taxa
# there will be a lot of files here, don't panic
# Boston - colon
cBos_P07_KW_L2 <- read.table(file="taxa/cBos_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW_L2 <- read.table(file="taxa/cBos_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW_L2 <- read.table(file="taxa/cBos_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_KW_L6 <- read.table(file="taxa/cBos_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_KW_L6 <- read.table(file="taxa/cBos_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_KW_L6 <- read.table(file="taxa/cBos_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT_L2 <- read.table(file="taxa/cBos_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT_L2 <- read.table(file="taxa/cBos_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT_L2 <- read.table(file="taxa/cBos_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P07_NPT_L6 <- read.table(file="taxa/cBos_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P20_NPT_L6 <- read.table(file="taxa/cBos_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cBos_P24_NPT_L6 <- read.table(file="taxa/cBos_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - colon
cLar_P07_KW_L2 <- read.table(file="taxa/cLar_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW_L2 <- read.table(file="taxa/cLar_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW_L2 <- read.table(file="taxa/cLar_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_KW_L6 <- read.table(file="taxa/cLar_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_KW_L6 <- read.table(file="taxa/cLar_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_KW_L6 <- read.table(file="taxa/cLar_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT_L2 <- read.table(file="taxa/cLar_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT_L2 <- read.table(file="taxa/cLar_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT_L2 <- read.table(file="taxa/cLar_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P07_NPT_L6 <- read.table(file="taxa/cLar_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P20_NPT_L6 <- read.table(file="taxa/cLar_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
cLar_P24_NPT_L6 <- read.table(file="taxa/cLar_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Boston - fecal
fBos_P07_KW_L2 <- read.table(file="taxa/fBos_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW_L2 <- read.table(file="taxa/fBos_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW_L2 <- read.table(file="taxa/fBos_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_KW_L6 <- read.table(file="taxa/fBos_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_KW_L6 <- read.table(file="taxa/fBos_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_KW_L6 <- read.table(file="taxa/fBos_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT_L2 <- read.table(file="taxa/fBos_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT_L2 <- read.table(file="taxa/fBos_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT_L2 <- read.table(file="taxa/fBos_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P07_NPT_L6 <- read.table(file="taxa/fBos_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P20_NPT_L6 <- read.table(file="taxa/fBos_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fBos_P24_NPT_L6 <- read.table(file="taxa/fBos_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
# Laramie - fecal
fLar_P07_KW_L2 <- read.table(file="taxa/fLar_P07_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW_L2 <- read.table(file="taxa/fLar_P20_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW_L2 <- read.table(file="taxa/fLar_P24_KW_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_KW_L6 <- read.table(file="taxa/fLar_P07_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_KW_L6 <- read.table(file="taxa/fLar_P20_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_KW_L6 <- read.table(file="taxa/fLar_P24_KW_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT_L2 <- read.table(file="taxa/fLar_P07_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT_L2 <- read.table(file="taxa/fLar_P20_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT_L2 <- read.table(file="taxa/fLar_P24_NPT_L2.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P07_NPT_L6 <- read.table(file="taxa/fLar_P07_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P20_NPT_L6 <- read.table(file="taxa/fLar_P20_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)
fLar_P24_NPT_L6 <- read.table(file="taxa/fLar_P24_NPT_L6.txt", header=TRUE, sep="\t", as.is=TRUE)

# use function GetSigsTaxa to filter each data.frame for 'significant' P-values
# Boston - colon
cBos_P07_KW_L2.sig <- GetSigsTaxa(cBos_P07_KW_L2)
cBos_P20_KW_L2.sig <- GetSigsTaxa(cBos_P20_KW_L2)
cBos_P24_KW_L2.sig <- GetSigsTaxa(cBos_P24_KW_L2)
cBos_P07_KW_L6.sig <- GetSigsTaxa(cBos_P07_KW_L6)
cBos_P20_KW_L6.sig <- GetSigsTaxa(cBos_P20_KW_L6)
cBos_P24_KW_L6.sig <- GetSigsTaxa(cBos_P24_KW_L6)
cBos_P07_NPT_L2.sig <- GetSigsTaxa(cBos_P07_NPT_L2)
cBos_P20_NPT_L2.sig <- GetSigsTaxa(cBos_P20_NPT_L2)
cBos_P24_NPT_L2.sig <- GetSigsTaxa(cBos_P24_NPT_L2)
cBos_P07_NPT_L6.sig <- GetSigsTaxa(cBos_P07_NPT_L6)
cBos_P20_NPT_L6.sig <- GetSigsTaxa(cBos_P20_NPT_L6)
cBos_P24_NPT_L6.sig <- GetSigsTaxa(cBos_P24_NPT_L6)
# Laramie - colon
cLar_P07_KW_L2.sig <- GetSigsTaxa(cLar_P07_KW_L2)
cLar_P20_KW_L2.sig <- GetSigsTaxa(cLar_P20_KW_L2)
cLar_P24_KW_L2.sig <- GetSigsTaxa(cLar_P24_KW_L2)
cLar_P07_KW_L6.sig <- GetSigsTaxa(cLar_P07_KW_L6)
cLar_P20_KW_L6.sig <- GetSigsTaxa(cLar_P20_KW_L6)
cLar_P24_KW_L6.sig <- GetSigsTaxa(cLar_P24_KW_L6)
cLar_P07_NPT_L2.sig <- GetSigsTaxa(cLar_P07_NPT_L2)
cLar_P20_NPT_L2.sig <- GetSigsTaxa(cLar_P20_NPT_L2)
cLar_P24_NPT_L2.sig <- GetSigsTaxa(cLar_P24_NPT_L2)
cLar_P07_NPT_L6.sig <- GetSigsTaxa(cLar_P07_NPT_L6)
cLar_P20_NPT_L6.sig <- GetSigsTaxa(cLar_P20_NPT_L6)
cLar_P24_NPT_L6.sig <- GetSigsTaxa(cLar_P24_NPT_L6)
# Boston - fecal
fBos_P07_KW_L2.sig <- GetSigsTaxa(fBos_P07_KW_L2)
fBos_P20_KW_L2.sig <- GetSigsTaxa(fBos_P20_KW_L2)
fBos_P24_KW_L2.sig <- GetSigsTaxa(fBos_P24_KW_L2)
fBos_P07_KW_L6.sig <- GetSigsTaxa(fBos_P07_KW_L6)
fBos_P20_KW_L6.sig <- GetSigsTaxa(fBos_P20_KW_L6)
fBos_P24_KW_L6.sig <- GetSigsTaxa(fBos_P24_KW_L6)
fBos_P07_NPT_L2.sig <- GetSigsTaxa(fBos_P07_NPT_L2)
fBos_P20_NPT_L2.sig <- GetSigsTaxa(fBos_P20_NPT_L2)
fBos_P24_NPT_L2.sig <- GetSigsTaxa(fBos_P24_NPT_L2)
fBos_P07_NPT_L6.sig <- GetSigsTaxa(fBos_P07_NPT_L6)
fBos_P20_NPT_L6.sig <- GetSigsTaxa(fBos_P20_NPT_L6)
fBos_P24_NPT_L6.sig <- GetSigsTaxa(fBos_P24_NPT_L6)
# Laramie - fecal
fLar_P07_KW_L2.sig <- GetSigsTaxa(fLar_P07_KW_L2)
fLar_P20_KW_L2.sig <- GetSigsTaxa(fLar_P20_KW_L2)
fLar_P24_KW_L2.sig <- GetSigsTaxa(fLar_P24_KW_L2)
fLar_P07_KW_L6.sig <- GetSigsTaxa(fLar_P07_KW_L6)
fLar_P20_KW_L6.sig <- GetSigsTaxa(fLar_P20_KW_L6)
fLar_P24_KW_L6.sig <- GetSigsTaxa(fLar_P24_KW_L6)
fLar_P07_NPT_L2.sig <- GetSigsTaxa(fLar_P07_NPT_L2)
fLar_P20_NPT_L2.sig <- GetSigsTaxa(fLar_P20_NPT_L2)
fLar_P24_NPT_L2.sig <- GetSigsTaxa(fLar_P24_NPT_L2)
fLar_P07_NPT_L6.sig <- GetSigsTaxa(fLar_P07_NPT_L6)
fLar_P20_NPT_L6.sig <- GetSigsTaxa(fLar_P20_NPT_L6)
fLar_P24_NPT_L6.sig <- GetSigsTaxa(fLar_P24_NPT_L6)

# add relevant metadata into appropriate columns
# Boston - colon
cBos_P07_KW_L2.sig$Facility <- "Boston"
cBos_P07_KW_L2.sig$Type <- "colon"
cBos_P07_KW_L2.sig$Test <- "krusk-wall"
cBos_P20_KW_L2.sig$Facility <- "Boston"
cBos_P20_KW_L2.sig$Type <- "colon"
cBos_P20_KW_L2.sig$Test <- "krusk-wall"
cBos_P24_KW_L2.sig$Facility <- "Boston"
cBos_P24_KW_L2.sig$Type <- "colon"
cBos_P24_KW_L2.sig$Test <- "krusk-wall"
cBos_P07_KW_L6.sig$Facility <- "Boston"
cBos_P07_KW_L6.sig$Type <- "colon"
cBos_P07_KW_L6.sig$Test <- "krusk-wall"
cBos_P20_KW_L6.sig$Facility <- "Boston"
cBos_P20_KW_L6.sig$Type <- "colon"
cBos_P20_KW_L6.sig$Test <- "krusk-wall"
cBos_P24_KW_L6.sig$Facility <- "Boston"
cBos_P24_KW_L6.sig$Type <- "colon"
cBos_P24_KW_L6.sig$Test <- "krusk-wall"
cBos_P07_NPT_L2.sig$Facility <- "Boston"
cBos_P07_NPT_L2.sig$Type <- "colon"
cBos_P07_NPT_L2.sig$Test <- "nonparam-T"
cBos_P20_NPT_L2.sig$Facility <- "Boston"
cBos_P20_NPT_L2.sig$Type <- "colon"
cBos_P20_NPT_L2.sig$Test <- "nonparam-T"
cBos_P24_NPT_L2.sig$Facility <- "Boston"
cBos_P24_NPT_L2.sig$Type <- "colon"
cBos_P24_NPT_L2.sig$Test <- "nonparam-T"
cBos_P07_NPT_L6.sig$Facility <- "Boston"
cBos_P07_NPT_L6.sig$Type <- "colon"
cBos_P07_NPT_L6.sig$Test <- "nonparam-T"
cBos_P20_NPT_L6.sig$Facility <- "Boston"
cBos_P20_NPT_L6.sig$Type <- "colon"
cBos_P20_NPT_L6.sig$Test <- "nonparam-T"
cBos_P24_NPT_L6.sig$Facility <- "Boston"
cBos_P24_NPT_L6.sig$Type <- "colon"
cBos_P24_NPT_L6.sig$Test <- "nonparam-T"
# Laramie - colon
cLar_P07_KW_L2.sig$Facility <- "Laramie"
cLar_P07_KW_L2.sig$Type <- "colon"
cLar_P07_KW_L2.sig$Test <- "krusk-wall"
cLar_P20_KW_L2.sig$Facility <- "Laramie"
cLar_P20_KW_L2.sig$Type <- "colon"
cLar_P20_KW_L2.sig$Test <- "krusk-wall"
cLar_P24_KW_L2.sig$Facility <- "Laramie"
cLar_P24_KW_L2.sig$Type <- "colon"
cLar_P24_KW_L2.sig$Test <- "krusk-wall"
cLar_P07_KW_L6.sig$Facility <- "Laramie"
cLar_P07_KW_L6.sig$Type <- "colon"
cLar_P07_KW_L6.sig$Test <- "krusk-wall"
cLar_P20_KW_L6.sig$Facility <- "Laramie"
cLar_P20_KW_L6.sig$Type <- "colon"
cLar_P20_KW_L6.sig$Test <- "krusk-wall"
cLar_P24_KW_L6.sig$Facility <- "Laramie"
cLar_P24_KW_L6.sig$Type <- "colon"
cLar_P24_KW_L6.sig$Test <- "krusk-wall"
cLar_P07_NPT_L2.sig$Facility <- "Laramie"
cLar_P07_NPT_L2.sig$Type <- "colon"
cLar_P07_NPT_L2.sig$Test <- "nonparam-T"
cLar_P20_NPT_L2.sig$Facility <- "Laramie"
cLar_P20_NPT_L2.sig$Type <- "colon"
cLar_P20_NPT_L2.sig$Test <- "nonparam-T"
cLar_P24_NPT_L2.sig$Facility <- "Laramie"
cLar_P24_NPT_L2.sig$Type <- "colon"
cLar_P24_NPT_L2.sig$Test <- "nonparam-T"
cLar_P07_NPT_L6.sig$Facility <- "Laramie"
cLar_P07_NPT_L6.sig$Type <- "colon"
cLar_P07_NPT_L6.sig$Test <- "nonparam-T"
cLar_P20_NPT_L6.sig$Facility <- "Laramie"
cLar_P20_NPT_L6.sig$Type <- "colon"
cLar_P20_NPT_L6.sig$Test <- "nonparam-T"
cLar_P24_NPT_L6.sig$Facility <- "Laramie"
cLar_P24_NPT_L6.sig$Type <- "colon"
cLar_P24_NPT_L6.sig$Test <- "nonparam-T"
# Boston - fecal
fBos_P07_KW_L2.sig$Facility <- "Boston"
fBos_P07_KW_L2.sig$Type <- "fecal"
fBos_P07_KW_L2.sig$Test <- "krusk-wall"
fBos_P20_KW_L2.sig$Facility <- "Boston"
fBos_P20_KW_L2.sig$Type <- "fecal"
fBos_P20_KW_L2.sig$Test <- "krusk-wall"
fBos_P24_KW_L2.sig$Facility <- "Boston"
fBos_P24_KW_L2.sig$Type <- "fecal"
fBos_P24_KW_L2.sig$Test <- "krusk-wall"
fBos_P07_KW_L6.sig$Facility <- "Boston"
fBos_P07_KW_L6.sig$Type <- "fecal"
fBos_P07_KW_L6.sig$Test <- "krusk-wall"
fBos_P20_KW_L6.sig$Facility <- "Boston"
fBos_P20_KW_L6.sig$Type <- "fecal"
fBos_P20_KW_L6.sig$Test <- "krusk-wall"
fBos_P24_KW_L6.sig$Facility <- "Boston"
fBos_P24_KW_L6.sig$Type <- "fecal"
fBos_P24_KW_L6.sig$Test <- "krusk-wall"
fBos_P07_NPT_L2.sig$Facility <- "Boston"
fBos_P07_NPT_L2.sig$Type <- "fecal"
fBos_P07_NPT_L2.sig$Test <- "nonparam-T"
fBos_P20_NPT_L2.sig$Facility <- "Boston"
fBos_P20_NPT_L2.sig$Type <- "fecal"
fBos_P20_NPT_L2.sig$Test <- "nonparam-T"
fBos_P24_NPT_L2.sig$Facility <- "Boston"
fBos_P24_NPT_L2.sig$Type <- "fecal"
fBos_P24_NPT_L2.sig$Test <- "nonparam-T"
fBos_P07_NPT_L6.sig$Facility <- "Boston"
fBos_P07_NPT_L6.sig$Type <- "fecal"
fBos_P07_NPT_L6.sig$Test <- "nonparam-T"
fBos_P20_NPT_L6.sig$Facility <- "Boston"
fBos_P20_NPT_L6.sig$Type <- "fecal"
fBos_P20_NPT_L6.sig$Test <- "nonparam-T"
fBos_P24_NPT_L6.sig$Facility <- "Boston"
fBos_P24_NPT_L6.sig$Type <- "fecal"
fBos_P24_NPT_L6.sig$Test <- "nonparam-T"
# Laramie - fecal
fLar_P07_KW_L2.sig$Facility <- "Laramie"
fLar_P07_KW_L2.sig$Type <- "fecal"
fLar_P07_KW_L2.sig$Test <- "krusk-wall"
fLar_P20_KW_L2.sig$Facility <- "Laramie"
fLar_P20_KW_L2.sig$Type <- "fecal"
fLar_P20_KW_L2.sig$Test <- "krusk-wall"
fLar_P24_KW_L2.sig$Facility <- "Laramie"
fLar_P24_KW_L2.sig$Type <- "fecal"
fLar_P24_KW_L2.sig$Test <- "krusk-wall"
fLar_P07_KW_L6.sig$Facility <- "Laramie"
fLar_P07_KW_L6.sig$Type <- "fecal"
fLar_P07_KW_L6.sig$Test <- "krusk-wall"
fLar_P20_KW_L6.sig$Facility <- "Laramie"
fLar_P20_KW_L6.sig$Type <- "fecal"
fLar_P20_KW_L6.sig$Test <- "krusk-wall"
fLar_P24_KW_L6.sig$Facility <- "Laramie"
fLar_P24_KW_L6.sig$Type <- "fecal"
fLar_P24_KW_L6.sig$Test <- "krusk-wall"
fLar_P07_NPT_L2.sig$Facility <- "Laramie"
fLar_P07_NPT_L2.sig$Type <- "fecal"
fLar_P07_NPT_L2.sig$Test <- "nonparam-T"
fLar_P20_NPT_L2.sig$Facility <- "Laramie"
fLar_P20_NPT_L2.sig$Type <- "fecal"
fLar_P20_NPT_L2.sig$Test <- "nonparam-T"
fLar_P24_NPT_L2.sig$Facility <- "Laramie"
fLar_P24_NPT_L2.sig$Type <- "fecal"
fLar_P24_NPT_L2.sig$Test <- "nonparam-T"
fLar_P07_NPT_L6.sig$Facility <- "Laramie"
fLar_P07_NPT_L6.sig$Type <- "fecal"
fLar_P07_NPT_L6.sig$Test <- "nonparam-T"
fLar_P20_NPT_L6.sig$Facility <- "Laramie"
fLar_P20_NPT_L6.sig$Type <- "fecal"
fLar_P20_NPT_L6.sig$Test <- "nonparam-T"
fLar_P24_NPT_L6.sig$Facility <- "Laramie"
fLar_P24_NPT_L6.sig$Type <- "fecal"
fLar_P24_NPT_L6.sig$Test <- "nonparam-T"

# Merge age- and type- matched dataframes from each Facility
# Then filter the merged df for NA's in two columns,
# This returns a df which retains OTUs that were present in both Facilities
# Finally, rbind the df by column to return our conserved candidates in a legible format

# P07 - colon
cdf07_KW_L2 <- merge(cBos_P07_KW_L2.sig,cLar_P07_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf07_KW_L2 <- cdf07_KW_L2[!is.na(cdf07_KW_L2$P.x) & !is.na(cdf07_KW_L2$P.y),]
cdf07_KW_L2 <- rbind(cBos_P07_KW_L2.sig[cBos_P07_KW_L2.sig$Taxon %in% cdf07_KW_L2$Taxon,],cLar_P07_KW_L2.sig[cLar_P07_KW_L2.sig$Taxon %in% cdf07_KW_L2$Taxon,])
cdf07_KW_L6 <- merge(cBos_P07_KW_L6.sig,cLar_P07_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf07_KW_L6 <- cdf07_KW_L6[!is.na(cdf07_KW_L6$P.x) & !is.na(cdf07_KW_L6$P.y),]
cdf07_KW_L6 <- rbind(cBos_P07_KW_L6.sig[cBos_P07_KW_L6.sig$Taxon %in% cdf07_KW_L6$Taxon,],cLar_P07_KW_L6.sig[cLar_P07_KW_L6.sig$Taxon %in% cdf07_KW_L6$Taxon,])
cdf07_NPT_L2 <- merge(cBos_P07_NPT_L2.sig,cLar_P07_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf07_NPT_L2 <- cdf07_NPT_L2[!is.na(cdf07_NPT_L2$P.x) & !is.na(cdf07_NPT_L2$P.y),]
cdf07_NPT_L2 <- rbind(cBos_P07_NPT_L2.sig[cBos_P07_NPT_L2.sig$Taxon %in% cdf07_NPT_L2$Taxon,],cLar_P07_NPT_L2.sig[cLar_P07_NPT_L2.sig$Taxon %in% cdf07_NPT_L2$Taxon,])
cdf07_NPT_L6 <- merge(cBos_P07_NPT_L6.sig,cLar_P07_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf07_NPT_L6 <- cdf07_NPT_L6[!is.na(cdf07_NPT_L6$P.x) & !is.na(cdf07_NPT_L6$P.y),]
cdf07_NPT_L6 <- rbind(cBos_P07_NPT_L6.sig[cBos_P07_NPT_L6.sig$Taxon %in% cdf07_NPT_L6$Taxon,],cLar_P07_NPT_L6.sig[cLar_P07_NPT_L6.sig$Taxon %in% cdf07_NPT_L6$Taxon,])

# P20 - colon
cdf20_KW_L2 <- merge(cBos_P20_KW_L2.sig,cLar_P20_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf20_KW_L2 <- cdf20_KW_L2[!is.na(cdf20_KW_L2$P.x) & !is.na(cdf20_KW_L2$P.y),]
cdf20_KW_L2 <- rbind(cBos_P20_KW_L2.sig[cBos_P20_KW_L2.sig$Taxon %in% cdf20_KW_L2$Taxon,],cLar_P20_KW_L2.sig[cLar_P20_KW_L2.sig$Taxon %in% cdf20_KW_L2$Taxon,])
cdf20_KW_L6 <- merge(cBos_P20_KW_L6.sig,cLar_P20_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf20_KW_L6 <- cdf20_KW_L6[!is.na(cdf20_KW_L6$P.x) & !is.na(cdf20_KW_L6$P.y),]
cdf20_KW_L6 <- rbind(cBos_P20_KW_L6.sig[cBos_P20_KW_L6.sig$Taxon %in% cdf20_KW_L6$Taxon,],cLar_P20_KW_L6.sig[cLar_P20_KW_L6.sig$Taxon %in% cdf20_KW_L6$Taxon,])
cdf20_NPT_L2 <- merge(cBos_P20_NPT_L2.sig,cLar_P20_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf20_NPT_L2 <- cdf20_NPT_L2[!is.na(cdf20_NPT_L2$P.x) & !is.na(cdf20_NPT_L2$P.y),]
cdf20_NPT_L2 <- rbind(cBos_P20_NPT_L2.sig[cBos_P20_NPT_L2.sig$Taxon %in% cdf20_NPT_L2$Taxon,],cLar_P20_NPT_L2.sig[cLar_P20_NPT_L2.sig$Taxon %in% cdf20_NPT_L2$Taxon,])
cdf20_NPT_L6 <- merge(cBos_P20_NPT_L6.sig,cLar_P20_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf20_NPT_L6 <- cdf20_NPT_L6[!is.na(cdf20_NPT_L6$P.x) & !is.na(cdf20_NPT_L6$P.y),]
cdf20_NPT_L6 <- rbind(cBos_P20_NPT_L6.sig[cBos_P20_NPT_L6.sig$Taxon %in% cdf20_NPT_L6$Taxon,],cLar_P20_NPT_L6.sig[cLar_P20_NPT_L6.sig$Taxon %in% cdf20_NPT_L6$Taxon,])

# P24 - colon
cdf24_KW_L2 <- merge(cBos_P24_KW_L2.sig,cLar_P24_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf24_KW_L2 <- cdf24_KW_L2[!is.na(cdf24_KW_L2$P.x) & !is.na(cdf24_KW_L2$P.y),]
cdf24_KW_L2 <- rbind(cBos_P24_KW_L2.sig[cBos_P24_KW_L2.sig$Taxon %in% cdf24_KW_L2$Taxon,],cLar_P24_KW_L2.sig[cLar_P24_KW_L2.sig$Taxon %in% cdf24_KW_L2$Taxon,])
cdf24_KW_L6 <- merge(cBos_P24_KW_L6.sig,cLar_P24_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf24_KW_L6 <- cdf24_KW_L6[!is.na(cdf24_KW_L6$P.x) & !is.na(cdf24_KW_L6$P.y),]
cdf24_KW_L6 <- rbind(cBos_P24_KW_L6.sig[cBos_P24_KW_L6.sig$Taxon %in% cdf24_KW_L6$Taxon,],cLar_P24_KW_L6.sig[cLar_P24_KW_L6.sig$Taxon %in% cdf24_KW_L6$Taxon,])
cdf24_NPT_L2 <- merge(cBos_P24_NPT_L2.sig,cLar_P24_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf24_NPT_L2 <- cdf24_NPT_L2[!is.na(cdf24_NPT_L2$P.x) & !is.na(cdf24_NPT_L2$P.y),]
cdf24_NPT_L2 <- rbind(cBos_P24_NPT_L2.sig[cBos_P24_NPT_L2.sig$Taxon %in% cdf24_NPT_L2$Taxon,],cLar_P24_NPT_L2.sig[cLar_P24_NPT_L2.sig$Taxon %in% cdf24_NPT_L2$Taxon,])
cdf24_NPT_L6 <- merge(cBos_P24_NPT_L6.sig,cLar_P24_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
cdf24_NPT_L6 <- cdf24_NPT_L6[!is.na(cdf24_NPT_L6$P.x) & !is.na(cdf24_NPT_L6$P.y),]
cdf24_NPT_L6 <- rbind(cBos_P24_NPT_L6.sig[cBos_P24_NPT_L6.sig$Taxon %in% cdf24_NPT_L6$Taxon,],cLar_P24_NPT_L6.sig[cLar_P24_NPT_L6.sig$Taxon %in% cdf24_NPT_L6$Taxon,])

# P07 - fecal
fdf07_KW_L2 <- merge(fBos_P07_KW_L2.sig,fLar_P07_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf07_KW_L2 <- fdf07_KW_L2[!is.na(fdf07_KW_L2$P.x) & !is.na(fdf07_KW_L2$P.y),]
fdf07_KW_L2 <- rbind(fBos_P07_KW_L2.sig[fBos_P07_KW_L2.sig$Taxon %in% fdf07_KW_L2$Taxon,],fLar_P07_KW_L2.sig[fLar_P07_KW_L2.sig$Taxon %in% fdf07_KW_L2$Taxon,])
fdf07_KW_L6 <- merge(fBos_P07_KW_L6.sig,fLar_P07_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf07_KW_L6 <- fdf07_KW_L6[!is.na(fdf07_KW_L6$P.x) & !is.na(fdf07_KW_L6$P.y),]
fdf07_KW_L6 <- rbind(fBos_P07_KW_L6.sig[fBos_P07_KW_L6.sig$Taxon %in% fdf07_KW_L6$Taxon,],fLar_P07_KW_L6.sig[fLar_P07_KW_L6.sig$Taxon %in% fdf07_KW_L6$Taxon,])
fdf07_NPT_L2 <- merge(fBos_P07_NPT_L2.sig,fLar_P07_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf07_NPT_L2 <- fdf07_NPT_L2[!is.na(fdf07_NPT_L2$P.x) & !is.na(fdf07_NPT_L2$P.y),]
fdf07_NPT_L2 <- rbind(fBos_P07_NPT_L2.sig[fBos_P07_NPT_L2.sig$Taxon %in% fdf07_NPT_L2$Taxon,],fLar_P07_NPT_L2.sig[fLar_P07_NPT_L2.sig$Taxon %in% fdf07_NPT_L2$Taxon,])
fdf07_NPT_L6 <- merge(fBos_P07_NPT_L6.sig,fLar_P07_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf07_NPT_L6 <- fdf07_NPT_L6[!is.na(fdf07_NPT_L6$P.x) & !is.na(fdf07_NPT_L6$P.y),]
fdf07_NPT_L6 <- rbind(fBos_P07_NPT_L6.sig[fBos_P07_NPT_L6.sig$Taxon %in% fdf07_NPT_L6$Taxon,],fLar_P07_NPT_L6.sig[fLar_P07_NPT_L6.sig$Taxon %in% fdf07_NPT_L6$Taxon,])

# P20 - fecal
fdf20_KW_L2 <- merge(fBos_P20_KW_L2.sig,fLar_P20_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf20_KW_L2 <- fdf20_KW_L2[!is.na(fdf20_KW_L2$P.x) & !is.na(fdf20_KW_L2$P.y),]
fdf20_KW_L2 <- rbind(fBos_P20_KW_L2.sig[fBos_P20_KW_L2.sig$Taxon %in% fdf20_KW_L2$Taxon,],fLar_P20_KW_L2.sig[fLar_P20_KW_L2.sig$Taxon %in% fdf20_KW_L2$Taxon,])
fdf20_KW_L6 <- merge(fBos_P20_KW_L6.sig,fLar_P20_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf20_KW_L6 <- fdf20_KW_L6[!is.na(fdf20_KW_L6$P.x) & !is.na(fdf20_KW_L6$P.y),]
fdf20_KW_L6 <- rbind(fBos_P20_KW_L6.sig[fBos_P20_KW_L6.sig$Taxon %in% fdf20_KW_L6$Taxon,],fLar_P20_KW_L6.sig[fLar_P20_KW_L6.sig$Taxon %in% fdf20_KW_L6$Taxon,])
fdf20_NPT_L2 <- merge(fBos_P20_NPT_L2.sig,fLar_P20_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf20_NPT_L2 <- fdf20_NPT_L2[!is.na(fdf20_NPT_L2$P.x) & !is.na(fdf20_NPT_L2$P.y),]
fdf20_NPT_L2 <- rbind(fBos_P20_NPT_L2.sig[fBos_P20_NPT_L2.sig$Taxon %in% fdf20_NPT_L2$Taxon,],fLar_P20_NPT_L2.sig[fLar_P20_NPT_L2.sig$Taxon %in% fdf20_NPT_L2$Taxon,])
fdf20_NPT_L6 <- merge(fBos_P20_NPT_L6.sig,fLar_P20_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf20_NPT_L6 <- fdf20_NPT_L6[!is.na(fdf20_NPT_L6$P.x) & !is.na(fdf20_NPT_L6$P.y),]
fdf20_NPT_L6 <- rbind(fBos_P20_NPT_L6.sig[fBos_P20_NPT_L6.sig$Taxon %in% fdf20_NPT_L6$Taxon,],fLar_P20_NPT_L6.sig[fLar_P20_NPT_L6.sig$Taxon %in% fdf20_NPT_L6$Taxon,])

# P24 - fecal
fdf24_KW_L2 <- merge(fBos_P24_KW_L2.sig,fLar_P24_KW_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf24_KW_L2 <- fdf24_KW_L2[!is.na(fdf24_KW_L2$P.x) & !is.na(fdf24_KW_L2$P.y),]
fdf24_KW_L2 <- rbind(fBos_P24_KW_L2.sig[fBos_P24_KW_L2.sig$Taxon %in% fdf24_KW_L2$Taxon,],fLar_P24_KW_L2.sig[fLar_P24_KW_L2.sig$Taxon %in% fdf24_KW_L2$Taxon,])
fdf24_KW_L6 <- merge(fBos_P24_KW_L6.sig,fLar_P24_KW_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf24_KW_L6 <- fdf24_KW_L6[!is.na(fdf24_KW_L6$P.x) & !is.na(fdf24_KW_L6$P.y),]
fdf24_KW_L6 <- rbind(fBos_P24_KW_L6.sig[fBos_P24_KW_L6.sig$Taxon %in% fdf24_KW_L6$Taxon,],fLar_P24_KW_L6.sig[fLar_P24_KW_L6.sig$Taxon %in% fdf24_KW_L6$Taxon,])
fdf24_NPT_L2 <- merge(fBos_P24_NPT_L2.sig,fLar_P24_NPT_L2.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf24_NPT_L2 <- fdf24_NPT_L2[!is.na(fdf24_NPT_L2$P.x) & !is.na(fdf24_NPT_L2$P.y),]
fdf24_NPT_L2 <- rbind(fBos_P24_NPT_L2.sig[fBos_P24_NPT_L2.sig$Taxon %in% fdf24_NPT_L2$Taxon,],fLar_P24_NPT_L2.sig[fLar_P24_NPT_L2.sig$Taxon %in% fdf24_NPT_L2$Taxon,])
fdf24_NPT_L6 <- merge(fBos_P24_NPT_L6.sig,fLar_P24_NPT_L6.sig, by="Taxon", all=TRUE, sort=FALSE)
fdf24_NPT_L6 <- fdf24_NPT_L6[!is.na(fdf24_NPT_L6$P.x) & !is.na(fdf24_NPT_L6$P.y),]
fdf24_NPT_L6 <- rbind(fBos_P24_NPT_L6.sig[fBos_P24_NPT_L6.sig$Taxon %in% fdf24_NPT_L6$Taxon,],fLar_P24_NPT_L6.sig[fLar_P24_NPT_L6.sig$Taxon %in% fdf24_NPT_L6$Taxon,])

# combine (rbind) each age-test-type data.frame
# sort the columns of each data.frame, then sort rows within columns by Age and OTU,
# and finally, remove any values of '1' in column 'Age'
# NOTE: data.frames with 0 obs. will disappear because they have no information to combine
# colon
cdf.tax <- rbind(cdf07_KW_L2,cdf07_KW_L6,cdf07_NPT_L2,cdf07_NPT_L6,cdf20_KW_L2,cdf20_KW_L6,cdf20_NPT_L2,cdf20_NPT_L6,cdf24_KW_L2,cdf24_KW_L6,cdf24_NPT_L2,cdf24_NPT_L6)
cdf.tax <- dplyr::select(cdf.tax, c(Age, Type, Facility, KO_mean, WT_mean, log2FC, Taxon, Test, P))
cdf.tax <- cdf.tax[order(cdf.tax$Age, cdf.tax$Taxon),]
kill.row.c <- which(cdf.tax$Age == 1)
cdf.tax <- cdf.tax[- c(kill.row.c),]

# fecal
fdf.tax <- rbind(fdf07_KW_L2,fdf07_KW_L6,fdf07_NPT_L2,fdf07_NPT_L6,fdf20_KW_L2,fdf20_KW_L6,fdf20_NPT_L2,fdf20_NPT_L6,fdf24_KW_L2,fdf24_KW_L6,fdf24_NPT_L2,fdf24_NPT_L6)
fdf.tax <- dplyr::select(fdf.tax, c(Age, Type, Facility, KO_mean, WT_mean, log2FC, Taxon, Test, P))
fdf.tax <- fdf.tax[order(fdf.tax$Age, fdf.tax$Taxon),]
kill.row.f <- which(fdf.tax$Age == 1)
fdf.tax <- fdf.tax[- c(kill.row.f),]

# finally, rbind cdf and fdf, and again sort by Age and Taxon
cons_tax <- rbind(cdf.tax,fdf.tax)
cons_tax <- cons_tax[order(cons_tax$Age, cons_tax$Taxon),]

# save tables
setwd("~/Desktop/r_analysis/tab_1_tab_s7")
write.table(cdf.tax, file="colon_cons_tax.txt", sep="\t", row.names=FALSE)
write.table(fdf.tax, file="fecal_cons_tax.txt", sep="\t", row.names=FALSE)
write.table(cons_tax, file="cons_tax.txt", sep="\t", row.names=FALSE)

# NOTE: for Table construction look at cons_otu.txt and cons_tax.txt
# For Table 1: look for OTUs and Taxa that share the same relationship in both facilities 
# For Table S7: look for whatever OTUs and Taxa are left over (i.e. those with opposite relationships in both facilities)

#############################
######### TABLE S1 ##########
#############################

# set the working directory
setwd("~/Desktop/r_analysis/tab_s1/")

# read in the distance matrices (Total Beta Diversity)
uw_cBL_dm <- read.dm(file="../bdiv/uw_cBL.txt")
w_cBL_dm <- read.dm(file="../bdiv/w_cBL.txt")
uw_fBL_dm <- read.dm(file="../bdiv/uw_fBL.txt")
w_fBL_dm <- read.dm(file="../bdiv/w_fBL.txt")
uw_c57_dm <- read.dm(file="../bdiv/uw_c57.txt")
w_c57_dm <- read.dm(file="../bdiv/w_c57.txt")

# pairwise adonis for the HSCR dataset
uw_adon.cBL <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="GroupFacility", dist.obj=uw_cBL_dm, match.col="SampleID", 
                          comp.formula=flt.dm~GroupFacility, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.cBL <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="GroupFacility", dist.obj=w_cBL_dm, match.col="SampleID", 
                         comp.formula=flt.dm~GroupFacility, n.perms=10000, p.adj.method="fdr", digits=3)
uw_adon.fBL <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="GroupFacility", dist.obj=uw_fBL_dm, match.col="SampleID", 
                          comp.formula=flt.dm~GroupFacility, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.fBL <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="GroupFacility", dist.obj=w_fBL_dm, match.col="SampleID", 
                         comp.formula=flt.dm~GroupFacility, n.perms=10000, p.adj.method="fdr", digits=3)

# create a vector to filter the outputs for groups of interest
# in this case, age- and genotype- matched mice from Boston and Laramie
# run them in both directions (aka Bos vs Lar AND Lar vs Bos)
vec.fac.comp <- c("P07-WT-Bos vs P07-WT-Lar","P07-WT-Lar vs P07-WT-Bos","P07-KO-Bos vs P07-KO-Lar","P07-KO-Lar vs P07-KO-Bos",
                  "P20-WT-Bos vs P20-WT-Lar","P20-WT-Lar vs P20-WT-Bos","P20-KO-Bos vs P20-KO-Lar","P20-KO-Lar vs P20-KO-Bos",
                  "P24-WT-Bos vs P24-WT-Lar","P24-WT-Lar vs P24-WT-Bos","P24-KO-Bos vs P24-KO-Lar","P24-KO-Lar vs P24-KO-Bos")

# create a vector of row numbers in column 'Comparison' that match our groups of interest
row.nums.uw_cBL <- which(uw_adon.cBL[,"Comparison"] %in% vec.fac.comp)
row.nums.w_cBL <- which(w_adon.cBL[,"Comparison"] %in% vec.fac.comp)
row.nums.uw_fBL <- which(uw_adon.fBL[,"Comparison"] %in% vec.fac.comp)
row.nums.w_fBL <- which(w_adon.fBL[,"Comparison"] %in% vec.fac.comp)

# create new data.frames with only our groups of interest
uw_adon.cBL.fac <- uw_adon.cBL[row.nums.uw_cBL,]
w_adon.cBL.fac <- w_adon.cBL[row.nums.w_cBL,]
uw_adon.fBL.fac <- uw_adon.fBL[row.nums.uw_fBL,]
w_adon.fBL.fac <- w_adon.fBL[row.nums.w_fBL,]

# add columns with rows specifying beta diversity metric, the sample type, and whether the input data was Total or Core
uw_adon.cBL.fac$DivMetrc <- "UW.Uni"
uw_adon.cBL.fac$Type <- "colon"
uw_adon.cBL.fac$Input <- "Total"
w_adon.cBL.fac$DivMetrc <- "W.Uni"
w_adon.cBL.fac$Type <- "colon"
w_adon.cBL.fac$Input <- "Total"
uw_adon.fBL.fac$DivMetrc <- "UW.Uni"
uw_adon.fBL.fac$Type <- "fecal"
uw_adon.fBL.fac$Input <- "Total"
w_adon.fBL.fac$DivMetrc <- "W.Uni"
w_adon.fBL.fac$Type <- "fecal"
w_adon.fBL.fac$Input <- "Total"

# pairwise adonis for the C57BL/6J dataset (total beta div.)
# NOTE: this isn't actually pairwise as the only grouping variable is Facility (Boston vs. Laramie)
# therefore, the resultant p.adj is identical to p.val because no correction can be applied for a single comparison
# we use the pwise.adon function to make our lives easier as it still works with a single comparison
uw_adon.c57.fac <- pwise.adon(meta=df.meta.c57, flt.col.intrst="Facility", dist.obj=uw_c57_dm, match.col="SampleID", 
                              comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=4)
w_adon.c57.fac <- pwise.adon(meta=df.meta.c57, flt.col.intrst="Facility", dist.obj=w_c57_dm, match.col="SampleID", 
                             comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=4)

# add columns with rows specifying beta diversity metric, the sample type, and whether the input data was Total or Core
uw_adon.c57.fac$DivMetrc <- "UW.Uni"
uw_adon.c57.fac$Type <- "fecal"
uw_adon.c57.fac$Input <- "Total"
w_adon.c57.fac$DivMetrc <- "W.Uni"
w_adon.c57.fac$Type <- "fecal"
w_adon.c57.fac$Input <- "Total"

# set the working directory (should be the same as above)
setwd("~/Desktop/r_analysis/tab_s1/")

# read in the distance matrices (Core Beta Diversity)
cBL_P07WTcore_dm <- read.dm(file="../fig_s6/w_cBL_P07WTcore.txt")
fBL_P07WTcore_dm <- read.dm(file="../fig_s6/w_fBL_P07WTcore.txt")
cBL_P07KOcore_dm <- read.dm(file="../fig_s6/w_cBL_P07KOcore.txt")
fBL_P07KOcore_dm <- read.dm(file="../fig_s6/w_fBL_P07KOcore.txt")
cBL_P20WTcore_dm <- read.dm(file="../fig_2/w_cBL_P20WTcore.txt")
fBL_P20WTcore_dm <- read.dm(file="../fig_2/w_fBL_P20WTcore.txt")
cBL_P20KOcore_dm <- read.dm(file="../fig_2/w_cBL_P20KOcore.txt")
fBL_P20KOcore_dm <- read.dm(file="../fig_2/w_fBL_P20KOcore.txt")
cBL_P24WTcore_dm <- read.dm(file="../fig_s7/w_cBL_P24WTcore.txt")
fBL_P24WTcore_dm <- read.dm(file="../fig_s7/w_fBL_P24WTcore.txt")
cBL_P24KOcore_dm <- read.dm(file="../fig_s7/w_cBL_P24KOcore.txt")
fBL_P24KOcore_dm <- read.dm(file="../fig_s7/w_fBL_P24KOcore.txt")
c57core_dm <- read.dm(file="../fig_4/c57core50.txt")

# pairwise adonis for core beta diversity
# NOTE: this isn't actually pairwise as the only grouping variable is Facility (Boston vs. Laramie)
# therefore, the resultant p.adj is identical to p.val because no correction can be applied for a single comparison
# we use the pwise.adon function to make our lives easier as it still works with a single comparison
cBL_P07WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P07WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P07WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P07WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
cBL_P07KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P07KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P07KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P07KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
cBL_P20WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P20WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P20WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P20WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
cBL_P20KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P20KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P20KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P20KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
cBL_P24WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P24WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P24WTcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P24WTcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
cBL_P24KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=cBL_P24KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
fBL_P24KOcore.fac <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Facility", dist.obj=fBL_P24KOcore_dm, match.col="SampleID", 
                                comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=3)
c57core.fac <- pwise.adon(meta=df.meta.c57, flt.col.intrst="Facility", dist.obj=c57core_dm, match.col="SampleID", 
                          comp.formula=flt.dm~Facility, n.perms=10000, p.adj.method="fdr", digits=4)

# add columns with rows specifying beta diversity metric, the sample type, and whether the input data was Total or [AgeGeno] Core
cBL_P07WTcore.fac$DivMetrc <- "W.Uni"
cBL_P07WTcore.fac$Type <- "colon"
cBL_P07WTcore.fac$Input <- "P07-WT.Core-50"
fBL_P07WTcore.fac$DivMetrc <- "W.Uni"
fBL_P07WTcore.fac$Type <- "fecal"
fBL_P07WTcore.fac$Input <- "P07-WT.Core-50"
cBL_P07KOcore.fac$DivMetrc <- "W.Uni"
cBL_P07KOcore.fac$Type <- "colon"
cBL_P07KOcore.fac$Input <- "P07-KO.Core-50"
fBL_P07KOcore.fac$DivMetrc <- "W.Uni"
fBL_P07KOcore.fac$Type <- "fecal"
fBL_P07KOcore.fac$Input <- "P07-KO.Core-50"
cBL_P20WTcore.fac$DivMetrc <- "W.Uni"
cBL_P20WTcore.fac$Type <- "colon"
cBL_P20WTcore.fac$Input <- "P20-WT.Core-50"
fBL_P20WTcore.fac$DivMetrc <- "W.Uni"
fBL_P20WTcore.fac$Type <- "fecal"
fBL_P20WTcore.fac$Input <- "P20-WT.Core-50"
cBL_P20KOcore.fac$DivMetrc <- "W.Uni"
cBL_P20KOcore.fac$Type <- "colon"
cBL_P20KOcore.fac$Input <- "P20-KO.Core-50"
fBL_P20KOcore.fac$DivMetrc <- "W.Uni"
fBL_P20KOcore.fac$Type <- "fecal"
fBL_P20KOcore.fac$Input <- "P20-KO.Core-50"
cBL_P24WTcore.fac$DivMetrc <- "W.Uni"
cBL_P24WTcore.fac$Type <- "colon"
cBL_P24WTcore.fac$Input <- "P24-WT.Core-50"
fBL_P24WTcore.fac$DivMetrc <- "W.Uni"
fBL_P24WTcore.fac$Type <- "fecal"
fBL_P24WTcore.fac$Input <- "P24-WT.Core-50"
cBL_P24KOcore.fac$DivMetrc <- "W.Uni"
cBL_P24KOcore.fac$Type <- "colon"
cBL_P24KOcore.fac$Input <- "P24-KO.Core-50"
fBL_P24KOcore.fac$DivMetrc <- "W.Uni"
fBL_P24KOcore.fac$Type <- "fecal"
fBL_P24KOcore.fac$Input <- "P24-KO.Core-50"
c57core.fac$DivMetrc <- "W.Uni"
c57core.fac$Type <- "fecal"
c57core.fac$Input <- "Core-50"

# combine all of the data.frames
adon.fac <- rbind(uw_adon.cBL.fac,w_adon.cBL.fac,uw_adon.fBL.fac,w_adon.fBL.fac,
                  cBL_P07WTcore.fac,fBL_P07WTcore.fac,cBL_P07KOcore.fac,fBL_P07KOcore.fac,
                  cBL_P20WTcore.fac,fBL_P20WTcore.fac,cBL_P20KOcore.fac,fBL_P20KOcore.fac,
                  cBL_P24WTcore.fac,fBL_P24WTcore.fac,cBL_P24KOcore.fac,fBL_P24KOcore.fac,
                  uw_adon.c57.fac,w_adon.c57.fac,
                  c57core.fac)

# save table
setwd("~/Desktop/r_analysis/tab_s1/")
write.table(adon.fac, file="adonis_facility.txt", sep="\t", row.names=FALSE)

#############################
######### TABLE S2 ##########
#############################

# set the working directory
setwd("~/Desktop/r_analysis/tab_s2/")

# read in alpha diversity files
# these are needed to generate the values in Table S2 Column: 'Total # Observed OTUs'
cBL.adiv <- read.table(file="cBL_HSCR_adiv.txt", header=TRUE, sep="\t", as.is=TRUE)
c57.adiv <- read.table(file="c57_adiv.txt", header=TRUE, sep="\t", as.is=TRUE)

# change column 1 from 'X' to 'SampleID'
names(cBL.adiv)[1] <- "SampleID"
names(c57.adiv)[1] <- "SampleID"

# merge in metadata from map
cBL.adiv.meta <- merge(cBL.adiv, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
c57.adiv.meta <- merge(c57.adiv, df.meta.c57, by="SampleID", all.x=TRUE, sort=FALSE)

# select relevant columns, dropping unneeded columns
cBL.adiv.obsotu <- dplyr::select(cBL.adiv.meta, c(SampleID, GroupFacility, observed_otus))
c57.adiv.obsotu <- dplyr::select(c57.adiv.meta, c(SampleID, Facility, observed_otus))

# using package dplyr calculate mean number of observed OTUs for each group
# these will be grouped by GroupFacility (cBL and fBL) or Facility (c57)
cBL.obsotu.mean <- dplyr::summarise(dplyr::group_by(cBL.adiv.obsotu, GroupFacility), mean=mean(observed_otus))
c57.obsotu.mean <- dplyr::summarise(dplyr::group_by(c57.adiv.obsotu, Facility), mean=mean(observed_otus))

# save tables
setwd("~/Desktop/r_analysis/tab_s2/")
write.table(cBL.obsotu.mean, file="cBL_obsotu_mean.txt", sep="\t", row.names=FALSE)
write.table(c57.obsotu.mean, file="c57_obsotu_mean.txt", sep="\t", row.names=FALSE)

# read in the text files corresponding to the values in Table S2 Column: '# core OTUs'
# NOTE: the number of rows (# obs.) in the file = '# core OTUs"

# P07-WT
cBL_P07WT.50 <- read.table(file="hscr_core_comp/cBL_P07WT/core_otus_50.txt", sep="\t", skip=1) # 14 obs.
cBos_P07WT.50 <- read.table(file="hscr_core_comp/cBos_P07WT/core_otus_50.txt", sep="\t", skip=1) # 7 obs.
cBos_P07WT.75 <- read.table(file="hscr_core_comp/cBos_P07WT/core_otus_75.txt", sep="\t", skip=1) # 4 obs.
cBos_P07WT.100 <- read.table(file="hscr_core_comp/cBos_P07WT/core_otus_100.txt", sep="\t", skip=1) # 3 obs.
cLar_P07WT.50 <- read.table(file="hscr_core_comp/cLar_P07WT/core_otus_50.txt", sep="\t", skip=1) # 34 obs.
cLar_P07WT.75 <- read.table(file="hscr_core_comp/cLar_P07WT/core_otus_75.txt", sep="\t", skip=1) # 20 obs.
cLar_P07WT.100 <- read.table(file="hscr_core_comp/cLar_P07WT/core_otus_100.txt", sep="\t", skip=1) # 8 obs.

# P07-KO
cBL_P07KO.50 <- read.table(file="hscr_core_comp/cBL_P07KO/core_otus_50.txt", sep="\t", skip=1) # 4 obs.
cBos_P07KO.50 <- read.table(file="hscr_core_comp/cBos_P07KO/core_otus_50.txt", sep="\t", skip=1) # 16 obs.
cBos_P07KO.75 <- read.table(file="hscr_core_comp/cBos_P07KO/core_otus_75.txt", sep="\t", skip=1) # 7 obs.
cBos_P07KO.100 <- read.table(file="hscr_core_comp/cBos_P07KO/core_otus_100.txt", sep="\t", skip=1) # 2 obs.
cLar_P07KO.50 <- read.table(file="hscr_core_comp/cLar_P07KO/core_otus_50.txt", sep="\t", skip=1) # 38 obs.
cLar_P07KO.75 <- read.table(file="hscr_core_comp/cLar_P07KO/core_otus_75.txt", sep="\t", skip=1) # 18 obs.
cLar_P07KO.100 <- read.table(file="hscr_core_comp/cLar_P07KO/core_otus_100.txt", sep="\t", skip=1) # 11 obs.

# P20-WT
cBL_P20WT.50 <- read.table(file="hscr_core_comp/cBL_P20WT/core_otus_50.txt", sep="\t", skip=1) # 18 obs.
cBL_P20WT.75 <- read.table(file="hscr_core_comp/cBL_P20WT/core_otus_75.txt", sep="\t", skip=1) # 2 obs.
cBos_P20WT.50 <- read.table(file="hscr_core_comp/cBos_P20WT/core_otus_50.txt", sep="\t", skip=1) # 42 obs.
cBos_P20WT.75 <- read.table(file="hscr_core_comp/cBos_P20WT/core_otus_75.txt", sep="\t", skip=1) # 23 obs.
cBos_P20WT.100 <- read.table(file="hscr_core_comp/cBos_P20WT/core_otus_100.txt", sep="\t", skip=1) # 8 obs.
cLar_P20WT.50 <- read.table(file="hscr_core_comp/cLar_P20WT/core_otus_50.txt", sep="\t", skip=1) # 63 obs.
cLar_P20WT.75 <- read.table(file="hscr_core_comp/cLar_P20WT/core_otus_75.txt", sep="\t", skip=1) # 23 obs.
cLar_P20WT.100 <- read.table(file="hscr_core_comp/cLar_P20WT/core_otus_100.txt", sep="\t", skip=1) # 10 obs.

# P20-KO
cBL_P20KO.50 <- read.table(file="hscr_core_comp/cBL_P20KO/core_otus_50.txt", sep="\t", skip=1) # 24 obs.
cBL_P20KO.75 <- read.table(file="hscr_core_comp/cBL_P20KO/core_otus_75.txt", sep="\t", skip=1) # 4 obs.
cBL_P20KO.100 <- read.table(file="hscr_core_comp/cBL_P20KO/core_otus_100.txt", sep="\t", skip=1) # 2 obs.
cBos_P20KO.50 <- read.table(file="hscr_core_comp/cBos_P20KO/core_otus_50.txt", sep="\t", skip=1) # 57 obs.
cBos_P20KO.75 <- read.table(file="hscr_core_comp/cBos_P20KO/core_otus_75.txt", sep="\t", skip=1) # 31 obs.
cBos_P20KO.100 <- read.table(file="hscr_core_comp/cBos_P20KO/core_otus_100.txt", sep="\t", skip=1) # 11 obs.
cLar_P20KO.50 <- read.table(file="hscr_core_comp/cLar_P20KO/core_otus_50.txt", sep="\t", skip=1) # 57 obs.
cLar_P20KO.75 <- read.table(file="hscr_core_comp/cLar_P20KO/core_otus_75.txt", sep="\t", skip=1) # 28 obs.
cLar_P20KO.100 <- read.table(file="hscr_core_comp/cLar_P20KO/core_otus_100.txt", sep="\t", skip=1) # 16 obs.

# P24-WT
cBL_P24WT.50 <- read.table(file="hscr_core_comp/cBL_P24WT/core_otus_50.txt", sep="\t", skip=1) # 50 obs.
cBL_P24WT.75 <- read.table(file="hscr_core_comp/cBL_P24WT/core_otus_75.txt", sep="\t", skip=1) # 3 obs.
cBL_P24WT.100 <- read.table(file="hscr_core_comp/cBL_P24WT/core_otus_100.txt", sep="\t", skip=1) # 1 obs.
cBos_P24WT.50 <- read.table(file="hscr_core_comp/cBos_P24WT/core_otus_50.txt", sep="\t", skip=1) # 91 obs.
cBos_P24WT.75 <- read.table(file="hscr_core_comp/cBos_P24WT/core_otus_75.txt", sep="\t", skip=1) # 40 obs.
cBos_P24WT.100 <- read.table(file="hscr_core_comp/cBos_P24WT/core_otus_100.txt", sep="\t", skip=1) # 40 obs.
cLar_P24WT.50 <- read.table(file="hscr_core_comp/cLar_P24WT/core_otus_50.txt", sep="\t", skip=1) # 51 obs.
cLar_P24WT.75 <- read.table(file="hscr_core_comp/cLar_P24WT/core_otus_75.txt", sep="\t", skip=1) # 10 obs.
cLar_P24WT.100 <- read.table(file="hscr_core_comp/cLar_P24WT/core_otus_100.txt", sep="\t", skip=1) # 5 obs.

# P24-KO
cBL_P24KO.50 <- read.table(file="hscr_core_comp/cBL_P24KO/core_otus_50.txt", sep="\t", skip=1) # 20 obs.
cBL_P24KO.75 <- read.table(file="hscr_core_comp/cBL_P24KO/core_otus_75.txt", sep="\t", skip=1) # 3 obs.
cBos_P24KO.50 <- read.table(file="hscr_core_comp/cBos_P24KO/core_otus_50.txt", sep="\t", skip=1) # 75 obs.
cBos_P24KO.75 <- read.table(file="hscr_core_comp/cBos_P24KO/core_otus_75.txt", sep="\t", skip=1) # 23 obs.
cBos_P24KO.100 <- read.table(file="hscr_core_comp/cBos_P24KO/core_otus_100.txt", sep="\t", skip=1) # 23 obs.
cLar_P24KO.50 <- read.table(file="hscr_core_comp/cLar_P24KO/core_otus_50.txt", sep="\t", skip=1) # 52 obs.
cLar_P24KO.75 <- read.table(file="hscr_core_comp/cLar_P24KO/core_otus_75.txt", sep="\t", skip=1) # 22 obs.
cLar_P24KO.100 <- read.table(file="hscr_core_comp/cLar_P24KO/core_otus_100.txt", sep="\t", skip=1) # 6 obs.

# C57BL/6J
BL_c57.50 <- read.table(file="c57_core_comp/BL_c57/core_otus_50.txt", sep="\t", skip=1) # 277 obs.
BL_c57.75 <- read.table(file="c57_core_comp/BL_c57/core_otus_75.txt", sep="\t", skip=1) # 116 obs.
BL_c57.100 <- read.table(file="c57_core_comp/BL_c57/core_otus_100.txt", sep="\t", skip=1) # 40 obs.
bos_c57.50 <- read.table(file="c57_core_comp/bos_c57/core_otus_50.txt", sep="\t", skip=1) # 354 obs.
bos_c57.75 <- read.table(file="c57_core_comp/bos_c57/core_otus_75.txt", sep="\t", skip=1) # 163 obs.
bos_c57.100 <- read.table(file="c57_core_comp/bos_c57/core_otus_100.txt", sep="\t", skip=1) # 76 obs.
lar_c57.50 <- read.table(file="c57_core_comp/lar_c57/core_otus_50.txt", sep="\t", skip=1) # 326 obs.
lar_c57.75 <- read.table(file="c57_core_comp/lar_c57/core_otus_75.txt", sep="\t", skip=1) # 130 obs.
lar_c57.100 <- read.table(file="c57_core_comp/lar_c57/core_otus_100.txt", sep="\t", skip=1) # 65 obs.

# NOTE: for Table 2 construction...
# ... values '_adiv.txt' files correspond to 'Total # of Observed OTUs'
# ... values for 'Conserved' in column 'Total # of Observed OTUs' are equal to:
# ... the average Total # of Observed OTUs for Boston and Laramie, aka (Boston+Laramie)/2
# ... values for '% Observed OTUs = core' are calculated as 'Total # of Observed OTUs'/'# of core OTUs', expressed as a percentage
# these were calculated in Excel (in the future, that will never be the case)

#############################
######### TABLE S3 ##########
#############################

# set the working directory
setwd("~/Desktop/r_analysis/tab_s3")

# read in all of the alpha diversity files
# Inter-Facility
cBL.adiv.df <- read.table(file="hscr/inter/cBL_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)
fBL.adiv.df <- read.table(file="hscr/inter/fBL_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)
c57.adiv.df <- read.table(file="c57/c57_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)

# Intra-Facility
cBos.adiv.df <- read.table(file="hscr/intra/cBos_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)
fBos.adiv.df <- read.table(file="hscr/intra/fBos_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)
cLar.adiv.df <- read.table(file="hscr/intra/cLar_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)
fLar.adiv.df <- read.table(file="hscr/intra/fLar_HSCR_adiv.txt",header=TRUE,sep="\t", as.is=TRUE)

# change column 1 from 'X' to 'SampleID'
names(cBL.adiv.df)[1] <- "SampleID" 
names(fBL.adiv.df)[1] <- "SampleID"
names(c57.adiv.df)[1] <- "SampleID"
names(cBos.adiv.df)[1] <- "SampleID"
names(fBos.adiv.df)[1] <- "SampleID" 
names(cLar.adiv.df)[1] <- "SampleID"
names(fLar.adiv.df)[1] <- "SampleID" 

# merge in metadata from map
cBL.adiv.df.meta <- merge(cBL.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
fBL.adiv.df.meta <- merge(fBL.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
c57.adiv.df.meta <- merge(c57.adiv.df, df.meta.c57, by="SampleID", all.x=TRUE, sort=FALSE)
cBos.adiv.df.meta <- merge(cBos.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
fBos.adiv.df.meta <- merge(fBos.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
cLar.adiv.df.meta <- merge(cLar.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)
fLar.adiv.df.meta <- merge(fLar.adiv.df, df.meta.hscr, by="SampleID", all.x=TRUE, sort=FALSE)

# select relevant columns, dropping unneeded columns
cBL.adiv.df.meta <- dplyr::select(cBL.adiv.df.meta, c(SampleID, GroupFacility, observed_otus, chao1))
fBL.adiv.df.meta <- dplyr::select(fBL.adiv.df.meta, c(SampleID, GroupFacility, observed_otus, chao1))
c57.adiv.df.meta <- dplyr::select(c57.adiv.df.meta, c(SampleID, Facility, observed_otus, chao1))
cBos.adiv.df.meta <- dplyr::select(cBos.adiv.df.meta, c(SampleID, Group, observed_otus, chao1))
fBos.adiv.df.meta <- dplyr::select(fBos.adiv.df.meta, c(SampleID, Group, observed_otus, chao1))
cLar.adiv.df.meta <- dplyr::select(cLar.adiv.df.meta, c(SampleID, Group, observed_otus, chao1))
fLar.adiv.df.meta <- dplyr::select(fLar.adiv.df.meta, c(SampleID, Group, observed_otus, chao1))

# specify the column of interest as unique factors
cBL.adiv.df.meta <- dplyr::mutate(cBL.adiv.df.meta, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
fBL.adiv.df.meta <- dplyr::mutate(fBL.adiv.df.meta, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
c57.adiv.df.meta <- dplyr::mutate(c57.adiv.df.meta, Facility=factor(Facility, levels=unique(Facility)))
cBos.adiv.df.meta <- dplyr::mutate(cBos.adiv.df.meta, Group=factor(Group, levels=unique(Group)))
fBos.adiv.df.meta <- dplyr::mutate(fBos.adiv.df.meta, Group=factor(Group, levels=unique(Group)))
cLar.adiv.df.meta <- dplyr::mutate(cLar.adiv.df.meta, Group=factor(Group, levels=unique(Group)))
fLar.adiv.df.meta <- dplyr::mutate(fLar.adiv.df.meta, Group=factor(Group, levels=unique(Group)))

# perform pairwise KW with Dunn's post-hoc and FDR correction
# NOTE: input data in data.frame must start after column 2
cBL.adiv.pwise.kw <- kw.plus.dunn.post(data=cBL.adiv.df.meta, col.intrst="GroupFacility")
fBL.adiv.pwise.kw <- kw.plus.dunn.post(data=fBL.adiv.df.meta, col.intrst="GroupFacility")
c57.adiv.pwise.kw <- kw.plus.dunn.post(data=c57.adiv.df.meta , col.intrst="Facility")
cBos.adiv.pwise.kw <- kw.plus.dunn.post(data=cBos.adiv.df.meta, col.intrst="Group")
fBos.adiv.pwise.kw <- kw.plus.dunn.post(data=fBos.adiv.df.meta, col.intrst="Group")
cLar.adiv.pwise.kw <- kw.plus.dunn.post(data=cLar.adiv.df.meta, col.intrst="Group")
fLar.adiv.pwise.kw <- kw.plus.dunn.post(data=fLar.adiv.df.meta, col.intrst="Group")

# perform pairwise Wilcoxon with FDR correction
# NOTE: input data in data.frame must start after column 2
cBL.adiv.pwise.wilc <- pwise.wilc(data=cBL.adiv.df.meta, col.intrst="GroupFacility")
fBL.adiv.pwise.wilc <- pwise.wilc(data=fBL.adiv.df.meta, col.intrst="GroupFacility")
c57.adiv.pwise.wilc <- pwise.wilc(data=c57.adiv.df.meta , col.intrst="Facility")
cBos.adiv.pwise.wilc <- pwise.wilc(data=cBos.adiv.df.meta, col.intrst="Group")
fBos.adiv.pwise.wilc <- pwise.wilc(data=fBos.adiv.df.meta, col.intrst="Group")
cLar.adiv.pwise.wilc <- pwise.wilc(data=cLar.adiv.df.meta, col.intrst="Group")
fLar.adiv.pwise.wilc <- pwise.wilc(data=fLar.adiv.df.meta, col.intrst="Group")

# filter the pwise data.frames
cBL.adiv.pwise.kw.flt <- flt.inter.fac(data=cBL.adiv.pwise.kw)
fBL.adiv.pwise.kw.flt <- flt.inter.fac(data=fBL.adiv.pwise.kw)
cBos.adiv.pwise.kw.flt <- flt.intra.fac(data=cBos.adiv.pwise.kw)
fBos.adiv.pwise.kw.flt <- flt.intra.fac(data=fBos.adiv.pwise.kw)
cLar.adiv.pwise.kw.flt <- flt.intra.fac(data=cLar.adiv.pwise.kw)
fLar.adiv.pwise.kw.flt <- flt.intra.fac(data=fLar.adiv.pwise.kw)
cBL.adiv.pwise.wilc.flt <- flt.inter.fac(data=cBL.adiv.pwise.wilc)
fBL.adiv.pwise.wilc.flt <- flt.inter.fac(data=fBL.adiv.pwise.wilc)
cBos.adiv.pwise.wilc.flt <- flt.intra.fac(data=cBos.adiv.pwise.wilc)
fBos.adiv.pwise.wilc.flt <- flt.intra.fac(data=fBos.adiv.pwise.wilc)
cLar.adiv.pwise.wilc.flt <- flt.intra.fac(data=cLar.adiv.pwise.wilc)
fLar.adiv.pwise.wilc.flt <- flt.intra.fac(data=fLar.adiv.pwise.wilc)

# add columns with rows specifying the sample type, and the pairwise test, the comparison, and the input data
cBL.adiv.pwise.kw.flt$Type <- "colon"
cBL.adiv.pwise.kw.flt$Test <- "KW"
cBL.adiv.pwise.kw.flt$Comp <- "inter"
cBL.adiv.pwise.kw.flt$Input <- "hscr"
fBL.adiv.pwise.kw.flt$Type <- "fecal"
fBL.adiv.pwise.kw.flt$Test <- "KW"
fBL.adiv.pwise.kw.flt$Comp <- "inter"
fBL.adiv.pwise.kw.flt$Input <- "hscr"
c57.adiv.pwise.kw$Type <- "fecal"
c57.adiv.pwise.kw$Test <- "KW"
c57.adiv.pwise.kw$Comp <- "inter"
c57.adiv.pwise.kw$Input <- "c57"
cBos.adiv.pwise.kw.flt$Type <- "colon"
cBos.adiv.pwise.kw.flt$Test <- "KW"
cBos.adiv.pwise.kw.flt$Comp <- "intra"
cBos.adiv.pwise.kw.flt$Input <- "hscr-bos"
fBos.adiv.pwise.kw.flt$Type <- "fecal"
fBos.adiv.pwise.kw.flt$Test <- "KW"
fBos.adiv.pwise.kw.flt$Comp <- "intra"
fBos.adiv.pwise.kw.flt$Input <- "hscr-bos"
cLar.adiv.pwise.kw.flt$Type <- "colon"
cLar.adiv.pwise.kw.flt$Test <- "KW"
cLar.adiv.pwise.kw.flt$Comp <- "intra"
cLar.adiv.pwise.kw.flt$Input <- "hscr-lar"
fLar.adiv.pwise.kw.flt$Type <- "fecal"
fLar.adiv.pwise.kw.flt$Test <- "KW"
fLar.adiv.pwise.kw.flt$Comp <- "intra"
fLar.adiv.pwise.kw.flt$Input <- "hscr-lar"
cBL.adiv.pwise.wilc.flt$Type <- "colon"
cBL.adiv.pwise.wilc.flt$Test <- "Wilc"
cBL.adiv.pwise.wilc.flt$Comp <- "inter"
cBL.adiv.pwise.wilc.flt$Input <- "hscr"
fBL.adiv.pwise.wilc.flt$Type <- "fecal"
fBL.adiv.pwise.wilc.flt$Test <- "Wilc"
fBL.adiv.pwise.wilc.flt$Comp <- "inter"
fBL.adiv.pwise.wilc.flt$Input <- "hscr"
c57.adiv.pwise.wilc$Type <- "fecal"
c57.adiv.pwise.wilc$Test <- "Wilc"
c57.adiv.pwise.wilc$Comp <- "inter"
c57.adiv.pwise.wilc$Input <- "c57"
cBos.adiv.pwise.wilc.flt$Type <- "colon"
cBos.adiv.pwise.wilc.flt$Test <- "Wilc"
cBos.adiv.pwise.wilc.flt$Comp <- "intra"
cBos.adiv.pwise.wilc.flt$Input <- "hscr-bos"
fBos.adiv.pwise.wilc.flt$Type <- "fecal"
fBos.adiv.pwise.wilc.flt$Test <- "Wilc"
fBos.adiv.pwise.wilc.flt$Comp <- "intra"
fBos.adiv.pwise.wilc.flt$Input <- "hscr-bos"
cLar.adiv.pwise.wilc.flt$Type <- "colon"
cLar.adiv.pwise.wilc.flt$Test <- "Wilc"
cLar.adiv.pwise.wilc.flt$Comp <- "intra"
cLar.adiv.pwise.wilc.flt$Input <- "hscr-lar"
fLar.adiv.pwise.wilc.flt$Type <- "fecal"
fLar.adiv.pwise.wilc.flt$Test <- "Wilc"
fLar.adiv.pwise.wilc.flt$Comp <- "intra"
fLar.adiv.pwise.wilc.flt$Input <- "hscr-lar"

# combine all of the data.frames
df.adiv.stats <- rbind(cBL.adiv.pwise.kw.flt,fBL.adiv.pwise.kw.flt,
                       cBL.adiv.pwise.wilc.flt,fBL.adiv.pwise.wilc.flt,
                       c57.adiv.pwise.kw,
                       c57.adiv.pwise.wilc,
                       cBos.adiv.pwise.kw.flt,fBos.adiv.pwise.kw.flt,cLar.adiv.pwise.kw.flt,fLar.adiv.pwise.kw.flt,
                       cBos.adiv.pwise.wilc.flt,fBos.adiv.pwise.wilc.flt,cLar.adiv.pwise.wilc.flt,fLar.adiv.pwise.wilc.flt)

# save table
setwd("~/Desktop/r_analysis/tab_s3/")
write.table(df.adiv.stats, file="adiv_stats.txt", sep="\t", row.names=FALSE)

########################################################
################ TABLE S4 and TABLE S6 #################
########################################################

# set the working directory
setwd("~/Desktop/r_analysis/tab_s4_tab_s6")

# read in the output from QIIME 1: summarize_taxa.py
hscr_phy <- read.taxa(file="HSCR_phylum.txt")
hscr_gen <- read.taxa(file="HSCR_genus.txt")
c57_phy <- read.taxa(file="c57_phylum.txt")

# remove unwanted columns
# optional: print names 'names(hscr_phy)'
# create a data.frame of unwanted columns
# create a vector from the unwanted column names
# remove columns from the data.frame
cols.hscr.phy <- hscr_phy[,2:25]
cols.hscr.phy <- names(cols.hscr.phy)
rm.cols.hscr.phy <- which(names(hscr_phy) %in% cols.hscr.phy)
hscr_phy <- hscr_phy[, -c(rm.cols.hscr.phy)]
cols.hscr.gen <- hscr_gen[,2:25]
cols.hscr.gen <- names(cols.hscr.gen)
rm.cols.hscr.gen <- which(names(hscr_gen) %in% cols.hscr.gen)
hscr_gen <- hscr_gen[, -c(rm.cols.hscr.gen)]
cols.c57.phy <- c57_phy[,2:10]
cols.c57.phy <- names(cols.c57.phy)
rm.cols.c57.phy <- which(names(c57_phy) %in% cols.c57.phy)
c57_phy <- c57_phy[, -c(rm.cols.c57.phy)]

# convert decimals to percentages
hscr_phy <- calc.prcnt(hscr_phy)
hscr_gen <- calc.prcnt(hscr_gen)
c57_phy <- calc.prcnt(c57_phy)

# search the data.frame for columns with relative abundance above X%
# and create a vector of columns names
hscr_high_phy_cols <- get.cols.ra(data=hscr_phy, threshold=5.99)
hscr_high_gen_cols <- get.cols.ra(data=hscr_gen, threshold=5.99)
c57_high_phy_cols <- get.cols.ra(data=c57_phy, threshold=5.99)

# create a new data.frame with high relative abundance phyla
hscr_high_phy <- hscr_phy[,c(1:1, hscr_high_phy_cols)]
hscr_high_gen <- hscr_gen[,c(1:1, hscr_high_gen_cols)]
c57_high_phy <- c57_phy[,c(1:1, c57_high_phy_cols)]

# change column 'X.SampleID' to 'SampleID'
names(hscr_high_phy)[1] <- "SampleID"
names(hscr_high_gen)[1] <- "SampleID"
names(c57_high_phy)[1] <- "SampleID"

# reduce columns in hscr metadata 
df.meta.hscr.flt <- dplyr::select(df.meta.hscr, SampleID, Type, Facility, Group, GroupFacility)

# merge in metadata from map
hscr.phy.meta <- merge(x=df.meta.hscr.flt, y=hscr_high_phy, by="SampleID", sort=FALSE, all=FALSE)
hscr.gen.meta <- merge(x=df.meta.hscr.flt, y=hscr_high_gen, by="SampleID", sort=FALSE, all=FALSE)
c57.phy.meta <- merge(x=df.meta.c57, y=c57_high_phy, by="SampleID", sort=FALSE, all=FALSE)

# split the hscr data.frames
splt.type.phy <- split.data.frame(x=hscr.phy.meta, f=hscr.phy.meta$Type)
cBL.phy <- splt.type.phy$colon
fBL.phy <- splt.type.phy$fecal
splt.type.gen <- split.data.frame(x=hscr.gen.meta, f=hscr.gen.meta$Type)
cBL.gen <- splt.type.gen$colon
fBL.gen <- splt.type.gen$fecal
splt.fac.phy.c <- split.data.frame(x=cBL.phy, f=cBL.phy$Facility)
cBos.phy <- splt.fac.phy.c$Boston
cLar.phy <- splt.fac.phy.c$Laramie
splt.fac.phy.f <- split.data.frame(x=fBL.phy, f=fBL.phy$Facility)
fBos.phy <- splt.fac.phy.f$Boston
fLar.phy <- splt.fac.phy.f$Laramie
splt.fac.gen.c <- split.data.frame(x=cBL.gen, f=cBL.gen$Facility)
cBos.gen <- splt.fac.gen.c$Boston
cLar.gen <- splt.fac.gen.c$Laramie
splt.fac.gen.f <- split.data.frame(x=fBL.gen, f=fBL.gen$Facility)
fBos.gen <- splt.fac.gen.f$Boston
fLar.gen <- splt.fac.gen.f$Laramie

# retain columns of interest
cBL.phy <- cBL.phy[,c(1,5:12)]
fBL.phy <- fBL.phy[,c(1,5:12)]
cBL.gen <- cBL.gen[,c(1,5:32)]
fBL.gen <- fBL.gen[,c(1,5:32)]
cBos.phy <- cBos.phy[,c(1,4,6:12)]
fBos.phy <- fBos.phy[,c(1,4,6:12)]
cLar.phy <- cLar.phy[,c(1,4,6:12)]
fLar.phy <- fLar.phy[,c(1,4,6:12)]
cBos.gen <- cBos.gen[,c(1,4,6:32)]
fBos.gen <- fBos.gen[,c(1,4,6:32)]
cLar.gen <- cLar.gen[,c(1,4,6:32)]
fLar.gen <- fLar.gen[,c(1,4,6:32)]

# specify the column of interest as unique factors
cBL.phy <- dplyr::mutate(cBL.phy, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
fBL.phy <- dplyr::mutate(fBL.phy, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
cBos.phy <- dplyr::mutate(cBos.phy, Group=factor(Group, levels=unique(Group)))
fBos.phy <- dplyr::mutate(fBos.phy, Group=factor(Group, levels=unique(Group)))
cLar.phy <- dplyr::mutate(cLar.phy, Group=factor(Group, levels=unique(Group)))
fLar.phy <- dplyr::mutate(fLar.phy, Group=factor(Group, levels=unique(Group)))
cBL.gen <- dplyr::mutate(cBL.gen, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
fBL.gen <- dplyr::mutate(fBL.gen, GroupFacility=factor(GroupFacility, levels=unique(GroupFacility)))
cBos.gen <- dplyr::mutate(cBos.gen, Group=factor(Group, levels=unique(Group)))
fBos.gen <- dplyr::mutate(fBos.gen, Group=factor(Group, levels=unique(Group)))
cLar.gen <- dplyr::mutate(cLar.gen, Group=factor(Group, levels=unique(Group)))
fLar.gen <- dplyr::mutate(fLar.gen, Group=factor(Group, levels=unique(Group)))
c57.phy.meta <- dplyr::mutate(c57.phy.meta, Facility=factor(Facility, levels=unique(Facility)))

# perform pairwise KW with Dunn's post-hoc and FDR correction
# NOTE: input data in data.frame must start after column 2
cBL.phy.pwise.kw <- kw.plus.dunn.post(data=cBL.phy, col.intrst="GroupFacility")
fBL.phy.pwise.kw <- kw.plus.dunn.post(data=fBL.phy, col.intrst="GroupFacility")
cBos.phy.pwise.kw <- kw.plus.dunn.post(data=cBos.phy, col.intrst="Group")
fBos.phy.pwise.kw <- kw.plus.dunn.post(data=fBos.phy, col.intrst="Group")
cLar.phy.pwise.kw <- kw.plus.dunn.post(data=cLar.phy, col.intrst="Group")
fLar.phy.pwise.kw <- kw.plus.dunn.post(data=fLar.phy, col.intrst="Group")
cBL.gen.pwise.kw <- kw.plus.dunn.post(data=cBL.gen, col.intrst="GroupFacility")
fBL.gen.pwise.kw <- kw.plus.dunn.post(data=fBL.gen, col.intrst="GroupFacility")
cBos.gen.pwise.kw <- kw.plus.dunn.post(data=cBos.gen, col.intrst="Group")
fBos.gen.pwise.kw <- kw.plus.dunn.post(data=fBos.gen, col.intrst="Group")
cLar.gen.pwise.kw <- kw.plus.dunn.post(data=cLar.gen, col.intrst="Group")
fLar.gen.pwise.kw <- kw.plus.dunn.post(data=fLar.gen, col.intrst="Group")
c57.phy.pwise.kw <- kw.plus.dunn.post(data=c57.phy.meta, col.intrst="Facility")

# perform pairwise Wilcoxon with FDR correction
# NOTE: input data in data.frame must start after column 2
cBL.phy.pwise.wilc <- pwise.wilc(data=cBL.phy, col.intrst="GroupFacility")
fBL.phy.pwise.wilc <- pwise.wilc(data=fBL.phy, col.intrst="GroupFacility")
cBos.phy.pwise.wilc <- pwise.wilc(data=cBos.phy, col.intrst="Group")
fBos.phy.pwise.wilc <- pwise.wilc(data=fBos.phy, col.intrst="Group")
cLar.phy.pwise.wilc <- pwise.wilc(data=cLar.phy, col.intrst="Group")
fLar.phy.pwise.wilc <- pwise.wilc(data=fLar.phy, col.intrst="Group")
cBL.gen.pwise.wilc <- pwise.wilc(data=cBL.gen, col.intrst="GroupFacility")
fBL.gen.pwise.wilc <- pwise.wilc(data=fBL.gen, col.intrst="GroupFacility")
cBos.gen.pwise.wilc <- pwise.wilc(data=cBos.gen, col.intrst="Group")
fBos.gen.pwise.wilc <- pwise.wilc(data=fBos.gen, col.intrst="Group")
cLar.gen.pwise.wilc <- pwise.wilc(data=cLar.gen, col.intrst="Group")
fLar.gen.pwise.wilc <- pwise.wilc(data=fLar.gen, col.intrst="Group")
c57.phy.pwise.wilc <- pwise.wilc(data=c57.phy.meta, col.intrst="Facility")

# filter the pwise data.frames for groups of interest
cBL.phy.pwise.kw.flt <- flt.inter.fac(data=cBL.phy.pwise.kw)
fBL.phy.pwise.kw.flt <- flt.inter.fac(data=fBL.phy.pwise.kw)
cBos.phy.pwise.kw.flt <- flt.intra.fac(data=cBos.phy.pwise.kw)
fBos.phy.pwise.kw.flt <- flt.intra.fac(data=fBos.phy.pwise.kw)
cLar.phy.pwise.kw.flt <- flt.intra.fac(data=cLar.phy.pwise.kw)
fLar.phy.pwise.kw.flt <- flt.intra.fac(data=fLar.phy.pwise.kw)
cBL.gen.pwise.kw.flt <- flt.inter.fac(data=cBL.gen.pwise.kw)
fBL.gen.pwise.kw.flt <- flt.inter.fac(data=fBL.gen.pwise.kw)
cBos.gen.pwise.kw.flt <- flt.intra.fac(data=cBos.gen.pwise.kw)
fBos.gen.pwise.kw.flt <- flt.intra.fac(data=fBos.gen.pwise.kw)
cLar.gen.pwise.kw.flt <- flt.intra.fac(data=cLar.gen.pwise.kw)
fLar.gen.pwise.kw.flt <- flt.intra.fac(data=fLar.gen.pwise.kw)
cBL.phy.pwise.wilc.flt <- flt.inter.fac(data=cBL.phy.pwise.wilc)
fBL.phy.pwise.wilc.flt <- flt.inter.fac(data=fBL.phy.pwise.wilc)
cBos.phy.pwise.wilc.flt <- flt.intra.fac(data=cBos.phy.pwise.wilc)
fBos.phy.pwise.wilc.flt <- flt.intra.fac(data=fBos.phy.pwise.wilc)
cLar.phy.pwise.wilc.flt <- flt.intra.fac(data=cLar.phy.pwise.wilc)
fLar.phy.pwise.wilc.flt <- flt.intra.fac(data=fLar.phy.pwise.wilc)
cBL.gen.pwise.wilc.flt <- flt.inter.fac(data=cBL.gen.pwise.wilc)
fBL.gen.pwise.wilc.flt <- flt.inter.fac(data=fBL.gen.pwise.wilc)
cBos.gen.pwise.wilc.flt <- flt.intra.fac(data=cBos.gen.pwise.wilc)
fBos.gen.pwise.wilc.flt <- flt.intra.fac(data=fBos.gen.pwise.wilc)
cLar.gen.pwise.wilc.flt <- flt.intra.fac(data=cLar.gen.pwise.wilc)
fLar.gen.pwise.wilc.flt <- flt.intra.fac(data=fLar.gen.pwise.wilc)

# filter the filtered pwise data.frames for p.adj < 0.05
cBL.phy.pwise.kw.SIGS <- dplyr::filter(cBL.phy.pwise.kw.flt, p.adj < 0.05)
cBL.phy.pwise.kw.SIGS <- dplyr::filter(cBL.phy.pwise.kw.flt, p.adj < 0.05)
fBL.phy.pwise.kw.SIGS <- dplyr::filter(fBL.phy.pwise.kw.flt, p.adj < 0.05)
cBos.phy.pwise.kw.SIGS <- dplyr::filter(cBos.phy.pwise.kw.flt, p.adj < 0.05)
fBos.phy.pwise.kw.SIGS <- dplyr::filter(fBos.phy.pwise.kw.flt, p.adj < 0.05)
cLar.phy.pwise.kw.SIGS <- dplyr::filter(cLar.phy.pwise.kw.flt, p.adj < 0.05)
fLar.phy.pwise.kw.SIGS <- dplyr::filter(fLar.phy.pwise.kw.flt, p.adj < 0.05)
cBL.gen.pwise.kw.SIGS <- dplyr::filter(cBL.gen.pwise.kw.flt, p.adj < 0.05)
fBL.gen.pwise.kw.SIGS <- dplyr::filter(fBL.gen.pwise.kw.flt, p.adj < 0.05)
cBos.gen.pwise.kw.SIGS <- dplyr::filter(cBos.gen.pwise.kw.flt, p.adj < 0.05)
fBos.gen.pwise.kw.SIGS <- dplyr::filter(fBos.gen.pwise.kw.flt, p.adj < 0.05)
cLar.gen.pwise.kw.SIGS <- dplyr::filter(cLar.gen.pwise.kw.flt, p.adj < 0.05)
fLar.gen.pwise.kw.SIGS <- dplyr::filter(fLar.gen.pwise.kw.flt, p.adj < 0.05)
cBL.phy.pwise.wilc.SIGS <- dplyr::filter(cBL.phy.pwise.wilc.flt, p.adj < 0.05)
fBL.phy.pwise.wilc.SIGS <- dplyr::filter(fBL.phy.pwise.wilc.flt, p.adj < 0.05)
cBos.phy.pwise.wilc.SIGS <- dplyr::filter(cBos.phy.pwise.wilc.flt, p.adj < 0.05)
fBos.phy.pwise.wilc.SIGS <- dplyr::filter(fBos.phy.pwise.wilc.flt, p.adj < 0.05)
cLar.phy.pwise.wilc.SIGS <- dplyr::filter(cLar.phy.pwise.wilc.flt, p.adj < 0.05)
fLar.phy.pwise.wilc.SIGS <- dplyr::filter(fLar.phy.pwise.wilc.flt, p.adj < 0.05)
cBL.gen.pwise.wilc.SIGS <- dplyr::filter(cBL.gen.pwise.wilc.flt, p.adj < 0.05)
fBL.gen.pwise.wilc.SIGS <- dplyr::filter(fBL.gen.pwise.wilc.flt, p.adj < 0.05)
cBos.gen.pwise.wilc.SIGS <- dplyr::filter(cBos.gen.pwise.wilc.flt, p.adj < 0.05)
fBos.gen.pwise.wilc.SIGS <- dplyr::filter(fBos.gen.pwise.wilc.flt, p.adj < 0.05)
cLar.gen.pwise.wilc.SIGS <- dplyr::filter(cLar.gen.pwise.wilc.flt, p.adj < 0.05)
fLar.gen.pwise.wilc.SIGS <- dplyr::filter(fLar.gen.pwise.wilc.flt, p.adj < 0.05)
c57.phy.pwise.kw.SIGS <- dplyr::filter(c57.phy.pwise.kw, p.adj < 0.05)
c57.phy.pwise.wilc.SIGS <- dplyr::filter(c57.phy.pwise.wilc, p.adj < 0.05)

# in the result from above the following tables have 0 obs.
# cBos.phy.pwise.wilc.SIGS
# cLar.phy.pwise.kw.SIGS 
# fLar.phy.pwise.kw.SIGS
# NOTE: as a result of 0 obs. these will not be included below

# add columns with rows specifying the sample type, the pairwise test, and the input data
cBL.phy.pwise.kw.SIGS$Type <- "colon"
cBL.phy.pwise.kw.SIGS$Test <- "KW"
cBL.phy.pwise.kw.SIGS$Input <- "hscr-phy"
fBL.phy.pwise.kw.SIGS$Type <- "fecal"
fBL.phy.pwise.kw.SIGS$Test <- "KW"
fBL.phy.pwise.kw.SIGS$Input <- "hscr-phy"
cBL.phy.pwise.wilc.SIGS$Type <- "colon"
cBL.phy.pwise.wilc.SIGS$Test <- "Wilc"
cBL.phy.pwise.wilc.SIGS$Input <- "hscr-phy"
fBL.phy.pwise.wilc.SIGS$Type <- "fecal"
fBL.phy.pwise.wilc.SIGS$Test <- "Wilc"
fBL.phy.pwise.wilc.SIGS$Input <- "hscr-phy"
cBL.gen.pwise.kw.SIGS$Type <- "colon"
cBL.gen.pwise.kw.SIGS$Test <- "KW"
cBL.gen.pwise.kw.SIGS$Input <- "hscr-gen"
fBL.gen.pwise.kw.SIGS$Type <- "fecal"
fBL.gen.pwise.kw.SIGS$Test <- "KW"
fBL.gen.pwise.kw.SIGS$Input <- "hscr-gen"
cBL.gen.pwise.wilc.SIGS$Type <- "colon"
cBL.gen.pwise.wilc.SIGS$Test <- "Wilc"
cBL.gen.pwise.wilc.SIGS$Input <- "hscr-gen"
fBL.gen.pwise.wilc.SIGS$Type <- "fecal"
fBL.gen.pwise.wilc.SIGS$Test <- "Wilc"
fBL.gen.pwise.wilc.SIGS$Input <- "hscr-gen"
c57.phy.pwise.kw.SIGS$Type <- "fecal"
c57.phy.pwise.kw.SIGS$Test <- "KW"
c57.phy.pwise.kw.SIGS$Input <- "c57"
c57.phy.pwise.wilc.SIGS$Type <- "fecal"
c57.phy.pwise.wilc.SIGS$Test <- "Wilc"
c57.phy.pwise.wilc.SIGS$Input <- "c57"
cBos.phy.pwise.kw.SIGS$Type <- "colon"
cBos.phy.pwise.kw.SIGS$Test <- "KW"
cBos.phy.pwise.kw.SIGS$Input <- "hscr-bos-phy"
fBos.phy.pwise.kw.SIGS$Type <- "fecal"
fBos.phy.pwise.kw.SIGS$Test <- "KW"
fBos.phy.pwise.kw.SIGS$Input <- "hscr-bos-phy"
fBos.phy.pwise.wilc.SIGS$Type <- "fecal"
fBos.phy.pwise.wilc.SIGS$Test <- "Wilc"
fBos.phy.pwise.wilc.SIGS$Input <- "hscr-bos-phy"
cLar.phy.pwise.wilc.SIGS$Type <- "colon"
cLar.phy.pwise.wilc.SIGS$Test <- "Wilc"
cLar.phy.pwise.wilc.SIGS$Input <- "hscr-lar-phy"
fLar.phy.pwise.wilc.SIGS$Type <- "fecal"
fLar.phy.pwise.wilc.SIGS$Test <- "Wilc"
fLar.phy.pwise.wilc.SIGS$Input <- "hscr-lar-phy"
cBos.gen.pwise.kw.SIGS$Type <- "colon"
cBos.gen.pwise.kw.SIGS$Test <- "KW"
cBos.gen.pwise.kw.SIGS$Input <- "hscr-bos-gen"
fBos.gen.pwise.kw.SIGS$Type <- "fecal"
fBos.gen.pwise.kw.SIGS$Test <- "KW"
fBos.gen.pwise.kw.SIGS$Input <- "hscr-bos-gen"
cBos.gen.pwise.wilc.SIGS$Type <- "colon"
cBos.gen.pwise.wilc.SIGS$Test <- "Wilc"
cBos.gen.pwise.wilc.SIGS$Input <- "hscr-bos-gen"
fBos.gen.pwise.wilc.SIGS$Type <- "fecal"
fBos.gen.pwise.wilc.SIGS$Test <- "Wilc"
fBos.gen.pwise.wilc.SIGS$Input <- "hscr-bos-gen"
cLar.gen.pwise.kw.SIGS$Type <- "colon"
cLar.gen.pwise.kw.SIGS$Test <- "KW"
cLar.gen.pwise.kw.SIGS$Input <- "hscr-lar-gen"
fLar.gen.pwise.kw.SIGS$Type <- "fecal"
fLar.gen.pwise.kw.SIGS$Test <- "KW"
fLar.gen.pwise.kw.SIGS$Input <- "hscr-lar-gen"
cLar.gen.pwise.wilc.SIGS$Type <- "colon"
cLar.gen.pwise.wilc.SIGS$Test <- "Wilc"
cLar.gen.pwise.wilc.SIGS$Input <- "hscr-lar-gen"
fLar.gen.pwise.wilc.SIGS$Type <- "fecal"
fLar.gen.pwise.wilc.SIGS$Test <- "Wilc"
fLar.gen.pwise.wilc.SIGS$Input <- "hscr-lar-gen"

# combine the .kwSIGS and .wilcSIGs data.frames
cBL.phy.SIGS <- rbind(cBL.phy.pwise.kw.SIGS,cBL.phy.pwise.wilc.SIGS)
fBL.phy.SIGS <- rbind(fBL.phy.pwise.kw.SIGS,fBL.phy.pwise.wilc.SIGS)
cBL.gen.SIGS <- rbind(cBL.gen.pwise.kw.SIGS,cBL.gen.pwise.wilc.SIGS)
fBL.gen.SIGS <- rbind(fBL.gen.pwise.kw.SIGS,fBL.gen.pwise.wilc.SIGS)
c57.phy.SIGS <- rbind(c57.phy.pwise.kw.SIGS,c57.phy.pwise.wilc.SIGS)
cBos.phy.SIGS <- cBos.phy.pwise.kw.SIGS
cBos.gen.SIGS <- rbind(cBos.gen.pwise.kw.SIGS,cBos.gen.pwise.wilc.SIGS)
fBos.phy.SIGS <- rbind(fBos.phy.pwise.kw.SIGS,fBos.phy.pwise.wilc.SIGS)
fBos.gen.SIGS <- rbind(fBos.gen.pwise.kw.SIGS,fBos.gen.pwise.wilc.SIGS)
cLar.phy.SIGS <- cLar.phy.pwise.wilc.SIGS
cLar.gen.SIGS <- rbind(cLar.gen.pwise.kw.SIGS,cLar.gen.pwise.wilc.SIGS)
fLar.phy.SIGS <- fLar.phy.pwise.wilc.SIGS
fLar.gen.SIGS <- rbind(fLar.gen.pwise.kw.SIGS,fLar.gen.pwise.wilc.SIGS)

# change column 'Metric' to 'Taxon'
names(cBL.phy.SIGS)[1] <- "Taxon"
names(fBL.phy.SIGS)[1] <- "Taxon"
names(cBL.gen.SIGS)[1] <- "Taxon"
names(fBL.gen.SIGS)[1] <- "Taxon"
names(c57.phy.SIGS)[1] <- "Taxon"
names(cBos.phy.SIGS)[1] <- "Taxon"
names(cBos.gen.SIGS)[1] <- "Taxon"
names(fBos.phy.SIGS)[1] <- "Taxon"
names(fBos.gen.SIGS)[1] <- "Taxon"
names(cLar.phy.SIGS)[1] <- "Taxon"
names(cLar.gen.SIGS)[1] <- "Taxon"
names(fLar.phy.SIGS)[1] <- "Taxon"
names(fLar.gen.SIGS)[1] <- "Taxon"

# replace . with - in column 'Pair2' for the HSCR data
cBL.phy.SIGS <- rplace.chars(data=cBL.phy.SIGS, col="Pair2", pat1=".WT.", rep1="-WT-", pat2=".KO.", rep2="-KO-")
fBL.phy.SIGS <- rplace.chars(data=fBL.phy.SIGS, col="Pair2", pat1=".WT.", rep1="-WT-", pat2=".KO.", rep2="-KO-")
cBL.gen.SIGS <- rplace.chars(data=cBL.gen.SIGS, col="Pair2", pat1=".WT.", rep1="-WT-", pat2=".KO.", rep2="-KO-")
fBL.gen.SIGS <- rplace.chars(data=fBL.gen.SIGS, col="Pair2", pat1=".WT.", rep1="-WT-", pat2=".KO.", rep2="-KO-")
cBos.phy.SIGS <- rplace.chars(data=cBos.phy.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
cBos.gen.SIGS <- rplace.chars(data=cBos.gen.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
fBos.phy.SIGS <- rplace.chars(data=fBos.phy.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
fBos.gen.SIGS <- rplace.chars(data=fBos.gen.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
cLar.phy.SIGS <- rplace.chars(data=cLar.phy.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
cLar.gen.SIGS <- rplace.chars(data=cLar.gen.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
fLar.phy.SIGS <- rplace.chars(data=fLar.phy.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")
fLar.gen.SIGS <- rplace.chars(data=fLar.gen.SIGS, col="Pair2", pat1=".WT", rep1="-WT", pat2=".KO", rep2="-KO")

# in order to know which group had [statistically supported] higher/lower abundance for a Taxon
# we need to add back in the relative abundance information...
# so...

# filter the stats input data.frame to retain only the info in the .SIGS data.frame
# NOTE: the c57.phy.meta data.frame already matches the c57.phy.SIGS data.frame
cBL.phy.flt <- flt.tax.df(data1=cBL.phy, data2=cBL.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                          d1.col="GroupFacility", keep.cols=c("SampleID", "GroupFacility"))
fBL.phy.flt <- flt.tax.df(data1=fBL.phy, data2=fBL.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                          d1.col="GroupFacility", keep.cols=c("SampleID", "GroupFacility"))
cBL.gen.flt <- flt.tax.df(data1=cBL.gen, data2=cBL.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                          d1.col="GroupFacility", keep.cols=c("SampleID", "GroupFacility"))
fBL.gen.flt <- flt.tax.df(data1=fBL.gen, data2=fBL.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                          d1.col="GroupFacility", keep.cols=c("SampleID", "GroupFacility"))
cBos.phy.flt <- flt.tax.df(data1=cBos.phy, data2=cBos.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
cBos.gen.flt <- flt.tax.df(data1=cBos.gen, data2=cBos.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
fBos.phy.flt <- flt.tax.df(data1=fBos.phy, data2=fBos.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
fBos.gen.flt <- flt.tax.df(data1=fBos.gen, data2=fBos.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
cLar.phy.flt <- flt.tax.df(data1=cLar.phy, data2=cLar.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
cLar.gen.flt <- flt.tax.df(data1=cLar.gen, data2=cLar.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
fLar.phy.flt <- flt.tax.df(data1=fLar.phy, data2=fLar.phy.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))
fLar.gen.flt <- flt.tax.df(data1=fLar.gen, data2=fLar.gen.SIGS, d2.col1="Taxon", d2.col2="Pair1", d2.col3="Pair2", 
                           d1.col="Group", keep.cols=c("SampleID", "Group"))

# remove column SampleID from each data.frame
cBL.phy.flt <- dplyr::select(cBL.phy.flt, -SampleID)
fBL.phy.flt <- dplyr::select(fBL.phy.flt, -SampleID)
cBL.gen.flt <- dplyr::select(cBL.gen.flt, -SampleID)
fBL.gen.flt <- dplyr::select(fBL.gen.flt, -SampleID)
c57.phy.flt <- dplyr::select(c57.phy.meta, -SampleID)
cBos.phy.flt <- dplyr::select(cBos.phy.flt, -SampleID)
cBos.gen.flt <- dplyr::select(cBos.gen.flt, -SampleID)
fBos.phy.flt <- dplyr::select(fBos.phy.flt, -SampleID)
fBos.gen.flt <- dplyr::select(fBos.gen.flt, -SampleID)
cLar.phy.flt <- dplyr::select(cLar.phy.flt, -SampleID)
cLar.gen.flt <- dplyr::select(cLar.gen.flt, -SampleID)
fLar.phy.flt <- dplyr::select(fLar.phy.flt, -SampleID)
fLar.gen.flt <- dplyr::select(fLar.gen.flt, -SampleID)

# calculate mean relative abundance for each group
cBL.phy.mRA <- dplyr::summarise_all(dplyr::group_by(cBL.phy.flt, GroupFacility), .fun=mean)
fBL.phy.mRA <- dplyr::summarise_all(dplyr::group_by(fBL.phy.flt, GroupFacility), .fun=mean)
cBL.gen.mRA <- dplyr::summarise_all(dplyr::group_by(cBL.gen.flt, GroupFacility), .fun=mean)
fBL.gen.mRA <- dplyr::summarise_all(dplyr::group_by(fBL.gen.flt, GroupFacility), .fun=mean)
c57.phy.mRA <- dplyr::summarise_all(dplyr::group_by(c57.phy.flt, Facility), .fun=mean)
cBos.phy.mRA <- dplyr::summarise_all(dplyr::group_by(cBos.phy.flt, Group), .fun=mean)
cBos.gen.mRA <- dplyr::summarise_all(dplyr::group_by(cBos.gen.flt, Group), .fun=mean)
fBos.phy.mRA <- dplyr::summarise_all(dplyr::group_by(fBos.phy.flt, Group), .fun=mean)
fBos.gen.mRA <- dplyr::summarise_all(dplyr::group_by(fBos.gen.flt, Group), .fun=mean)
cLar.phy.mRA <- dplyr::summarise_all(dplyr::group_by(cLar.phy.flt, Group), .fun=mean)
cLar.gen.mRA <- dplyr::summarise_all(dplyr::group_by(cLar.gen.flt, Group), .fun=mean)
fLar.phy.mRA <- dplyr::summarise_all(dplyr::group_by(fLar.phy.flt, Group), .fun=mean)
fLar.gen.mRA <- dplyr::summarise_all(dplyr::group_by(fLar.gen.flt, Group), .fun=mean)

# reshape the data.frame to convert columns into rows for each Group
cBL.phy.mRA.rshp <- reshape2::melt(cBL.phy.mRA, id.var="GroupFacility", variable="Taxon", value.name="MeanRA")
fBL.phy.mRA.rshp <- reshape2::melt(fBL.phy.mRA, id.var="GroupFacility", variable="Taxon", value.name="MeanRA")
cBL.gen.mRA.rshp <- reshape2::melt(cBL.gen.mRA, id.var="GroupFacility", variable="Taxon", value.name="MeanRA")
fBL.gen.mRA.rshp <- reshape2::melt(fBL.gen.mRA, id.var="GroupFacility", variable="Taxon", value.name="MeanRA")
c57.phy.mRA.rshp <- reshape2::melt(c57.phy.mRA, id.var="Facility", variable="Taxon", value.name="MeanRA")
cBos.phy.mRA.rshp <- reshape2::melt(cBos.phy.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
cBos.gen.mRA.rshp <- reshape2::melt(cBos.gen.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
fBos.phy.mRA.rshp <- reshape2::melt(fBos.phy.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
fBos.gen.mRA.rshp <- reshape2::melt(fBos.gen.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
cLar.phy.mRA.rshp <- reshape2::melt(cLar.phy.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
cLar.gen.mRA.rshp <- reshape2::melt(cLar.gen.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
fLar.phy.mRA.rshp <- reshape2::melt(fLar.phy.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")
fLar.gen.mRA.rshp <- reshape2::melt(fLar.gen.mRA, id.var="Group", variable="Taxon", value.name="MeanRA")

# merge .mRA.rshp and .SIGS data.frames to add in Mean Relatice Abundances for each group
cBL.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cBL.phy.mRA.rshp, df.SIGS=cBL.phy.SIGS, mRA.col="GroupFacility", merge.col="Taxon", col.rnme="MeanRA",
                                   SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fBL.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fBL.phy.mRA.rshp, df.SIGS=fBL.phy.SIGS, mRA.col="GroupFacility", merge.col="Taxon", col.rnme="MeanRA",
                                   SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
cBL.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cBL.gen.mRA.rshp, df.SIGS=cBL.gen.SIGS, mRA.col="GroupFacility", merge.col="Taxon", col.rnme="MeanRA",
                                   SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fBL.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fBL.gen.mRA.rshp, df.SIGS=fBL.gen.SIGS, mRA.col="GroupFacility", merge.col="Taxon", col.rnme="MeanRA",
                                   SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
c57.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=c57.phy.mRA.rshp, df.SIGS=c57.phy.SIGS, mRA.col="Facility", merge.col="Taxon", col.rnme="MeanRA",
                                   SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
cBos.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cBos.phy.mRA.rshp, df.SIGS=cBos.phy.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
cBos.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cBos.gen.mRA.rshp, df.SIGS=cBos.gen.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fBos.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fBos.phy.mRA.rshp, df.SIGS=fBos.phy.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fBos.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fBos.gen.mRA.rshp, df.SIGS=fBos.gen.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
cLar.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cLar.phy.mRA.rshp, df.SIGS=cLar.phy.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
cLar.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=cLar.gen.mRA.rshp, df.SIGS=cLar.gen.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fLar.phy.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fLar.phy.mRA.rshp, df.SIGS=fLar.phy.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")
fLar.gen.SIGS.mRA <- merge.mRA.SIGS(df.mRA=fLar.gen.mRA.rshp, df.SIGS=fLar.gen.SIGS, mRA.col="Group", merge.col="Taxon", col.rnme="MeanRA",
                                    SIGS.col1="Pair1", new.col.name1="MeanRA.P1", SIGS.col2="Pair2", new.col.name2="MeanRA.P2")


# now remove any taxa with mRA less than 5.99 for both groups
cBL.phy.SIGS.mRA <- dplyr::filter(cBL.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fBL.phy.SIGS.mRA <- dplyr::filter(fBL.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
cBL.gen.SIGS.mRA <- dplyr::filter(cBL.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fBL.gen.SIGS.mRA <- dplyr::filter(fBL.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
c57.phy.SIGS.mRA <- dplyr::filter(c57.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
cBos.phy.SIGS.mRA <- dplyr::filter(cBos.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
cBos.gen.SIGS.mRA <- dplyr::filter(cBos.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fBos.phy.SIGS.mRA <- dplyr::filter(fBos.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fBos.gen.SIGS.mRA <- dplyr::filter(fBos.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
cLar.phy.SIGS.mRA <- dplyr::filter(cLar.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
cLar.gen.SIGS.mRA <- dplyr::filter(cLar.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fLar.phy.SIGS.mRA <- dplyr::filter(fLar.phy.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)
fLar.gen.SIGS.mRA <- dplyr::filter(fLar.gen.SIGS.mRA, !MeanRA.P1 < 5.99 | !MeanRA.P2 < 5.99)

# combine the inter facility data.frames
tax.inter.fac.stats <- rbind(cBL.phy.SIGS.mRA,fBL.phy.SIGS.mRA,cBL.gen.SIGS.mRA,fBL.gen.SIGS.mRA,c57.phy.SIGS.mRA)

# combine all inter facility data.frames
tax.intra.fac.stats <- rbind(cBos.phy.SIGS.mRA,cBos.gen.SIGS.mRA,fBos.phy.SIGS.mRA,fBos.gen.SIGS.mRA,
                             cLar.phy.SIGS.mRA,cLar.gen.SIGS.mRA,fLar.phy.SIGS.mRA,fLar.gen.SIGS.mRA)

# save tables
setwd("~/Desktop/r_analysis/tab_s4_tab_s6/")
write.table(tax.inter.fac.stats, file="tax_inter_stats.txt", sep="\t", row.names=FALSE)
write.table(tax.intra.fac.stats, file="tax_intra_stats.txt", sep="\t", row.names=FALSE)

# NOTE: 
# For Table S4: use "tax_inter_stats.txt"
# For Table S6: use "tax_intra_stats.txt"

#############################
######### TABLE S5 ##########
#############################

# set the working directory
setwd("~/Desktop/r_analysis/tab_s5/")

# read in the distance matrices (Total Beta Diversity)
uw_cBos_dm <- read.dm(file="../bdiv/uw_cBos.txt")
w_cBos_dm <- read.dm(file="../bdiv/w_cBos.txt")
uw_fBos_dm <- read.dm(file="../bdiv/uw_fBos.txt")
w_fBos_dm <- read.dm(file="../bdiv/w_fBos.txt")
uw_cLar_dm <- read.dm(file="../bdiv/uw_cLar.txt")
w_cLar_dm <- read.dm(file="../bdiv/w_cLar.txt")
uw_fLar_dm <- read.dm(file="../bdiv/uw_fLar.txt")
w_fLar_dm <- read.dm(file="../bdiv/w_fLar.txt")


# pairwise adonis for the HSCR dataset
uw_adon.cBos <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=uw_cBos_dm, match.col="SampleID", 
                           comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.cBos <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=w_cBos_dm, match.col="SampleID", 
                          comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
uw_adon.fBos <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=uw_fBos_dm, match.col="SampleID", 
                           comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.fBos <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=w_fBos_dm, match.col="SampleID", 
                          comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
uw_adon.cLar <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=uw_cLar_dm, match.col="SampleID", 
                           comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.cLar <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=w_cLar_dm, match.col="SampleID", 
                          comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
uw_adon.fLar <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=uw_fLar_dm, match.col="SampleID", 
                           comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)
w_adon.fLar <- pwise.adon(meta=df.meta.hscr, flt.col.intrst="Group", dist.obj=w_fLar_dm, match.col="SampleID", 
                          comp.formula=flt.dm~Group, n.perms=10000, p.adj.method="fdr", digits=3)

# create a vector to filter the outputs for groups of interest
# in this case, age- matched mice within each facility
# run them in both directions (aka P07-WT vs P07-KO AND P07-KO vs P07-WT)
vec.grp.comp <- c("P07-WT vs P07-KO","P07-KO vs P07-WT",
                  "P20-WT vs P20-KO","P20-KO vs P20-WT",
                  "P24-WT vs P24-KO","P24-KO vs P24-WT")

# create a vector of row numbers in column 'Comparison' that match our groups of interest
row.nums.uw_cBos <- which(uw_adon.cBos[,"Comparison"] %in% vec.grp.comp)
row.nums.w_cBos <- which(w_adon.cBos[,"Comparison"] %in% vec.grp.comp)
row.nums.uw_fBos <- which(uw_adon.fBos[,"Comparison"] %in% vec.grp.comp)
row.nums.w_fBos <- which(w_adon.fBos[,"Comparison"] %in% vec.grp.comp)
row.nums.uw_cLar <- which(uw_adon.cLar[,"Comparison"] %in% vec.grp.comp)
row.nums.w_cLar <- which(w_adon.cLar[,"Comparison"] %in% vec.grp.comp)
row.nums.uw_fLar <- which(uw_adon.fLar[,"Comparison"] %in% vec.grp.comp)
row.nums.w_fLar <- which(w_adon.fLar[,"Comparison"] %in% vec.grp.comp)

# create new data.frames with only our groups of interest
uw_adon.cBos.grp <- uw_adon.cBos[row.nums.uw_cBos,]
w_adon.cBos.grp <- w_adon.cBos[row.nums.w_cBos,]
uw_adon.fBos.grp <- uw_adon.fBos[row.nums.uw_fBos,]
w_adon.fBos.grp <- w_adon.fBos[row.nums.w_fBos,]
uw_adon.cLar.grp <- uw_adon.cLar[row.nums.uw_cLar,]
w_adon.cLar.grp <- w_adon.cLar[row.nums.w_cLar,]
uw_adon.fLar.grp <- uw_adon.fLar[row.nums.uw_fLar,]
w_adon.fLar.grp <- w_adon.fLar[row.nums.w_fLar,]

# add columns with rows specifying beta diversity metric, the sample type, and whether the input data was Total or Core
uw_adon.cBos.grp$DivMetrc <- "UW.Uni"
uw_adon.cBos.grp$Type <- "colon"
uw_adon.cBos.grp$Input <- "Bos"
w_adon.cBos.grp$DivMetrc <- "W.Uni"
w_adon.cBos.grp$Type <- "colon"
w_adon.cBos.grp$Input <- "Bos"
uw_adon.fBos.grp$DivMetrc <- "UW.Uni"
uw_adon.fBos.grp$Type <- "fecal"
uw_adon.fBos.grp$Input <- "Bos"
w_adon.fBos.grp$DivMetrc <- "W.Uni"
w_adon.fBos.grp$Type <- "fecal"
w_adon.fBos.grp$Input <- "Bos"
uw_adon.cLar.grp$DivMetrc <- "UW.Uni"
uw_adon.cLar.grp$Type <- "colon"
uw_adon.cLar.grp$Input <- "Lar"
w_adon.cLar.grp$DivMetrc <- "W.Uni"
w_adon.cLar.grp$Type <- "colon"
w_adon.cLar.grp$Input <- "Lar"
uw_adon.fLar.grp$DivMetrc <- "UW.Uni"
uw_adon.fLar.grp$Type <- "fecal"
uw_adon.fLar.grp$Input <- "Lar"
w_adon.fLar.grp$DivMetrc <- "W.Uni"
w_adon.fLar.grp$Type <- "fecal"
w_adon.fLar.grp$Input <- "Lar"

# combine all of the data.frames
adon.grp <- rbind(uw_adon.cBos.grp, w_adon.cBos.grp,uw_adon.fBos.grp,w_adon.fBos.grp,
                  uw_adon.cLar.grp,w_adon.cLar.grp,uw_adon.fLar.grp,w_adon.fLar.grp)

# save table
setwd("~/Desktop/r_analysis/tab_s5/")
write.table(adon.grp, file="adonis_intrafacility.txt", sep="\t", row.names=FALSE)

# save workspace
setwd("~/Desktop/r_analysis/")
save.image(file="R_Code_4_WS.Rdata")

